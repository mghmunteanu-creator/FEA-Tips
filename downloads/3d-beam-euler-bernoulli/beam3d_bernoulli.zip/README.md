# FEA Tips — Section 23.1

Linear analysis of a 3D beam structure with Euler–Bernoulli finite elements.

Extract all files into one folder, make it MATLAB's current folder, and run `main.m`.

- `main.m`: runs the analysis and plotting sequence.
- `gen.m`: defines geometry, material, loads and boundary conditions.
- `princ.m`: constructs the element local-frame transformation matrices.
- `beam3d.m`: forms and assembles stiffness, applies boundary conditions and solves for nodal displacements.
- `efforts3d.m`: reports nodal displacements/rotations and element forces/moments.
- `gr_beam3d.m`: plots undeformed and deformed geometry; Enter selects deformation scale 1.

Expected environment: desktop MATLAB R2024 or later with standard numerical and graphics functions, without additional toolboxes. Compatibility with every release has not been tested.

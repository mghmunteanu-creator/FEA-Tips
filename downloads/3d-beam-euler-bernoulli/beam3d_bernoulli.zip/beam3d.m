% *** beam3d ***
xg=[-sqrt(3)/3  sqrt(3)/3]; 
neq=6*nnd;
K=zeros(neq);   
F=zeros(neq,1);
D=[ea   0   0   0
    0  git  0   0
    0   0  eiy  0
    0   0   0  eiz];  
zr=zeros(3);
for ie=1:nel 
    n1=elem(ie,1); n2=elem(ie,2);
    ip=[6*n1-5  6*n1-4  6*n1-3  6*n1-2  6*n1-1  6*n1  6*n2-5  6*n2-4  6*n2-3  6*n2-2  6*n2-1  6*n2]';
    dx=x(n2)-x(n1); dy=y(n2)-y(n1); dz=z(n2)-z(n1);
    L=sqrt(dx*dx+dy*dy+dz*dz);
    R0=R0t(:,:,ie);
    R=[R0 zr zr zr
       zr R0 zr zr
       zr zr R0 zr
       zr zr zr R0];
    kel=zeros(12,12);
    for ig=1:2
        xc=(1+xg(ig))/2;
        B=[-1/L         0                  0              0          0               0        1/L        0                 0             0          0             0
             0          0                  0            -1/L         0               0         0         0                 0            1/L         0             0
             0          0            (6-12*xc)/L/L        0      (-4+6*xc)/L         0         0         0          (-6+12*xc)/L/L       0      (-2+6*xc)/L       0     
             0    (-6+12*xc)/L/L           0              0          0          (-4+6*xc)/L    0    (6-12*xc)/L/L          0             0          0        (-2+6*xc)/L ];   
        kel=kel+B'*D*B*L/2;
    end
    kel=R'*kel*R;
    K(ip,ip)=K(ip,ip)+kel;
end
loc=6*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)+forze(:,3);
loc=6*(cond(:,1)-1)+cond(:,2);
K(loc,:)=0; K(:,loc)=0; F(loc,:)=0;                    
K(loc,loc)=eye(length(loc));      
S=K\F;      

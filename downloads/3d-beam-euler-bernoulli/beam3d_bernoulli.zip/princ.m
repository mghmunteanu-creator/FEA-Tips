% *** princ ***
R0t=zeros(3,3,nel);
for ie=1:nel
    x3=n3(ie,1); y3=n3(ie,2); z3=n3(ie,3);
    n1=elem(ie,1);n2=elem(ie,2);
    lmn1(1)=x(n2)-x(n1); lmn1(2)=y(n2)-y(n1); lmn1(3)=z(n2)-z(n1);
    nm=norm(lmn1); lmn1=lmn1/nm;
    
    lmn2(1)=x3-x(n1);  lmn2(2)=y3-y(n1);  lmn2(3)=z3-z(n1);
    nm=norm(lmn2); lmn2=lmn2/nm;
    
    lmn3=cross(lmn1,lmn2); nm=norm(lmn3); lmn3=lmn3/nm;
    lmn2=cross(lmn3,lmn1);
    
    R0t(:,:,ie)=[lmn1;lmn2;lmn3];
end

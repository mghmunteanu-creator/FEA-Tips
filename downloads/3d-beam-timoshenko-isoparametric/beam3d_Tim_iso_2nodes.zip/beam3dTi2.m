%*** beam3dTi2 ***
neq=6*nnd;
D=diag([ea gay gaz git eiy eiz]);
K=zeros(neq);   
F=zeros(neq,1);
zr=zeros(3);
for ie=1:nel  
    n1=elem(ie,1); n2=elem(ie,2);
    ip=[6*n1-5  6*n1-4  6*n1-3  6*n1-2  6*n1-1  6*n1  6*n2-5  6*n2-4  6*n2-3  6*n2-2  6*n2-1  6*n2]';
    dx=x(n2)-x(n1); dy=y(n2)-y(n1); dz=z(n2)-z(n1);
    L=sqrt(dx*dx+dy*dy+dz*dz);
    
    mz=12*eiy/L^2/gaz;
    gammaz=mz/(1+mz);
    my=12*eiz/L^2/gay;
    gammay=my/(1+my);
    D=diag([ea gay*gammay gaz*gammaz git eiy eiz]);
    
    R0=R0t(:,:,ie);
    R=[R0 zr zr zr
       zr R0 zr zr
       zr zr R0 zr
       zr zr zr R0];
    B=[-1/L    0    0    0    0    0  1/L    0    0    0    0    0
          0 -1/L    0    0    0 -1/2    0  1/L    0    0    0 -1/2
          0    0  1/L    0 -1/2    0    0    0 -1/L    0 -1/2    0
          0    0    0 -1/L    0    0    0    0    0  1/L    0    0
          0    0    0    0 -1/L    0    0    0    0    0  1/L    0
          0    0    0    0    0 -1/L    0    0    0    0    0  1/L];
    B(3,:)=-B(3,:);
    kel=B'*D*B*L;
    kel=R'*kel*R;              
    K(ip,ip)=K(ip,ip)+kel;
end
loc=6*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)+forze(:,3);
loc=6*(cond(:,1)-1)+cond(:,2);
K(loc,:)=0; K(:,loc)=0; F(loc,:)=0;                    
K(loc,loc)=eye(length(loc));      
S=K\F;

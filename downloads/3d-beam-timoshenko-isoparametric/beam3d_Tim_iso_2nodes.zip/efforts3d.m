% *** efforts3d ***
disp('Node  u_displacement  v_displacement  w_displacement  rotation_x      rotation_y      rotation_z')
u=S(1:6:neq);
v=S(2:6:neq);
w=S(3:6:neq);
fix=S(4:6:neq);
fiy=S(5:6:neq);
fiz=S(6:6:neq);
disp(num2str([[1:nnd]' u v w fix fiy fiz],'%-5.0f %-12.5g    %-12.5g    %-12.5g    %-12.5g    %-12.5g    %-12.5g\n'))
disp('=======================================================================================================')
disp('Elem node   N            Ty           Tz           Mx           My           Mz')
for ie=1:nel
    n1=elem(ie,1); n2=elem(ie,2);
    ip=[6*n1-5  6*n1-4  6*n1-3  6*n1-2  6*n1-1  6*n1  6*n2-5  6*n2-4  6*n2-3  6*n2-2  6*n2-1  6*n2]';
    dx=x(n2)-x(n1); dy=y(n2)-y(n1); dz=z(n2)-z(n1);
    L=sqrt(dx*dx+dy*dy+dz*dz);
    
    mz=12*eiy/L^2/gaz;
    gammaz=mz/(1+mz);
    my=12*eiz/L^2/gay;
    gammay=my/(1+my);
    D=diag([ea gay*gammay gaz*gammaz git eiy eiz]);

    R0=R0t(:,:,ie);
    zr=zeros(3);
    R=[R0 zr zr zr
       zr R0 zr zr
       zr zr R0 zr
       zr zr zr R0];
 	kel=zeros(12,12);
    B=[-1/L    0    0    0    0    0  1/L    0    0    0    0    0
          0 -1/L    0    0    0 -1/2    0  1/L    0    0    0 -1/2
          0    0  1/L    0 -1/2    0    0    0 -1/L    0 -1/2    0
          0    0    0 -1/L    0    0    0    0    0  1/L    0    0
          0    0    0    0 -1/L    0    0    0    0    0  1/L    0
          0    0    0    0    0 -1/L    0    0    0    0    0  1/L];
    B(3,:)=-B(3,:);
    kel=B'*D*B*L;
    efforts=kel*R*S(ip);
    disp(num2str([ie n1 efforts(1: 6)'],'%-5.0f %-5.0f %-12.5g %-12.5g %-12.5g %-12.5g %-12.5g %-12.5g\n'))
    disp(num2str([ie n2 efforts(7:12)'],'%-5.0f %-5.0f %-12.5g %-12.5g %-12.5g %-12.5g %-12.5g %-12.5g\n'))
    disp(' ')
end

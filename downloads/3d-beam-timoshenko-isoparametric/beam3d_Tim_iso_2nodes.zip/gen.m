% *** gen ***
%==========================================================================
% It generates input data for a cantilevr beam:
%   Lg- beam length
%   E - Young modulus
%   G - shear modulus 
%   A - cross-section area
%   Ay, Az - shear areas
%   It- geometrical cross-section property for torsion 
%   Iy & Iz- geometrical inertia moments of cross-section
%==========================================================================
% x, y, z -  nodal coordinates 
%        x=[x1 x2 x3 x4 ...]'
%        y=[y1 y2 y3 y4 ...]'
%        z=[z1 z2 z3 z4 ...]'
%        
% elem  table contains element nodes
%       [node1  node2]
%        :      :    ]
%
% n3    table containing the coordinates of the third node of beam 
%       elements to define y local axis
%       [xn31  yn31  zn31
%        xn32  yn32  zn32
%        :     :     :   ]
%
% cond  table contains nodal constraints
%       (dir=1 - x direction, dir=2 - y direction, dir=3 - z direction)
%       [node1  dir1
%        node2  dir2
%        :      :   ]
%
% forze table contains nodal loads: node, direction, value
%       [node1  dir1  force1
%        node2  dir2  force2
%        :      :     :           :     ]
%
% R0t   tridimensional table (3x3xnel) contains the 3x3 rotation matrices
%==========================================================================
R=50;
H=80;
h=9;
b=6;
E=1000;
G=E/2.6;
A=b*h;
Ay=5/6*A;
Az=5/6*A;
Iz=b*h^3/12;
Iy=h*b^3/12;
%--------------------------------------------------------------------------
% Finds the coeficien of the stiffness modulus for torsion
dM=max([h,b]);
dm=min([h,b]);
hpeb=[1     1.5   2     3     4     6     8     10    100];
beta=[0.141 0.196 0.229 0.263 0.281 0.299 0.307 0.313 0.333];
cbt=interp1(hpeb,beta,dM/dm,'PCHIP');
%--------------------------------------------------------------------------
It=cbt*dM*dm^3;
ea=E*A; 
gay=G*Ay;
gaz=G*Az;
git=G*It;
eiz=E*Iz;
eiy=E*Iy;
%==========================================================================
nel=40;                         % number of beam elemens
nnd=nel+1;                        % number of nodes
%==========================================================================
% Nodal coordinates:
dang=2*pi/nel;
dH=H/nel;
ang=0;
Hc=0;
for i=1:nnd
    x(i,1)=R*cos(ang);
    y(i,1)=R*sin(ang);
    z(i,1)=Hc;
    ang=ang+dang;
    Hc=Hc+dH;
end
%==========================================================================
% elements
elem=[[1:nnd-1]' [2:nnd]'];
%==========================================================================
% n3 table
n3=zeros(nel,3);
Hc=dH/2;
for ie=1:nel
    n3(ie,:)=[0 0 Hc];
    Hc=Hc+dH;
end
%==========================================================================
% constraints
cond=[1    1
      1    2
      1    3
      1    4
      1    5
      1    6];
%==========================================================================
%  loads
forze=[nnd    1   -1
       nnd    2    1
       nnd    3    1];
%==========================================================================
% generation of R0 matrices
princ

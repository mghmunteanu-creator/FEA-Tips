% *** main ***
clear
format short e
gen
beam3dTi2
figure(5), clf, hold on, grid on, axis('equal')
efforts3d
gr_beam3d

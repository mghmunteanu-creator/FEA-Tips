% *** efforts3d ***
disp('Node  u_displacement  v_displacement  w_displacement  rotation_x      rotation_y      rotation_z')
u=S(1:6:neq);
v=S(2:6:neq);
w=S(3:6:neq);
fix=S(4:6:neq);
fiy=S(5:6:neq);
fiz=S(6:6:neq);
disp(num2str([[1:nnd]' u v w fix fiy fiz],'%-5.0f %-12.5g    %-12.5g    %-12.5g    %-12.5g    %-12.5g    %-12.5g\n'))
disp('=======================================================================================================')
disp('Elem node   N            Ty           Tz           Mx           My           Mz')
for ie=1:nel
    n1=elem(ie,1); n2=elem(ie,2);
    dx=x(n2)-x(n1); dy=y(n2)-y(n1); dz=z(n2)-z(n1);
    L=sqrt(dx*dx+dy*dy+dz*dz);
    R0=R0t(:,:,ie);
    zr=zeros(3);
    R=[R0 zr zr zr
       zr R0 zr zr
       zr zr R0 zr
       zr zr zr R0];
    ip=[6*n1-5  6*n1-4  6*n1-3  6*n1-2  6*n1-1  6*n1  6*n2-5  6*n2-4  6*n2-3  6*n2-2  6*n2-1  6*n2]';
 	kel=zeros(12,12);
    for ig=1:2
        xc=(1+xg(ig))/2*L;
        B=[[ -1/L,                                          0,                                          0,    0,                                                           0,                                                            0, 1/L,                                         0,                                         0,   0,                                                            0,                                                           0]
           [    0,           -(12*eiz)/(L*(gay*L^2 + 12*eiz)),                                          0,    0,                                                           0,                                  -(6*eiz)/(gay*L^2 + 12*eiz),   0,           (12*eiz)/(L*(gay*L^2 + 12*eiz)),                                         0,   0,                                                            0,                                 -(6*eiz)/(gay*L^2 + 12*eiz)]
           [    0,                                          0,            (12*eiy)/(L*(gaz*L^2 + 12*eiy)),    0,                                 -(6*eiy)/(gaz*L^2 + 12*eiy),                                                            0,   0,                                         0,          -(12*eiy)/(L*(gaz*L^2 + 12*eiy)),   0,                                  -(6*eiy)/(gaz*L^2 + 12*eiy),                                                           0]
           [    0,                                          0,                                          0, -1/L,                                                           0,                                                            0,   0,                                         0,                                         0, 1/L,                                                            0,                                                           0]
           [    0,                                          0, -(6*gaz*(L - 2*xc))/(L*(gaz*L^2 + 12*eiy)),    0, (2*(2*gaz*L^2 - 3*gaz*xc*L + 6*eiy))/(L*(gaz*L^2 + 12*eiy)),                                                            0,   0,                                         0, (6*gaz*(L - 2*xc))/(L*(gaz*L^2 + 12*eiy)),   0, -(2*(- gaz*L^2 + 3*gaz*xc*L + 6*eiy))/(L*(gaz*L^2 + 12*eiy)),                                                           0]
           [    0, -(6*gay*(L - 2*xc))/(L*(gay*L^2 + 12*eiz)),                                          0,    0,                                                           0, -(2*(2*gay*L^2 - 3*gay*xc*L + 6*eiz))/(L*(gay*L^2 + 12*eiz)),   0, (6*gay*(L - 2*xc))/(L*(gay*L^2 + 12*eiz)),                                         0,   0,                                                            0, (2*(- gay*L^2 + 3*gay*xc*L + 6*eiz))/(L*(gay*L^2 + 12*eiz))]];
        B([3 5],:)=-B([3 5],:);
        kel=kel+B'*D*B*L/2;
    end                 
    efforts=kel*R*S(ip);
    disp(num2str([ie n1 efforts(1: 6)'],'%-5.0f %-5.0f %-12.5g %-12.5g %-12.5g %-12.5g %-12.5g %-12.5g\n'))
    disp(num2str([ie n2 efforts(7:12)'],'%-5.0f %-5.0f %-12.5g %-12.5g %-12.5g %-12.5g %-12.5g %-12.5g\n'))
    disp(' ')
end

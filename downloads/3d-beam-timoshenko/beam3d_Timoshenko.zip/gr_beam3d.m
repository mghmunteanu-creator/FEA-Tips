% *** gr_beam3d ***
scale=input('Scale [Default: 1]: ');
if length(scale)==0; scale=1; end
x1=x+scale*u;
y1=y+scale*v;
z1=z+scale*w;
figure(5)
clf
hold on
grid on
axis('equal')
patch('Vertices',[x  y   z],'Faces',elem(:,1:2),'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b','linewidth',1.25)
patch('Vertices',[x1 y1 z1],'Faces',elem(:,1:2),'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','m','linewidth',1.25)
xlabel('x'),ylabel('y'),zlabel('z')
view(3)
drawnow
title('Blue - initial shape,  magenta - deformed beam')

# FEA Tips — Section 22.2

Large-displacement analysis of a 3D Euler–Bernoulli cantilever using finite differences.

Run `cantilever_3D.m` in MATLAB. This self-contained script defines the input data, iterates the beam configuration, reports the iteration count and residual, and plots the deformed centreline. No other program files are included or required.

Expected environment: desktop MATLAB R2024 or later with standard numerical and graphics functions; no additional toolbox is required by the script. This compatibility expectation is not a claim of testing in every release.

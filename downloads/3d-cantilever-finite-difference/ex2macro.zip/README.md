# FEA Tips — Section 22.2, Example 2

This is an ANSYS Mechanical APDL package, not a MATLAB program. It contains one file, `ex2macro.mac`; no separate support files are required.

The macro defines the clamped BEAM188 cantilever, material, rectangular section and end forces, then solves the static large-displacement problem. Units are mm, N and MPa (moments in N mm). Compare the deformed configuration and displacements with Example 2.

In a fresh Mechanical APDL model, set the working directory to the extracted folder and read `ex2macro.mac` as an input file, for example with `/INPUT,ex2macro,mac`. The macro creates and solves the model but does not include a postprocessing sequence. Use Mechanical APDL with BEAM188 support; a specific tested ANSYS release is not recorded for this package.

# Section 16.2 MATLAB programs

The package contains `main.m`, `gen1.m`, `gen2.m`, `stiff.m`, `deltaB.m`, `rot.m`, `plot_disp.m`, `plot_strain.m`, and `plot_stress.m`.

- `gen1.m` defines Example 1 (pure bending).
- `gen2.m` defines Example 2 (cantilever loaded by an end force).
- `main.m` calls `gen1` by default; replace that call with `gen2` to run Example 2.
- `plot_disp.m` plots displacement results.
- `plot_strain.m` plots strain results.
- `plot_stress.m` plots stress results.

The programs were tested in MATLAB R2026a. The plotting programs use `turbo`, which is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

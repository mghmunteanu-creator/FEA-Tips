% *** deltaB ***
% B derivative contribution:
for i=1:8
    p=zeros(2,4);
    p(i)=1;
    dJ=H*p';
    % derivative of b with respect of u_el:
    db=-J1*dJ*b;
    % Converting b derivative into B derivative:
    dBsig(:,i)=sg(1)*[db(1,1)       0     db(1,2)        0    db(1,3)        0    db(1,4)        0 ]+...
                 sg(2)*[     0    db(2,1)        0    db(2,2)        0    db(2,3)        0    db(2,4)]+...
                 sg(3)*[db(2,1)   db(1,1)   db(2,2)   db(1,2)   db(2,3)   db(1,3)   db(2,4)   db(1,4)];
end

% Contribution of the det(J):
x1=xdel(1); x2=xdel(2); x3=xdel(3); x4=xdel(4);
y1=ydel(1); y2=ydel(2); y3=ydel(3); y4=ydel(4);
ddJ=[y2 - y4 + s*y3 - s*y4 + t*y2 - t*y3
     x4 - x2 - s*x3 + s*x4 - t*x2 + t*x3
     y3 - y1 - s*y3 + s*y4 - t*y1 + t*y4
     x1 - x3 + s*x3 - s*x4 + t*x1 - t*x4
     y4 - y2 - s*y1 + s*y2 + t*y1 - t*y4
     x2 - x4 + s*x1 - s*x2 - t*x1 + t*x4
     y1 - y3 + s*y1 - s*y2 - t*y2 + t*y3
     x3 - x1 - s*x1 + s*x2 + t*x2 - t*x3];

ddetJ=sgnJ*ddJ*(B'*sg)'/8;

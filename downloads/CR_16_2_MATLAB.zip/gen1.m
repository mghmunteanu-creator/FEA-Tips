% *** gen1 ***
% pure bending
L=400;
H=30;
th=5;
E=1000;
nu=0.3;

nL=80;
nH=12;
%========================================
% Generation of the table "x"
dH=H/nH;
dL=L/nL;
nnd=(nL+1)*(nH+1);                    % number of nodes
neq=2*nnd;                            % number of nodal unknowns
nel=nL*nH;                          % number of finite elements
elem=zeros(nel,4);
inod=0;
xx=0;
for i=1:nL+1
   yy=0;
   for j=1:nH+1
      inod=inod+1;
      x(inod,1)=xx;
      y(inod,1)=yy;
      yy=yy+dH;
   end
   xx=xx+dL;
end
x0=x; y0=y;
%========================================
% Generation of the table "elem"
iel=0;
inod=0;
for i=1:nL
    for j=1:nH
        inod=inod+1;
        iel=iel+1;
        elem(iel,:)=[inod   inod+1  inod+nH+2 inod+nH+1];
   end
   inod=inod+1;
end
%========================================
% Generation of the table "cond"
ic=0;
for i=1:nH+1
    ic=ic+1;
    cond(ic,1)=i;
    cond(ic,2)=1;
end
ic=ic+1;
cond(ic,1)=nH/2+1;
cond(ic,2)=2;
%========================================
% Generation of the table "forze"
ang=75/180*pi;
for i=1:nH+1
   FFF=(i-nH/2-1)*102;
   forze(2*i-1,1)=nnd+1-i;
   forze(2*i-1,2)=1;
   forze(2*i-1,3)=FFF*cos(ang);
   forze(2*i  ,1)=nnd+1-i;
   forze(2*i  ,2)=2;
   forze(2*i  ,3)=FFF*sin(ang);
      if i==1 | i==nH+1
          forze(2*i-1,3)=FFF*cos(ang)/2;
          forze(2*i  ,3)=FFF*sin(ang)/2;
      end
end
patch('Vertices',[x y],'Faces',elem,'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b')    

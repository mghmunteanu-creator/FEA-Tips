% *** rot ***
% nodal coordinates of the current configuration (xdel, ydel):
xdel=xel+u([n1 n2 n3 n4]); 	
ydel=yel+v([n1 n2 n3 n4]); 
% Angle theta as arithmetic average of the angles between homologous sides 
% of initial and current configurations:
for i=1:4
    i1=mod(i,4)+1;
    dxy =[xel(i1)-xel(i)   yel(i1)-yel(i)   0];
    dxyd=[xdel(i1)-xdel(i) ydel(i1)-ydel(i) 0];
    cr=cross(dxyd,dxy);
    dt=dot(dxyd,dxy);
    thet(i)=atan2(cr(3),dt);
end
thetm=mean(thet);
% nodal coordinates of the corotational configuration (xyr):
cs=cos(thetm); sn=sin(thetm);
R=[cs sn; -sn cs];
xyr=R*[xel yel]';               
% corotated displacements:
sel=[xdel ydel]'-xyr;
sel=sel(:); 

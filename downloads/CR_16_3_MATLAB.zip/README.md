# Section 16.3 MATLAB package

This package accompanies Section 16.3, **Numerical evaluation of the tangent stiffness matrix**. The element tangent matrix is evaluated by central numerical differentiation of the element internal nodal force vector.

Run `main.m`. By default, it calls `gen1.m` and analyzes Example 1, the pure-bending problem. To run Example 2, replace the call `gen1` in `main.m` with `gen2`.

`gen1.m` corresponds to Example 1 of Section 16.2, and `gen2.m` corresponds to Example 2 of Section 16.2.

The package contains:

- `main.m` — nonlinear solution and load-step loop;
- `gen1.m` — Example 1, pure bending;
- `gen2.m` — Example 2, cantilever loaded by an end force;
- `stiff.m` — central numerical differentiation of the element internal nodal force vector;
- `fel_el.m` — evaluation of the element internal nodal force vector;
- `rot.m` — representative element rotation evaluated with `atan2` and the arithmetic mean of the four side rotations;
- `plot_disp.m`, `plot_strain.m`, and `plot_stress.m` — displacement, strain, and stress post-processing.

The central-difference perturbation is `dd=1e-5`. No analytical tangent-differentiation routine is required.

The programs were tested in MATLAB R2026a. The plotting programs use `turbo(16)`. `turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

%*** fel_el ***
% Compute the element internal nodal force vector felt for the current
% values of u and v.
% istore=1 - store strains and stresses
% istore=0 - do not store strains and stresses
rot
felt=zeros(8,1);
for j=1:4
    s=st(1,j);
    t=st(2,j);
    H=[(1+t)/4  -(1+t)/4  -(1-t)/4   (1-t)/4
       (1+s)/4   (1-s)/4  -(1-s)/4  -(1+s)/4];
    J=H*[xdel ydel];
    detJ=abs(det(J));
    J1=inv(J);
    b=J1*H;
    B=[b(1,1)       0    b(1,2)       0    b(1,3)       0    b(1,4)       0
           0    b(2,1)       0    b(2,2)       0    b(2,3)       0    b(2,4)
       b(2,1)   b(1,1)   b(2,2)   b(1,2)   b(2,3)   b(1,3)   b(2,4)   b(1,4)];
    strn=B*sel;
    sg=DHooke*strn;
    th1=(1-nu/(1-nu)*(strn(1)+strn(2)))*th;
    felt=felt+th1*(B'*sg)*detJ;
    if istore==1
        ig=4*(ie-1)+j;
        strnt(ig,:,istep)=strn';
        sigmt(ig,1:3,istep)=sg';
        sgr=R'*[sg(1) sg(3);sg(3) sg(2)]*R;
        sigmtr(ig,1:3,istep)=[sgr(1,1) sgr(2,2) sgr(1,2)];
    end
end

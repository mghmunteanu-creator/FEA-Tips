%*** stiff ***
% Numerical tangent stiffness using central finite differences
E1=E/(1-nu*nu);
E2=nu*E1;
G=E/2/(1+nu);
DHooke=[E1 E2 0
        E2 E1 0
         0  0 G];
F=zeros(neq,1);
K=zeros(neq);
% Gauss points:
st=[1  -1  -1   1
    1   1  -1  -1]*sqrt(3)/3;
u=S(1:2:neq);
v=S(2:2:neq);
dd=1e-5;                    % numerical differentiation perturbation
for ie=1:nel
    n1=elem(ie,1);
    n2=elem(ie,2);
    n3=elem(ie,3);
    n4=elem(ie,4);
    nod=[n1 n2 n3 n4];
    xel=[x(n1) x(n2) x(n3) x(n4)]';
    yel=[y(n1) y(n2) y(n3) y(n4)]';
    fel=zeros(8,1);
    kel=zeros(8);

    % Internal nodal force vector in the current configuration:
    istore=1;                % store strains and stresses
    fel_el
    fel=felt;

    % Central numerical differentiation of the element internal force:
    istore=0;                % do not store perturbed strains and stresses
    for ipert=1:8
        inod=ceil(ipert/2);

        % +dd perturbation:
        if rem(ipert,2)==1
            u(nod(inod))=u(nod(inod))+dd;
        else
            v(nod(inod))=v(nod(inod))+dd;
        end
        fel_el
        felp=felt;

        % Change from +dd to -dd:
        if rem(ipert,2)==1
            u(nod(inod))=u(nod(inod))-2*dd;
        else
            v(nod(inod))=v(nod(inod))-2*dd;
        end
        fel_el
        felm=felt;

        % Restore the unperturbed displacement:
        if rem(ipert,2)==1
            u(nod(inod))=u(nod(inod))+dd;
        else
            v(nod(inod))=v(nod(inod))+dd;
        end

        % Column ipert of the tangent stiffness matrix:
        kel(:,ipert)=(felp-felm)/(2*dd);
    end

    % Assembling process:
    ip=[2*n1-1 2*n1 2*n2-1 2*n2 2*n3-1 2*n3 2*n4-1 2*n4];
    F(ip)=F(ip)+fel;
    K(ip,ip)=K(ip,ip)+kel;
    eta_sym(ie)=norm(kel-kel','fro')/norm(kel,'fro');
end
% Constraints:
loc=2*(cond(:,1)-1)+cond(:,2);
K(loc,:)=0;
K(:,loc)=0;
F(loc)=0;
K(loc,loc)=eye(length(loc));
% External forces:
loc=2*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;

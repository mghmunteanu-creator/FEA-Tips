% *** gen ***
R1=100;
R2=500;
H=60;
E=1000;
nu=0.3;
p=0.035;
nL=72;
nH=12;
%========================================
% Generation of the table "x"
dH=H/nH;
dL=(R2-R1)/nL;
n=(nL+1)*(nH+1);          % number of nodes
nel=nL*nH;                % number of finite elements
neq=2*n;                  % number of equations (DOFs)
elem=zeros(nel,4);
inod=0;
xx=R1;
for i=1:nL+1
   yy=0;
   for j=1:nH+1
      inod=inod+1;
      x(inod,1)=xx;
      y(inod,1)=yy;
      yy=yy+dH;
   end
   xx=xx+dL;
end
%========================================
% Generation of the table "elem"
iel=0;
inod=0;
for i=1:nL
    for j=1:nH
        j1=rem(j,2);
        inod=inod+1;
        iel=iel+1;
        elem(iel,:)=[inod   inod+nH+1  inod+nH+2  inod+1];
   end
   inod=inod+1;
end
%========================================
% Generation of the table "cond"
ic=0;
for i=1:nH+1
    ic=ic+1;
    cond(ic,1)=i;
    cond(ic,2)=2;
end
%========================================
% Generation of the table "forze"
dF=p*H*R2/nH;
for i=1:nH+1
   forze(i,1)=n+1-i;
   forze(i,2)=2;
   forze(i,3)=dF;
   if i==1 | i==nH+1
      forze(i,3)=dF/2;
   end
end

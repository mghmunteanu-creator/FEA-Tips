% *** main ***
clear
format short e
gen
figure(5)
clf, hold on, grid on, axis('equal')
patch('Vertices',[x y],'Faces',elem,'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b')    
axis([0 650 -10 150])
sigmt=zeros(4*nel,5);
axisymm

plot_disp
plot_stress
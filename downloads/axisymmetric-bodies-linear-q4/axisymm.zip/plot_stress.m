% *** plot_stress ***
iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - does not plot
istress=input('Stress (1-sx, 2-sy, 3-st, 4-txy, 5-VM, Default=1): ');
if length(istress)==0; istress=1; end
scale=input('Scale (Default=0): ');
if length(scale)==0, scale=0; end   
u=S(1:2:neq);
v=S(2:2:neq);
x1=x+scale*u;
y1=y+scale*v;
ig=0;
for i=1:nel;
	n1=elem(i,1); n2=elem(i,2); n3=elem(i,3); n4=elem(i,4);
    ipos=[2*n1-1  2*n1  2*n2-1  2*n2  2*n3-1  2*n3  2*n4-1  2*n4]; 
    %----------------------------------------------------------------------
	xel=[x(n1) x(n2) x(n3) x(n4)]'; 	% nodal
	yel=[y(n1) y(n2) y(n3) y(n4)]'; 	% coordinates 
    uel=S(ipos);
	for j=1:4;
        ig=ig+1;
        s=st(1,j);
        t=st(2,j);
        H=[(1+t)/4  -(1+t)/4  -(1-t)/4  (1-t)/4
           (1+s)/4   (1-s)/4  -(1-s)/4 -(1+s)/4]; 	
        Nu=[(1+s)*(1+t) 0 (1-s)*(1+t) 0 (1-s)*(1-t) 0 (1+s)*(1-t) 0]/4;
        r=Nu(1:2:8)*xel;
        J=H*[ xel    yel];                  % Jacobian
        detJ=det(J);
        J1=inv(J);
        b=J1*H;
        Bux=[b(1,1)  0        b(1,2)   0        b(1,3)   0        b(1,4)   0     ];
        Buy=[b(2,1)  0        b(2,2)   0        b(2,3)   0        b(2,4)   0     ];
        Bvx=[0       b(1,1)   0        b(1,2)   0        b(1,3)   0        b(1,4)]; 
        Bvy=[0       b(2,1)   0        b(2,2)   0        b(2,3)   0        b(2,4)];  
        B=[Bux
           Bvy
           Nu/r
           Buy+Bvx];
       sgm=DHooke*B*uel;
       sgech=sqrt( sgm(1).^2+sgm(2).^2+sgm(3).^2-sgm(1).*sgm(2)-sgm(2).*sgm(3)-sgm(3).*sgm(1)+3*sgm(4).^2);
       sigmt(ig,:)=[sgm' sgech];
    end
end
%==========================================================================
strs=zeros(n,2);
isg=0;
for i=1:nel
    for j=1:4
        nod=elem(i,j);
        strs(nod,2)=strs(nod,2)+1;
        isg=isg+1;
        strs(nod,1)=strs(nod,1)+sigmt(isg,istress);
    end
end
stress=strs(:,1)./strs(:,2);
%==========================================================================
figure(15)
clf
hold on
axis('equal')
colormap(turbo(16))
smx=max(stress);
smn=min(stress);
if iedge==0
    patch('Vertices',[x1 y1],'Faces',elem,'CData',stress,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[x1 y1],'Faces',elem,'CData',stress,'Facecolor','interp','edgecolor','w')
end
colorbar
lighting phong
sigma_max=smx
sigma_min=smn
if istress==1
    title('\sigma_x')
elseif istress==2
    title('\sigma_y')   
elseif istress==3
    title('\sigma_\theta')   
elseif istress==4
    title('\tau_x_y')  
elseif istress==5
    title('\sigma_V_M')
end
axis([0 650 -10 150])

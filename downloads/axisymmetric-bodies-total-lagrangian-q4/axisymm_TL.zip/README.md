# FEA Tips — Section 28.3

Axisymmetric bodies: Total Lagrangian formulation with a four-node isoparametric element.

Run `main.m` in MATLAB. It calls `gen.m` for the toroidal-container mesh, material, constraints and loads, and `stiff.m` for the internal force vector and tangent stiffness. After the solution, run `plot_disp.m` or `plot_stress.m` to select a load step and result component. Displacement visualization defaults to scale 1; stress visualization defaults to scale 0.

Results for load step `istep` are stored and plotted at index `istep+1`; index 1 represents the initial state. The convergence check in `main.m` divides the squared displacement-increment norm by the number of equations (`neq`).

Mesh/Jacobian checks and the example solution were tested in MATLAB R2026a Update 4. No claim is made here that other MATLAB releases were executed.

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

% *** main ***
clear
format short e
nstep=20;            % number of load steps
itermax=50;          % maximum number of iterations
tol=1e-4;            % tolerance
figure(5)
clf, hold on, grid on, axis('equal')
gen
patch('Vertices',[x y],'Faces',elem,'Facecolor',[1 1 1],'linewidth',0.25,'edgecolor','c')    
drawnow
S =zeros(neq,1);
St=zeros(neq,nstep+1);
strnt=zeros(4*nel,4,nstep+1);
sigmt=zeros(4*nel,5,nstep+1);
for istep=1:nstep
    error=1;
    iter=0;
    while (error > tol) & (iter < itermax)
        iter=iter+1;
        stiff
        dS=K\F;
        S=S-dS;
        error=sqrt(dS'*dS/neq);
    end
    u=S(1:2:neq);
    v=S(2:2:neq);
    patch('Vertices',[x+u y+v],'Faces',elem,'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b')  
    [istep iter error]
    St(:,istep+1)=S;
    drawnow
end
% Compute Von Mises stress:
sgech=sqrt( sigmt(:,1,:).^2+sigmt(:,2,:).^2+sigmt(:,3,:).^2-...
            sigmt(:,1,:).*sigmt(:,2,:)-sigmt(:,2,:).*sigmt(:,3,:)-sigmt(:,3,:).*sigmt(:,1,:)+...
            3*sigmt(:,4,:).^2);
sigmt(:,5,:)=sgech;

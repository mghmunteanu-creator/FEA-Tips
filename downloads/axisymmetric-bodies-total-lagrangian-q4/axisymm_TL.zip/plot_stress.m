% *** plot_stress ***
iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - does not plot
istep=input('Load step (Default=nstep): ');
if length(istep)==0; istep=nstep; end
istress=input('Stress (1-sx, 2-sy, 3-st, 4-txy, 5-VM, Default=1): ');
if length(istress)==0; istress=1; end
scale=input('Scale (Default=0): ');
if length(scale)==0, scale=0; end   
u=St(1:2:neq,istep+1);
v=St(2:2:neq,istep+1);
disp(' ');
disp('Load step');
istep
%==========================================================================
strs=zeros(nnd,2);
isg=0;
for i=1:nel
    for j=1:4
        nod=elem(i,j);
        strs(nod,2)=strs(nod,2)+1;
        isg=isg+1;
        strs(nod,1)=strs(nod,1)+sigmt(isg,istress,istep+1);
    end
end
stress=strs(:,1)./strs(:,2);
%==========================================================================
xx1=x+scale*u;
yy1=y+scale*v;
figure(15)
clf
hold on
axis('equal')
colormap(turbo(16))
smx=max(stress);
smn=min(stress);
if iedge==0
    patch('Vertices',[xx1 yy1],'Faces',elem,'CData',stress,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[xx1 yy1],'Faces',elem,'CData',stress,'Facecolor','interp','edgecolor','w')
end
colorbar
lighting phong
sigma_max=smx
sigma_min=smn
titlu='\sigma_x\sigma_y\sigma_z\tau_x_yVM      ';
sss=titlu(8*(istress-1)+1:8*istress);
title({[sss,',   Load step ',num2str(istep)],;['min= ',num2str(smn),'  max=',num2str(smx)]})

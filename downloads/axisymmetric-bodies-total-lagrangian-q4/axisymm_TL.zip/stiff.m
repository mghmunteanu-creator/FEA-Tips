% *** stiff ***
E1 =E*(1-nu)/(1+nu)/(1-2*nu);
nu1=nu/(1-nu);
G=E/2/(1+nu);
DHooke=[    E1      nu1*E1     nu1*E1     0
        nu1*E1      E1         nu1*E1     0
        nu1*E1      nu1*E1         E1     0 
			 0           0          0     G ];
F=zeros(neq,1);
K=zeros(neq);
% Gauss points
st=[1  -1  -1   1
    1   1  -1  -1]*sqrt(3)/3;
ig=0;
for i=1:nel;
	n1=elem(i,1); n2=elem(i,2); n3=elem(i,3); n4=elem(i,4);
    ipos=[2*n1-1  2*n1  2*n2-1  2*n2  2*n3-1  2*n3  2*n4-1  2*n4]; 
    sel=S(ipos);
    %----------------------------------------------------------------------
	xel=[x(n1) x(n2) x(n3) x(n4)]'; 	% nodal
	yel=[y(n1) y(n2) y(n3) y(n4)]'; 	% coordinates 
    fel=zeros(8,1);
	kel=zeros(8);
	for j=1:4;
        ig=ig+1;
        s=st(1,j);
        t=st(2,j);
        H=[(1+t)/4  -(1+t)/4  -(1-t)/4  (1-t)/4
           (1+s)/4   (1-s)/4  -(1-s)/4 -(1+s)/4]; 	
        Nu=[(1+s)*(1+t) 0 (1-s)*(1+t) 0 (1-s)*(1-t) 0 (1+s)*(1-t) 0]/4;
        r=Nu(1:2:8)*xel; 
        J=H*[ xel    yel];                  % Jacobian
        detJ=det(J);
        J1=inv(J);
        b=J1*H;
        Bux=[b(1,1)  0        b(1,2)   0        b(1,3)   0        b(1,4)   0     ];
        Buy=[b(2,1)  0        b(2,2)   0        b(2,3)   0        b(2,4)   0     ];
        Bvx=[0       b(1,1)   0        b(1,2)   0        b(1,3)   0        b(1,4)]; 
        Bvy=[0       b(2,1)   0        b(2,2)   0        b(2,3)   0        b(2,4)];  
        ug=Nu*sel;
        ux=Bux*sel;
        uy=Buy*sel;
        vx=Bvx*sel;
        vy=Bvy*sel; 
        B0=[Bux
            Bvy
            Nu/r
            Buy+Bvx];
        
        % Green-Lagrange strains:
        ex =ux+ux^2/2+vx^2/2;
        ey =vy+uy^2/2+vy^2/2;
        ez =ug/r+ug^2/r^2/2;
        exy=uy+vx+ux*uy+vx*vy;
        
        Gx =Bux'*Bux+Bvx'*Bvx;
        Gy =Buy'*Buy+Bvy'*Bvy;
        Gz =Nu'*Nu/r^2;
        Gxy=Bux'*Buy+Bvx'*Bvy+Buy'*Bux+Bvy'*Bvx;
        BL=[sel'*Gx; sel'*Gy; sel'*Gz; sel'*Gxy];
         
        B=B0+BL;
        sigmt(ig,1:4,istep+1)=[ex ey ez exy]*DHooke;
    
        fel=fel+r*(B'*sigmt(ig,1:4,istep+1)')*detJ;
        kel=kel+r*(B'*DHooke*B+sigmt(ig,1,istep+1)*Gx+sigmt(ig,2,istep+1)*Gy+sigmt(ig,3,istep+1)*Gz+sigmt(ig,4,istep+1)*Gxy)*detJ;

        strnt(ig,:,istep+1)=[ex ey ez exy];
    end
    % assembling process:
    F(ipos)=F(ipos)+fel;
    K(ipos,ipos)=K(ipos,ipos)+kel;
end
% Constraints
loc=2*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 
% Concentrated force
loc=2*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;               

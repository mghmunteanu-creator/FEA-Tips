# Section 28.4 — Axisymmetric Q4: direct and consistent UL

Run `main.m` in MATLAB. It calls `gen.m` (mesh, material, constraints and fixed nodal loads) and `stiff_cons.m` (internal forces and consistent tangent). Use `plot_disp.m` and `plot_stress.m` for a selected load step.

Units: mm, N, MPa. Integration and MATLAB loads refer to one radian. The supplied default is 10 load steps. The 4- and 20-step examples were verified in MATLAB R2026a Update 4; no other release was executed. The five supplied MATLAB files are unchanged.

Stress components: radial, axial, circumferential, meridional shear, and von Mises. The first four are extrapolated from Gauss points and averaged at shared nodes; nodal von Mises is then calculated. Stored result index: load step + 1.

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

The ANSYS APDL macro is a separate download.

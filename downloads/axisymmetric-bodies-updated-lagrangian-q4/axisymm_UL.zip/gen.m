% *** gen ***
% Toroidal example from Section 28.3: x=radius, y=axis, ONE RADIAN.
% Preserve the original fixed nodal loads p*dL*x, including endpoints.
x=[]; y=[]; cond=[]; forze=[];
L=100;
R=50;
H=10;
r0=150;
E=1000;
nu=0.3;
p=2.5;
nL=36;
nR=30;
nH= 6;
%===========================================================
nnd=(nL+2*nR+1)*(nH+1);      	% number of nodes
nel=(nL+2*nR)*nH;           % number of finite elements
neq=2*nnd;                    % number of equations (DOFs)
elem=zeros(nel,4);
%==========================================================
% Generation of the table "x"
dH=H/nH;
dL=L/nL;
dR=pi/2*R/nR;
dang=pi/2/nR;
ang=0;
inod=0;
for i=1:nR
   yy=0;
   Rc=R;
   for j=1:nH+1
      inod=inod+1;
      x(inod,1)=R-Rc*cos(ang)+r0;
      y(inod,1)=Rc*sin(ang);
      yy=yy+dH;
      Rc=Rc+dH;
   end
   ang=ang+dang;
end

xx=0;
for i=1:nL+1
   yy=R;
   for j=1:nH+1
      inod=inod+1;
      x(inod,1)=xx+r0+R;
      y(inod,1)=yy;
      yy=yy+dH;
   end
   xx=xx+dL;
end
ang=0;
for i=1:nR
   ang=ang+dang;
   yy=0;
   Rc=R;
   for j=1:nH+1
      inod=inod+1;
      x(inod,1)=Rc*sin(ang)+L+R+r0;
      y(inod,1)=Rc*cos(ang);
      yy=yy+dH;
      Rc=Rc+dH;
   end
end
x0=x; y0=y;
%==========================================================
% Generation of the table "elem"
iel=0;
inod=0;
for i=1:nL+2*nR
    for j=1:nH
        j1=rem(j,2);
        inod=inod+1;
        iel=iel+1;
        elem(iel,:)=[inod   inod+nH+1  inod+nH+2  inod+1];
   end
   inod=inod+1;
end
%==========================================================
% Generation of the table "cond"
ic=0;
for i=1:nH+1
    ic=ic+1;
    cond(ic,1)=i;
    cond(ic,2)=2;
    ic=ic+1;
    cond(ic,1)=nnd-i+1;
    cond(ic,2)=2;
end
%==========================================================
% Generation of the table "forze"
ii=0;
in=1;
for i=1:nL+2*nR+1
   im=in+1;
   ang=-atan2(y(in)-y(im),x(im)-x(in));
   ff=p*dL*x(in);
   ii=ii+1;
   forze(ii,1)=in;
   forze(ii,2)=1;
   forze(ii,3)=ff*cos(ang);
   ii=ii+1;
   forze(ii,1)=in;
   forze(ii,2)=2;
   forze(ii,3)=ff*sin(ang);
   in=in+nH+1;
end
%==========================================================================
% Check the original local node order against the Q4 shape derivatives
assert(all(x0>0),'All radial coordinates must be positive.');
st=[1 -1 -1 1;1 1 -1 -1]*sqrt(3)/3;
minDetJ0=inf;
for ie=1:nel
    nodi=elem(ie,:);
    for j=1:4
        s=st(1,j); t=st(2,j);
        H=[1+t -1-t -1+t 1-t;1+s 1-s -1+s -1-s]/4;
        detJ0=det(H*[x0(nodi) y0(nodi)]);
        assert(detJ0>0,'Nonpositive reference Gauss Jacobian.');
        minDetJ0=min(minDetJ0,detJ0);
    end
end

%*** main ***
clear
format short e
nstep=10;             % number of load steps
tol=1e-4;            % displacement correction tolerance
tolF=1e-8;           % relative force residual tolerance
itermax=50;          % maximum number of iterations
igraph=1;            % 1 - plot successive configurations; 0 - no graphics
gen
if igraph==1
    figure(5)
    clf, hold on, grid on, axis('equal')
    patch('Vertices',[x y],'Faces',elem,'Facecolor',[1 1 1],'linewidth',0.25,'edgecolor','k')
    drawnow
end
St=zeros(neq,nstep+1);
strnt=zeros(4*nel,4,nstep+1);
sigmt=zeros(4*nel,5,nstep+1);
history=zeros(nstep,4);
for istep=1:nstep
    S=zeros(neq,1);             % displacements during the current load step
    errNR=1;
    errF=1;
    iter=0;
    stiff_cons
    while ((errNR > tol) | (errF > tolF)) & (iter < itermax)
        iter=iter+1;
        dS=K\F;
        S=S-dS;
        errNR=sqrt(dS'*dS/neq);
        x=x-dS(1:2:neq);
        y=y-dS(2:2:neq);
        % Recompute at the corrected trial geometry, including the last one.
        stiff_cons
        errF=norm(F)/max(1,norm(P(free)*istep/nstep));
    end
    if (errNR > tol) | (errF > tolF)
        error('FEATips:NewtonNotConverged','Load step %d did not converge.',istep);
    end
    if igraph==1
        patch('Vertices',[x y],'Faces',elem,'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b')
        drawnow
    end
    [istep iter errNR errF]
    St(:,istep+1)=St(:,istep)+S;
    history(istep,:)=[istep iter errNR errF];
end
% Compute von Mises stress (Cauchy stress components):
sgech=sqrt(((sigmt(:,1,:)-sigmt(:,2,:)).^2+...
            (sigmt(:,2,:)-sigmt(:,3,:)).^2+...
            (sigmt(:,3,:)-sigmt(:,1,:)).^2)/2+3*sigmt(:,4,:).^2);
sigmt(:,5,:)=sgech;
reactions=Fint-P;

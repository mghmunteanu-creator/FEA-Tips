%*** plot_disp ***
iedge=0;    % 1 - plot element contours; 0 - does not plot
istep=input('Load step (Default=nstep): ');
if isempty(istep), istep=nstep; end
idisp=input('Displacement (1-u radial, 2-v axial, Default=2): ');
if isempty(idisp), idisp=2; end
scale=input('Displacement scale (Default=1): ');
if isempty(scale), scale=1; end
load_step=istep
u=St(1:2:neq,istep+1);
v=St(2:2:neq,istep+1);
%==========================================================================
xc=x0+scale*u;
yc=y0+scale*v;
figure(10)
clf, hold on, axis('equal')
colormap(turbo(16));
displ=St(idisp:2:neq,istep+1);
dmx=max(displ);
dmn=min(displ);
if iedge==0
    patch('Vertices',[xc yc],'Faces',elem,'FaceVertexCData',displ,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[xc yc],'Faces',elem,'FaceVertexCData',displ,'Facecolor','interp','edgecolor','w')
end
colorbar
disp_max=dmx
disp_min=dmn
if idisp==1, sss='u_r'; else, sss='u_y'; end
xlabel('r'), ylabel('y')
title({[sss,',   Load step ',num2str(istep)];['min= ',num2str(dmn),'  max=',num2str(dmx)]})

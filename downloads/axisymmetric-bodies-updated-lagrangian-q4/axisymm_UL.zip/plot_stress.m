%*** plot_stress ***
iedge=0;    % 1 - plot element contours; 0 - does not plot
istep=input('Load step (Default=nstep): ');
if isempty(istep), istep=nstep; end
istress=input('Stress (1-sr, 2-sy, 3-stheta, 4-try, 5-VM, Default=1): ');
if isempty(istress), istress=1; end
scale=input('Displacement scale (Default=0): ');
if isempty(scale), scale=0; end
load_step=istep
u=St(1:2:neq,istep+1);
v=St(2:2:neq,istep+1);
xc=x0+scale*u;
yc=y0+scale*v;
%==========================================================================
% Extrapolation of all four stress components from Gauss points to nodes
% Bilinear interpolation in natural coordinates, in the original GP order
st=[1 -1 -1 1
    1  1 -1 -1]*sqrt(3)/3;
A=zeros(4);
for j=1:4
    s=st(1,j); t=st(2,j);
    A(j,:)=[(1+s)*(1+t) (1-s)*(1+t) (1-s)*(1-t) (1+s)*(1-t)]/4;
end
sigmti=zeros(4*nel,4);
ig=1;
for ie=1:nel
    sig0=sigmt(ig:ig+3,1:4,istep+1);
    sigmti(ig:ig+3,:)=A\sig0;
    ig=ig+4;
end
%==========================================================================
% Arithmetic average of stresses at nodes shared by several elements
strs=zeros(nnd,4);
count=zeros(nnd,1);
ig=0;
for i=1:nel
    for j=1:4
        nod=elem(i,j);
        count(nod)=count(nod)+1;
        ig=ig+1;
        strs(nod,:)=strs(nod,:)+sigmti(ig,:);
    end
end
for i=1:nnd
    strs(i,:)=strs(i,:)/count(i);
end
% Nodal von Mises from the four recovered stress components
strs(:,5)=sqrt(((strs(:,1)-strs(:,2)).^2+(strs(:,2)-strs(:,3)).^2+...
               (strs(:,3)-strs(:,1)).^2)/2+3*strs(:,4).^2);
stress=strs(:,istress);
%==========================================================================
% Graphic representation
figure(15)
clf, hold on, axis('equal')
colormap(turbo(16))
smx=max(stress);
smn=min(stress);
if iedge==0
    patch('Vertices',[xc yc],'Faces',elem,'FaceVertexCData',stress,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[xc yc],'Faces',elem,'FaceVertexCData',stress,'Facecolor','interp','edgecolor','w')
end
colorbar
sigma_max=smx
sigma_min=smn
names={'\sigma_r','\sigma_y','\sigma_\theta','\tau_{ry}','VM'};
sss=names{istress};
xlabel('r'), ylabel('y')
title({[sss,',   Load step ',num2str(istep)];['min= ',num2str(smn),'  max=',num2str(smx)]})

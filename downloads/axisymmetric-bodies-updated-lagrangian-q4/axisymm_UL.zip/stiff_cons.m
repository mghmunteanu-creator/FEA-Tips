%*** stiff_cons ***
% Axisymmetric Q4 UL - fully consistent tangent, one-radian sector.
% x = radius r; y = axial coordinate. Stress order: r, y, theta, ry.
E1=E*(1-nu)/(1+nu)/(1-2*nu);
E2=E*nu/(1+nu)/(1-2*nu);
G=E/2/(1+nu);
DHooke=[E1 E2 E2 0
        E2 E1 E2 0
        E2 E2 E1 0
         0  0  0 G];
F=zeros(neq,1);
K=zeros(neq);
assert(all(x0>0) && all(x>0),'Nodal radii must be positive.');
% Gauss points (same order as the local nodes)
st=[1 -1 -1 1
    1  1 -1 -1]*sqrt(3)/3;
ig=0;
minDetJ0=inf; minDetJ=inf; minr=inf;
for ie=1:nel
    nodi=elem(ie,1:4);
    ip=[2*nodi-1; 2*nodi]; ip=ip(:)';
    % Initial nodal coordinates
    xel0=x0(nodi);        yel0=y0(nodi);
    % Current trial nodal coordinates
    xelt=x(nodi);         yelt=y(nodi);
    fel=zeros(8,1);
    kel=zeros(8);
    for j=1:4
        ig=ig+1;
        s=st(1,j);
        t=st(2,j);
        N=[(1+s)*(1+t) (1-s)*(1+t) (1-s)*(1-t) (1+s)*(1-t)]/4;
        H=[(1+t)/4  -(1+t)/4  -(1-t)/4  (1-t)/4
           (1+s)/4   (1-s)/4  -(1-s)/4 -(1+s)/4];
        J0=H*[xel0 yel0];
        Jt=H*[xelt yelt];
        detJ0=det(J0);
        detJ=det(Jt);
        if (detJ0<=0) | (detJ<=0)
            error('FEATips:NonpositiveJacobian','Element %d, Gauss point %d.',ie,j);
        end
        r0g=N*xel0;
        r=N*xelt;
        assert(r0g>0 && r>0,'Gauss radii must be positive.');
        minDetJ0=min(minDetJ0,detJ0);
        minDetJ=min(minDetJ,detJ);
        minr=min(minr,r);
        J1=inv(Jt);
        b=J1*H;
        % B matrix (engineering shear strain)
        B=[b(1,1) 0      b(1,2) 0      b(1,3) 0      b(1,4) 0
           0      b(2,1) 0      b(2,2) 0      b(2,3) 0      b(2,4)
           N(1)/r 0      N(2)/r 0      N(3)/r 0      N(4)/r 0
           b(2,1) b(1,1) b(2,2) b(1,2) b(2,3) b(1,3) b(2,4) b(1,4)];
        % Total Euler-Almansi strains
        Ftot=(J0\Jt)';
        Q=inv(Ftot*Ftot');
        Qtheta=(r0g/r)^2;       % inverse square of hoop stretch r/r0g
        e=(eye(2)-Q)/2;
        ex=e(1,1); ey=e(2,2); et=(1-Qtheta)/2; exy=2*e(1,2);
        strnt(ig,:,istep+1)=[ex ey et exy];
        % Cauchy stress = DHooke * Euler-Almansi strain
        sigmt(ig,1:4,istep+1)=[ex ey et exy]*DHooke;
        sig=sigmt(ig,1:4,istep+1)';
        sigma=[sig(1) sig(4)
               sig(4) sig(2)];
        % Internal forces: volume per ONE RADIAN
        fel=fel+r*B'*sig*detJ;
        % Consistent material tangent
        BQ=zeros(4,8);
        for i=1:4
            ii=2*i-1:2*i;
            BQ([1 2 4],ii)=B([1 2 4],ii)*Q;
            BQ(3,ii)=[Qtheta*N(i)/r 0];
        end
        km=B'*DHooke*BQ;
        % Consistent geometric tangent (2 x 2 blocks)
        % Includes variation of detJ, r, the meridian gradients and N/r.
        % The two sigma_theta*N_i*N_k/r^2 terms cancel exactly.
        kg=zeros(8);
        er=[1;0];
        for i=1:4
            ii=2*i-1:2*i;
            bi=b(:,i);
            sbi=sigma*bi;
            for k=1:4
                kk=2*k-1:2*k;
                bk=b(:,k);
                kg(ii,kk)=sbi*bk'-(sigma*bk)*bi'+...
                          N(k)/r*sbi*er'+sig(3)*N(i)/r*er*bk';
            end
        end
        kel=kel+r*(km+kg)*detJ;
    end
    % Assembly
    F(ip)=F(ip)+fel;
    K(ip,ip)=K(ip,ip)+kel;
end
Fint=F;
% Concentrated forces: fixed nodal loads per radian, as in Section 28.3
P=zeros(neq,1);
for i=1:size(forze,1)
    loc=2*(forze(i,1)-1)+forze(i,2);
    P(loc)=P(loc)+forze(i,3);
end
F=F-P*istep/nstep;
% Constraints (after external loads)
loc=unique(2*(cond(:,1)-1)+cond(:,2));
free=setdiff((1:neq)',loc);
K(loc,:)=0; K(:,loc)=0; F(loc)=0;
K(loc,loc)=eye(length(loc));

# Section 28.4b — Simplified incremental axisymmetric UL

Run `main.m` from this folder. The supplied example uses 10 load steps; set `nstep` in `main.m` to 1, 2, 5 or 20 to reproduce the other rows of the comparison table.

- `gen.m`: toroidal-container geometry, Q4 connectivity, material, constraints and nodal forces.
- `stiff.m`: incremental element calculations, accumulated-strain transformation and global assembly for a one-radian sector.
- `plot_disp.m`: displacement maps after running `main.m`.
- `plot_stress.m`: radial, axial, circumferential, shear and von Mises stress maps using nodal averaging of the associated Gauss-point values.

Plotting defaults are the final load step, axial displacement (or radial stress), and deformation scale 1. Every prompt states its default. Select a different load step when required.

Executed in MATLAB R2026a with 1, 2, 5, 10 and 20 load steps. Older MATLAB releases have not been tested. `turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results. Both plotting routines already provide this fallback automatically.

The solver stops with an explicit error if a Jacobian is nonpositive or Newton iterations fail to converge. The incremental tangent is approximate; the final result depends on load-step refinement, as discussed in Section 28.4b.

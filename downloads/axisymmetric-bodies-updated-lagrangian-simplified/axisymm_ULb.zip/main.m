%*** main ***
clear
format short e
nstep=10;           % number of load steps
itermax=50;          % maximum number of iterations
tol=1e-4;            % tolerance
figure(5)
clf, hold on, grid on, axis('equal')
gen
patch('Vertices',[x y],'Faces',elem,'Facecolor',[1 1 1],'linewidth',0.25,'edgecolor','k')    
St=zeros(neq,nstep+1);
strnt=zeros(4*nel,4,nstep+1);
sigmt=zeros(4*nel,5,nstep+1);
for istep=1:nstep
    S=zeros(neq,1);
    errNR=1;
    iter=0;
    while (errNR > tol) & (iter < itermax)
        iter=iter+1;
        stiff
        dS=K\F;
        S=S-dS;
        errNR=sqrt(dS'*dS/nnd);
    end
    if ~isfinite(errNR) || errNR>tol
        error('UL:Nonconvergence','Load step %d did not converge after %d iterations (increment norm %g).',istep,iter,errNR);
    end
    x=x+S(1:2:neq);
    y=y+S(2:2:neq);
    patch('Vertices',[x y],'Faces',elem,'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b')    
    [istep iter errNR]
    St(:,istep+1)=St(:,istep)+S;
    pause(0.01)
end
% Compute von Mises stress:
sgech=sqrt( sigmt(:,1,:).^2+sigmt(:,2,:).^2+sigmt(:,3,:).^2-...
            sigmt(:,1,:).*sigmt(:,2,:)-sigmt(:,2,:).*sigmt(:,3,:)-sigmt(:,3,:).*sigmt(:,1,:)+...
            3*sigmt(:,4,:).^2);
sigmt(:,5,:)=sgech;

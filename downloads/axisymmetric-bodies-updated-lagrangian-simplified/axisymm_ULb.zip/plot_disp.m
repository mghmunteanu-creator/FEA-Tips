%*** plot_disp ***
iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - hide element edges
istep=input(sprintf('Load step [Default: %d]: ',nstep));   
if isempty(istep), istep=nstep; end           
idisp=input('Displacement (1-u radial, 2-v axial) [Default: 2]: ');
if isempty(idisp), idisp=2; end           
scale=input('Displacement scale [Default: 1]: ');
if isempty(scale), scale=1; end   
u=St(1:2:neq,istep+1);
v=St(2:2:neq,istep+1);
disp(' ');
disp('Load step');
istep
%===================================
x1=x0+scale*u;
y1=y0+scale*v;
figure(10)
clf
hold on
axis('equal')
if exist('turbo','file')
    colormap(turbo(16));
else
    colormap(jet(16));
end
displacement=St(idisp:2:neq,istep+1);
dmx=max(displacement);
dmn=min(displacement);
if iedge==0
    patch('Vertices',[x1 y1],'Faces',elem,'CData',displacement,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[x1 y1],'Faces',elem,'CData',displacement,'Facecolor','interp','edgecolor','w')
end
colorbar
disp_max=dmx
disp_min=dmn
if idisp==1
    title({['u',',   Load step ',num2str(istep)];['min= ',num2str(dmn),'  max=',num2str(dmx)]})
elseif idisp==2
    title({['v',',   Load step ',num2str(istep)];['min= ',num2str(dmn),'  max=',num2str(dmx)]})   
end
drawnow

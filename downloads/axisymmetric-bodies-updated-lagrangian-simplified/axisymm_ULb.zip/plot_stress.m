%*** plot_stress ***
iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - hide element edges
istep=input(sprintf('Load step [Default: %d]: ',nstep));
if isempty(istep); istep=nstep; end
istress=input('Stress (1-radial, 2-axial, 3-circumferential, 4-shear, 5-von Mises) [Default: 1]: ');
if isempty(istress); istress=1; end
scale=input('Displacement scale [Default: 1]: ');
if isempty(scale), scale=1; end   
u=St(1:2:neq,istep+1);
v=St(2:2:neq,istep+1);
disp(' ');
disp('Load step');
istep
%==========================================================================
strs=zeros(nnd,2);
isg=0;
for i=1:nel
    for j=1:4
        nod=elem(i,j);
        strs(nod,2)=strs(nod,2)+1;
        isg=isg+1;
        strs(nod,1)=strs(nod,1)+sigmt(isg,istress,istep+1);
    end
end
stress=strs(:,1)./strs(:,2);
%==========================================================================
x1=x0+scale*u;
y1=y0+scale*v;
figure(15)
clf
hold on
axis('equal')
if exist('turbo','file')
    colormap(turbo(16));
else
    colormap(jet(16));
end
smx=max(stress);
smn=min(stress);
if iedge==0
    patch('Vertices',[x1 y1],'Faces',elem,'CData',stress,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[x1 y1],'Faces',elem,'CData',stress,'Facecolor','interp','edgecolor','w')
end
colorbar
sigma_max=smx
sigma_min=smn
if istress==1
    title({['Radial stress \sigma_r',',   Load step ',num2str(istep)];['min= ',num2str(smn),'  max=',num2str(smx)]})
elseif istress==2
    title({['Axial stress \sigma_y',',   Load step ',num2str(istep)];['min= ',num2str(smn),'  max=',num2str(smx)]})
elseif istress==3
    title({['Circumferential stress \sigma_\theta',',   Load step ',num2str(istep)];['min= ',num2str(smn),'  max=',num2str(smx)]})
elseif istress==4
    title({['Radial-axial shear stress \tau_{ry}',',   Load step ',num2str(istep)];['min= ',num2str(smn),'  max=',num2str(smx)]})
elseif istress==5
    title({['von Mises equivalent stress',',   Load step ',num2str(istep)];['min= ',num2str(smn),'  max=',num2str(smx)]})
end
drawnow

# ANSYS verification model

This package accompanies Example 1 in Chapter 6 of FEA Tips.

`ansys.txt` is an ANSYS Mechanical APDL input macro using the BEAM188 element, a 5 mm × 1 mm rectangular section, `E = 2e5 MPa`, large-deformation analysis (`NLGEOM,1`), and 50 load substeps.

The macro uses symmetry and models one half of the 100 mm double-clamped beam. The midpoint is therefore represented by the free end of the half-model, where the symmetry conditions `UX = 0` and `ROTZ = 0` are applied. Half of the total midpoint force is used: 50 N in the macro corresponds to the 100 N force in the full-beam MATLAB model.

To run it, open ANSYS Mechanical APDL and read `ansys.txt` as an input file. The package is provided for independent comparison with the MATLAB results; ANSYS was not available in the local verification environment used for this website update.

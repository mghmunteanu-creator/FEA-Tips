# Nonlinear double-clamped beam — MATLAB programs

This package accompanies Chapter 6 of FEA Tips. It implements a two-node cubic Euler–Bernoulli beam element with the moderately large-displacement axial strain

`epsilon_0 = du/dx + 0.5*(dv/dx)^2`

and curvature `kappa = d^2v/dx^2`. The nonlinear equilibrium equations are solved incrementally by the Newton–Raphson method.

## Run the supplied double-clamped example

1. Place all `.m` files in one folder and make it the current MATLAB folder.
2. Run `main`.
3. When requested, enter a load-step number from `0` to `50` to print nodal results.

The supplied data in `gen.m` define a 100 mm double-clamped beam with a 5 mm × 1 mm rectangular cross-section, `E = 2e5 MPa`, 100 finite elements, and a 100 N downward midpoint force applied in 50 steps.

The final-step calculation gives approximately:

- midpoint displacement: `v_C = -1.86555 mm` (`|v_C|/d = 0.0186555`);
- constant axial-force ratio: `N/F = 8.01210`.

## Files

- `main.m` — analysis driver and Newton–Raphson loop;
- `gen.m` — geometry, material data, mesh, constraints, and load;
- `deriv.m` — strain and curvature derivatives;
- `stiff.m` — element residual, tangent stiffness, assembly, constraints, and loads;
- `stress.m` — axial force and bending moment recovery at Gauss points;
- `diagrams.m` — force–displacement and internal-force diagrams;
- `print_results.m` — tabular nodal displacements and element resultants.

## Cantilever comparison in Chapter 6

To reproduce the 40-element cantilever value quoted in Example 2, use `F0 = -4`, `nel = 40`, retain only the three constraints at node 1, set `nf = nnd`, and apply the vertical load at node `nf`. The program then gives `|v_max|/L = 0.142371` and `phi_max = 0.209692 rad`.

## Compatibility

Tested in MATLAB R2024a. The code uses standard MATLAB syntax and is expected to be compatible with newer MATLAB versions. No additional toolbox is required.

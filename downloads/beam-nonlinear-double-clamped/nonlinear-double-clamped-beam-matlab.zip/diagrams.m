%*** diagrams ***
vmx=St(3*nf-1,:);
FF=[0:nstep]*F0/nstep;
figure(10)
clf, hold on, grid on
plot(abs(vmx/Lb),abs(FF)*Lb^2/EI,'b','linewidth',1.5)
xlabel('v_C/d')
ylabel('Fd^2/EI')
title('Load versus maximum  v displacement')

figure(20)
clf, hold on, grid on, 
plot(abs(vmx/Lb),mean(N)*Lb^2/EI,'b','linewidth',1.5)
xlabel('v_C/d')
ylabel('Nd^2/EI')
title('Axial effort N versus maximum  v displacement')

figure(40);clf, hold on, grid on
ss=L/2:L:Lb;
NN=(N(1:2:2*nel,nstep+1)+N(2:2:2*nel,nstep+1))/2;
plot(ss/Lb,NN/abs(F0),'b','linewidth',1.5)
xlabel('x/d')
ylabel('N/F')
title('Axial effort')
nm=mean(NN)/abs(F0);
axis([0 1 nm*0.9 nm*1.1])

lg=sqrt(3)/3*L;
TT=reshape(M(:,nstep+1),2,nel)';T=(TT(:,1)-TT(:,2))/lg;
figure(45);clf, hold on, grid on
plot([L/2:L:Lb]/Lb,T/abs(F0),'b','linewidth',1.5)
xlabel('x/d')
ylabel('T/F')
title('Shear effort')

figure(50)
clf, hold on, grid on
plot(sgs/Lb,M(:,nstep+1)/Lb/abs(F0),'b','linewidth',1.5)
xlabel('x/d')
ylabel('M/(Fd)')
title('Bending moment diagram')



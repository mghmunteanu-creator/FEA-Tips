%*** gen ***
F0=-100;               % force
Lb=100;                % length of beam
width=5;               % width of cross-section
t=1;                   % thickness of cross-section
E=2e5;                 % Young modulus
EI=E*width*t^3/12;
EA=E*width*t;
nel=100;               % number of finite elements
nnd=nel+1;             % number of nodes
neq=3*nnd;
L=Lb/nel;              % length of one finite element
Lt=ones(nel,1)*L;
x=[0:L:Lb+L/100]';     % nodal coordinates
y=x*0;
elem=[1:nel; 2:nnd]';  % finite elements
cond=[1    1           % boundary constraints
      1    2
      1    3
      nnd  1
      nnd  2
      nnd  3];

nf=nel/2+1; 
forze=[nf 2 F0];     % load

%*** main ***
clear
format short e
gen
nstep=50;               % number of load steps
tol=1e-5;               % tolerance
itermax=50;             % max number of iterations
S=zeros(neq,1);         % nodal displacements in current load step
St=zeros(neq,nstep+1);  % nodal displacements in all load steps
N=zeros(2*nel,nstep+1); % axial effort
M=zeros(2*nel,nstep+1); % bending moment
figure(5), clf, hold on, grid on, axis('equal')
plot(x/Lb,y/Lb,'k','linewidth',1)
drawnow
title('Deformed beam')
xlabel('x/d')
ylabel('y/d')
for istep=1:nstep
    error=1;
    iter=0;
    while (error > tol) & (iter < itermax)
        iter=iter+1;
        stiff
        dS=K\F;
        S=S-dS;
        error=sqrt(dS'*dS/nnd);    
    end
    stress
    plot((x+S(1:3:neq))/Lb,(y+S(2:3:neq))/Lb,'b','linewidth',1)
    drawnow
    [istep iter error]
    St(:,istep+1)=S;
    pause(0.01)
end
u=S(1:3:neq);
v=S(2:3:neq);
xx=x+u;
yy=y+v;
diagrams
print_results

%*** print_results ***
% results: nodal displacements and efforts:
ist=input('Number of the load step: ');
if length(ist)==0, ist=nstep; end
disp('  ')
disp(['Load step: ',num2str(ist)]);
S=St(:,ist+1);
Nc=N(:,ist+1); Nm=sum(reshape(Nc,2,nel))/2;
Mc=M(:,ist+1); Mm=sum(reshape(Mc,2,nel))/2;
TT=reshape(Mc,2,nel);Tm=(TT(1,:)-TT(2,:))/lg;

disp('  ')
disp('Node  u            v            phi')
disp(num2str([[1:nnd]' S(1:3:neq) S(2:3:neq) S(3:3:neq)],'%-5.0f %-12.5g %-12.5g %-12.5g\n'));

disp('  ')
disp('Node  N            T            M')
disp(num2str([[1:nel]; Nm; Tm; Mm]','%-5.0f %-12.5g %-12.5g %-12.5g\n'));

%*** stiff ***
xg=[-sqrt(3)/3 sqrt(3)/3];
F=zeros(neq,1);
K=zeros(neq);
ii=0;
for ie=1:nel
    n1=elem(ie,1);
    n2=elem(ie,2);
    L=Lt(ie);
    ip=[3*n1-2 3*n1-1 3*n1 3*n2-2 3*n2-1 3*n2];
    uel=S(ip);
    fel=zeros(6,1);
    kel=zeros(6);
    for ig=1:2 
        ii=ii+1;
        xc=1/2*(1+xg(ig));          % Gauss points
        sgs(ii)=xc+sum(Lt(1:ie))-L; % x coordinates of the Gauss points
        deriv
        fel=fel+L/2*(EA*ep*ep1+EI*ka*ka1);
        kel=kel+L/2*(EA*(ep*ep2+ep1*ep1')+EI*ka1*ka1');
    end
    F(ip)=F(ip)+fel;
    K(ip,ip)=K(ip,ip)+kel;
end
% Constraints
loc=3*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 
% Concentrated forces
loc=3*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;

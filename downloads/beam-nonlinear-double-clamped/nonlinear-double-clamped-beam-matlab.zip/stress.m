%*** stress ***
ii=0;
for ie=1:nel
    n1=elem(ie,1);
    n2=elem(ie,2);
    L=Lt(ie);
    ip=[3*n1-2 3*n1-1 3*n1 3*n2-2 3*n2-1 3*n2];
    uel=S(ip);
    for ig=1:2     	
        ii=ii+1;
        xc=1/2*(1+xg(ig));          % Gauss points
        Nux=[-1/L         0                  0          1/L       0                   0      ];
        Nvx=[  0    (-6*xc+6*xc*xc)/L   1-4*xc+3*xc*xc   0   (6*xc-6*xc*xc)/L   -2*xc+3*xc*xc];
        Nka=[  0    (12*xc-6)/L/L       (6*xc-4)/L       0   (6-12*xc)/L/L      (6*xc-2)/L ]; 
        ep=Nux*uel   +1/2*(Nvx*uel)^2;
        ka=Nka*uel;
        N(ii,istep+1)=EA*ep;
        M(ii,istep+1)=EI*ka;
    end
end   

# Section 5.1 — Two-node Euler–Bernoulli beam element

Run `main.m` from this folder. The program creates a curved cantilever-beam
model, assembles the global stiffness matrix using two-point Gauss integration,
solves the linear system, and plots the deformed beam together with the axial
force, transverse force, and bending-moment diagrams.

## Files

- `main.m` — runs the analysis and produces the plots;
- `gen.m` — defines geometry, material data, nodal loads, constraints, and
  element reference frames;
- `deriv.m` — evaluates the axial-strain and curvature rows;
- `stiff.m` — forms the element stiffness matrices and assembles the global
  system;
- `stress.m` — recovers the axial force `N`, transverse force `T`, and bending
  moment `M_z`.

The analysis is performed in the global `xy` plane. In this planar setting,
`T` and `T_y` denote the same transverse force component, while `M` and `M_z`
denote the same bending moment component.

Tested in MATLAB R2024a. The code uses standard MATLAB syntax and is expected
to be compatible with newer MATLAB versions. No additional toolbox is required.

%*** deriv ***
% Axial-strain and curvature-displacement matrices.
% The curvature convention is kappa_z = d^2(v)/d(x)^2.
Bux=[-1/L       0                0       1/L       0                  0     ];
Bka=[ 0   (12*xc-6)/L^2   (6*xc-4)/L    0   (-12*xc+6)/L^2   (6*xc-2)/L ];
ep1=Bux';
ka1=Bka';

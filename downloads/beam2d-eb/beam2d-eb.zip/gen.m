%*** gen ***
%==========================================================================
% Generate the input data for a curved cantilever beam:
%   radius - radius of the curved beam
%   E      - Young's modulus
%   A      - cross-sectional area
%   Iz     - second moment of area about the z axis
%   V      - vertical force applied at the free end
%   H      - horizontal force applied at the free end
%==========================================================================
% x, y  nodal coordinates
%        
% elem   element connectivity:
%        [node1  node2
%         :      :   ]
%
% cond   nodal constraints:
%        direction 1 = x displacement
%        direction 2 = y displacement
%        direction 3 = rotation about the z axis
%        [node  direction
%         :     :        ]
%
% loads  nodal loads:
%        [node  direction  value
%         :     :          :    ]
%==========================================================================
V=10;          % vertical force
H=20;          % horizontal force
radius=50;     % radius of the curved beam
width=5;       % width of the rectangular cross-section
t=1;           % thickness of the rectangular cross-section
E=2e5;         % Young's modulus

nnd=101;       % number of nodes
nel=nnd-1;     % number of beam elements
neq=3*nnd;     % number of equations
%--------------------------------------------------------------------------
A=width*t;
Iz=width*t^3/12;
ea=E*A;
ei=E*Iz;
Lb=pi*radius/2;
%==========================================================================
% nodal coordinates
da=pi/2/nel;
a=0;
for i=1:nnd
    x(i,1)=radius*(1-cos(a));
    y(i,1)=radius*sin(a);
    a=a+da;
end
%==========================================================================
% beam elements
n1=1:nel; n2=n1+1;
elem=[n1' n2'];
%==========================================================================
cond=[ 1 1
       1 2
       1 3];
%==========================================================================
loads=[nnd 2 V
       nnd 1 H];
%==========================================================================
% Rotation matrices from global to local element coordinates
Rt=zeros(6,6,nel);
for ie=1:nel
    n1=elem(ie,1);
    n2=elem(ie,2);
    dx=x(n2)-x(n1);
    dy=y(n2)-y(n1);
    L=sqrt(dx^2+dy^2);
    cs=dx/L;            
    sn=dy/L;
    Lt(ie)=L;
    Rt(:,:,ie)=[ cs sn  0   0   0  0            
                -sn cs  0   0   0  0
                  0  0  1   0   0  0
                  0  0  0  cs  sn  0
                  0  0  0 -sn  cs  0
                  0  0  0   0   0  1];
end

%*** main ***
clear
format short e
gen
stiff
S=K\F;
stress

figure(5), clf, hold on, grid on, axis('equal')
title('Beam centerline: undeformed (blue), deformed (red)')
xlabel('x/L')
ylabel('y/L')
plot(x/Lb,y/Lb,'b','linewidth',1)
plot((x+S(1:3:neq))/Lb,(y+S(2:3:neq))/Lb,'r','linewidth',1)
%==========================================================================
% Nodal displacements and stress resultants
disp('  ')
disp('Node  u            v            phi_z')
disp(num2str([[1:nnd]' S(1:3:neq) S(2:3:neq) S(3:3:neq)],'%-5.0f %-12.5g %-12.5g %-12.5g\n'));

disp('  ')
disp('Node  N            T            M')
disp(num2str([[1:nnd]; Ni; Ti; Mi]','%-5.0f %-12.5g %-12.5g %-12.5g\n'));
%--------------------------------------------------------------------------
% Stress-resultant diagrams
s=[0 cumsum(Lt)];
% Axial-force diagram
figure(10), clf, hold on, grid on
plot(s,Ni,'linewidth',1.5)
xlabel('s [mm]')
ylabel('Axial force N [N]')
title('Axial force')

% Shear-force diagram
figure(15), clf, hold on, grid on
plot(s,Ti,'linewidth',1.5)
xlabel('s [mm]')
ylabel('Shear force T [N]')
title('Shear force')

% Bending-moment diagram
figure(20), clf, hold on, grid on
plot(s,Mi,'linewidth',1.5)
xlabel('s [mm]')
ylabel('Bending moment M_z [N mm]')
title('Bending moment')

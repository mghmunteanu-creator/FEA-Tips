%*** stiff ***
% Assemble the global stiffness matrix by two-point Gauss integration.
xg=[-sqrt(3)/3 sqrt(3)/3];
F=zeros(neq,1);
K=zeros(neq);
for ie=1:nel
    Re=Rt(:,:,ie);
    n1=elem(ie,1);
    n2=elem(ie,2);
    L=Lt(ie);           % length of the beam element
    ipos=[3*n1-2 3*n1-1 3*n1 3*n2-2 3*n2-1 3*n2];
    kel=zeros(6);
    for ig=1:2 
        xc=1/2*(1+xg(ig));
        deriv
        kel=kel+L/2*(ea*ep1*ep1'+ei*ka1*ka1');
    end
    K(ipos,ipos)=K(ipos,ipos)+Re'*kel*Re;
end
% Apply zero prescribed displacements.
loc=3*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 
% Apply concentrated nodal loads.
loc=3*(loads(:,1)-1)+loads(:,2);
F(loc)=F(loc)+loads(:,3);

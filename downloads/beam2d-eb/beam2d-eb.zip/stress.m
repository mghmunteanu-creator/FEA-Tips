%*** stress ***
% Recover the axial force and bending moment at the Gauss points.
for ie=1:nel
    n1=elem(ie,1);
    n2=elem(ie,2);
    L=Lt(ie);
    Re=Rt(:,:,ie);
    ipos=[3*n1-2 3*n1-1 3*n1 3*n2-2 3*n2-1 3*n2];
    uel=Re*S(ipos);
    for ig=1:2     	
        xc=1/2*(1+xg(ig));
        deriv
        ep(ig)=Bux*uel;
        ka(ig)=Bka*uel;
    end
    N(ie)=ea*mean(ep);
    M(ie)=ei*mean(ka);
end
% Interpolate/extrapolate the element values to the nodes.
Ni=interp1(0.5:nel,N,0:nel,'PCHIP','extrap');
Mi=interp1(0.5:nel,M,0:nel,'PCHIP','extrap');
% The beam convention is dM_z/ds = -T_y.
s=[0 cumsum(Lt)];
T=-diff(Mi)./diff(s);
Ti=interp1(0.5:nel,T,0:nel,'PCHIP','extrap');
% Round the tabulated and plotted values to two decimal places.
p=1e2;
Ni=round(Ni*p)/p; Ti=round(Ti*p)/p; Mi=round(Mi*p)/p;

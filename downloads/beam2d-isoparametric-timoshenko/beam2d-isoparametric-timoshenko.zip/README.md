# Section 5.3 — Isoparametric two-node Timoshenko beam element

Run `main.m` from this folder. The program builds the linear beam model,
assembles the isoparametric element stiffness, solves the system, and plots
the deformed beam and the internal resultants.

## Files

- `main.m` — runs the analysis and produces the plots;
- `gen.m` — geometry, material data, loads, constraints, and local frames;
- `stiff.m` — one-point Gauss integration with the correction factor
  `gamma`, followed by global assembly;
- `stress.m` — recovery of the axial force `N`, shear force `T`, and bending
  moment `M`.

Here `varphi` is the rotation of the normal, `psi` is the cross-section
rotation, and `beta = varphi - psi` is the shear angle. The correction factor
`gamma` removes the excessive shear stiffness associated with the basic
one-point element. MATLAB R2017b-compatible syntax is used; the package was
checked with MATLAB R2026a. No additional toolbox is required.

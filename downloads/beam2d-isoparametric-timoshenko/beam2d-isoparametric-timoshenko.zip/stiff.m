%*** stiff.m ***
xg=[-sqrt(3)/3 sqrt(3)/3];
F=zeros(neq,1);
K=zeros(neq);
for ie=1:nel
    R=Rt(:,:,ie);
    n1=elem(ie,1);
    n2=elem(ie,2);
    L=Lt(ie);               % length of the beam element
    ip=[3*n1-2 3*n1-1 3*n1 3*n2-2 3*n2-1 3*n2];
    gamma=12*ei/(L^2*ga + 12*ei);
    gac=gamma*ga;
    % isoparametric 2-node Timoshenko beam element, one Gauss point integration
    kel=[[  ea/L,     0,                        0, -ea/L,     0,                        0]
         [     0, gac/L,                    gac/2,     0, -gac/L,                    gac/2]
         [     0, gac/2, (gac*L^2 + 4*ei)/(4*L),     0, -gac/2, -(-gac*L^2 + 4*ei)/(4*L)]
         [ -ea/L,     0,                        0,  ea/L,     0,                        0]
         [     0, -gac/L,                   -gac/2,     0, gac/L,                   -gac/2]
         [     0, gac/2, -(-gac*L^2 + 4*ei)/(4*L),     0, -gac/2,   (gac*L^2 + 4*ei)/(4*L)]];
    K(ip,ip)=K(ip,ip)+R'*kel*R;
end
% Constraints
loc=3*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 
% Concentrated forces
loc=3*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)+forze(:,3);               

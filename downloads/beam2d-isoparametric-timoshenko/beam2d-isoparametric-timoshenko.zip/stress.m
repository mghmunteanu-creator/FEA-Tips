%*** stress.m ***
s=0;
for ie=1:nel
    n1=elem(ie,1);
    n2=elem(ie,2);
    L=Lt(ie);
    R=Rt(:,:,ie);
	ip=[3*n1-2 3*n1-1 3*n1 3*n2-2 3*n2-1 3*n2];
    uel=R*S(ip);
    Bux=[-1/L       0            0     1/L       0           0];
    Bbe=[   0,    -1/L,   -(1-s)/2,      0,    1/L    -(1+s)/2];
    Bka=[   0,      0,        -1/L,      0,      0         1/L];
    ep=Bux*uel;
    be=Bbe*uel;
    ka=Bka*uel;
    N(ie,1)=ea*ep;
    gamma=12*ei/(L^2*ga + 12*ei);
    T(ie,1)=gamma*ga*be;
    M(ie,1)=ei*ka;
end
% interpolation
Ni=interp1(0.5:nel,N,0:nel,'PCHIP','extrap');
Ti=interp1(0.5:nel,T,0:nel,'PCHIP','extrap');
Mi=interp1(0.5:nel,M,0:nel,'PCHIP','extrap');
p=1e2;
Ni=round(Ni*p)/p; Ti=round(Ti*p)/p; Mi=round(Mi*p)/p;

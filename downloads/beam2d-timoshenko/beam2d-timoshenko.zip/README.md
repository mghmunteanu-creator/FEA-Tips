# Section 5.2 — Two-node Timoshenko beam element

Run `main.m` from this folder. It creates the model, assembles the global
stiffness matrix by two-point Gauss integration, solves the linear system,
and plots the deformed beam and the internal resultants.

## Files

- `main.m` — runs the analysis and produces the plots;
- `gen.m` — geometry, material data, loads, constraints, and local frames;
- `deriv.m` — generalized strain-displacement rows;
- `stiff.m` — element stiffness and global assembly;
- `stress.m` — recovery of the axial force `N`, shear force `T`, and bending
  moment `M`.

The program uses the Timoshenko generalized strains
`epsilon_0`, `beta`, and `kappa`, with the generalized stresses `N`, `T`,
and `M`. MATLAB R2017b-compatible syntax is used; the package was checked
with MATLAB R2026a. No additional toolbox is required.

%*** deriv.m ***
dd=(ga*L^2 + 12*ei);
Bux=[-1/L         0                  0          1/L       0                   0      ];
Bbe=[   0,         -(12*ei)/L,                           -(6*ei),   0,          (12*ei)/L,                          -(6*ei)]/dd;
Bka=[   0, (6*ga*(2*xc - 1)) , -((4*ga - 6*ga*xc)*L^2 + 12*ei)/L,   0, -(6*ga*(2*xc - 1)), ((6*ga*xc - 2*ga)*L^2 + 12*ei)/L]/dd;
    
ep1=Bux';
be1=Bbe';
ka1=Bka';

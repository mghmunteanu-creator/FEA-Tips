%*** main.m ***
clear
format short e
gen
stiff
S=K\F;
stress

figure(5), clf, hold on, grid on, axis('equal')
title('The beam: blue - not deformed, red - deformed')
xlabel('x/Lb')
ylabel('y/Lb')
plot(x/Lb,y/Lb,'b','linewidth',1)
plot((x+S(1:3:neq))/Lb,(y+S(2:3:neq))/Lb,'r','linewidth',1)
%==========================================================================
% results: nodal displacements and efforts
disp('  ')
disp('Node  u            v            phi')
disp(num2str([[1:nnd]' S(1:3:neq) S(2:3:neq) S(3:3:neq)],'%-5.0f %-12.5g %-12.5g %-12.5g\n'));

disp('  ')
disp('Node  N            T            M')
disp(num2str([[1:nnd]; Ni; Ti; Mi]','%-5.0f %-12.5g %-12.5g %-12.5g\n'));
%--------------------------------------------------------------------------
% diagrams
s=(0:nel)*L;
% Axial effort diagram
figure(10), clf, hold on, grid on
plot(s,Ni,'linewidth',1.5)
xlabel('s [mm]')
ylabel('Axial effort [N]')
title('Axial effort')

% Shear effort diagram
figure(15), clf, hold on, grid on
plot(s,Ti,'linewidth',1.5)
xlabel('s [mm]')
ylabel('Shear effort [N]')
title('Shear effort')

% Bending moment diagram
figure(20), clf, hold on, grid on
plot(s,Mi,'linewidth',1.5)
xlabel('s [mm]')
ylabel('Bending moment [Nmm]')
title('Bending moment')

%*** stress.m ***
for ie=1:nel
    n1=elem(ie,1);
    n2=elem(ie,2);
    L=Lt(ie);
    R=Rt(:,:,ie);
	ip=[3*n1-2 3*n1-1 3*n1 3*n2-2 3*n2-1 3*n2];
    uel=R*S(ip);
    for ig=1:2     	
        xc=1/2*(1+xg(ig));
        deriv
        ep(ig)=Bux*uel;
        be(ig)=Bbe*uel;
        ka(ig)=Bka*uel;
    end
	N(ie)=ea*mean(ep);
    T(ie)=ga*mean(be);
    M(ie)=ei*mean(ka);
end
% interpolation
Ni=interp1(0.5:nel,N,0:nel,'PCHIP','extrap');
Ti=interp1(0.5:nel,T,0:nel,'PCHIP','extrap');
Mi=interp1(0.5:nel,M,0:nel,'PCHIP','extrap');
p=1e2;
Ni=round(Ni*p)/p; Ti=round(Ti*p)/p; Mi=round(Mi*p)/p;

# Chapter 19 - Timoshenko third-degree shape function

This package contains the beam buckling example programs. Run `main.m` from the extracted folder. It calls `gen`, `stiff`, `stress`, and `geomK`: the linear static analysis supplies the axial forces for the buckling eigenproblem. Compression has N < 0 and geometric stiffness uses -N.

The MATLAB release used for the author testing is not recorded in this package.

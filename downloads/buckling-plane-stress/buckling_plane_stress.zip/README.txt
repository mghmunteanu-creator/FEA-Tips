CHAPTER 20 MATLAB PROGRAMS

This package solves the linear eigenvalue-buckling problem for a plane-stress structure discretized with Q4 finite elements.

Run main.m.

Program structure:
- gen.m defines the finite-element model and reference loading.
- stiff.m assembles the elastic stiffness matrix and applies the boundary conditions.
- stress.m evaluates the element stresses from the preliminary linear static solution.
- geomK.m assembles the geometric stiffness matrix and solves the buckling eigenvalue problem.

Compression is negative. The program first solves the linear static problem for the prescribed reference load and then solves the generalized eigenvalue problem for the buckling load multipliers.

Tested with MATLAB R2026a.

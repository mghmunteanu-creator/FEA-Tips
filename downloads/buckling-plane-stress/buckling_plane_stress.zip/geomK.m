% *** plane_kg ***
Kg=sparse(neq,neq);
ig=0;
for i=1:nel;
	n1=elem(i,1); n2=elem(i,2); n3=elem(i,3); n4=elem(i,4);
    ipos=[2*n1-1  2*n1  2*n2-1  2*n2  2*n3-1  2*n3  2*n4-1  2*n4]; 
    %----------------------------------------------------------------------
	xel=[x(n1) x(n2) x(n3) x(n4)]'; 	% nodal
	yel=[y(n1) y(n2) y(n3) y(n4)]'; 	% coordinates 
    fel=zeros(8,1);
	kelg=zeros(8);
	for j=1:4;
        ig=ig+1;
        s=st(1,j);
        t=st(2,j);
        H=[(1+t)/4  -(1+t)/4  -(1-t)/4  (1-t)/4
           (1+s)/4   (1-s)/4  -(1-s)/4 -(1+s)/4]; 	
        J=H*[ xel    yel];                  % Jacobian
        detJ=abs(det(J));
        J1=inv(J);
        b=J1*H;
        Bux=[b(1,1)  0        b(1,2)   0        b(1,3)   0        b(1,4)   0     ];
        Buy=[b(2,1)  0        b(2,2)   0        b(2,3)   0        b(2,4)   0     ];
        Bvx=[0       b(1,1)   0        b(1,2)   0        b(1,3)   0        b(1,4)]; 
        Bvy=[0       b(2,1)   0        b(2,2)   0        b(2,3)   0        b(2,4)];            
             
        Gx =Bux'*Bux+Bvx'*Bvx;
        Gy =Buy'*Buy+Bvy'*Bvy;
        Gxy=Bux'*Buy+Bvx'*Bvy+Buy'*Bux+Bvy'*Bvx;
             
        kelg=kelg-th*(sigmt(ig,1)*Gx+sigmt(ig,2)*Gy+sigmt(ig,3)*Gxy)*detJ;
    end
    % assembling process:
    Kg(ipos,ipos)=Kg(ipos,ipos)+kelg;
end

% Constraints
loc=2*(cond(:,1)-1)+cond(:,2);
ip=setdiff(1:neq,loc);

ei=E*th^4/12; 
N_cr_Euler=pi^2*ei/L^2/4

[ev d]=eigs(Kg(ip,ip),K(ip,ip));
dd=1./diag(d);
valid=isfinite(dd) & dd>0;
ind=find(valid);
[ds is]=sort(dd(valid));
is=ind(is);
figure(10)
mx=(max(x)-min(x)+max(y)-min(y))/10;
ieigv=0;
for i=1:min(6,length(is))
    if valid(is(i))==1
        ieigv=ieigv+1;
        str = ['Eigenvalue number',num2str(ieigv),': ',num2str(dd(is(i)))];
        disp(str)
        disp(' ')
        vcr=ev(:,is(i));
        vcr=vcr/max(abs(vcr))*mx;
        vc=zeros(neq,1);
        vc(ip)=vcr;
        xc=vc(1:2:neq);
        yc=vc(2:2:neq);
        clf, hold on, grid on, axis('equal')
        patch('Vertices',[x+xc y+yc],'Faces',elem(:,1:4),'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b')
        disp('To continue, press any key')
        pause
    end
end



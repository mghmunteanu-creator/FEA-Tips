% *** main ***
clear
gen
stiff
S=K\F;
stress
geomK

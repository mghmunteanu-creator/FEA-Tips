% *** stress ***
B=zeros(3,8);
sigmt=zeros(4*nel,3);
ig=0;
for i=1:nel
	n1=elem(i,1); n2=elem(i,2); n3=elem(i,3); n4=elem(i,4);
    ipos=[ngn*n1-1 ngn*n1 ngn*n2-1 ngn*n2 ngn*n3-1 ngn*n3 ngn*n4-1 ngn*n4];
	xel=x([n1 n2 n3 n4]); yel=y([n1 n2 n3 n4]);     % nodal coordinates
	del=S(ipos);                                    % nodal displacements
	for ip=1:4;
        s=st(1,ip);
        t=st(2,ip);
        H=[(1+t)/4  -(1+t)/4  -(1-t)/4  (1-t)/4
           (1+s)/4   (1-s)/4  -(1-s)/4 -(1+s)/4]; 	
        J=H*[ xel    yel];              % Jacobian
		br=inv(J)*H;
        B(1,[1 3 5 7])=br(1,:); 
        B(2,[2 4 6 8])=br(2,:);
        B(3,[2 4 6 8 1 3 5 7])=[br(1,:) br(2,:)];
		sigma=DHooke*B*del;             % calculate stresses
        ig=ig+1;
        sigmt(ig,:)=sigma;
    end
end

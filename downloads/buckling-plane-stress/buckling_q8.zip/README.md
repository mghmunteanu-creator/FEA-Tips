# Chapter 20 — Q8 buckling analysis, Example 1

Run `main.m` to analyse the plane-stress cantilever with eight-node
quadrilateral elements. The supplied mesh is nH=8, nL=100.

- `gen.m`: geometry, mesh, constraints and unit compressive reference load.
- `stiff.m`: elastic stiffness with nine Gauss points per element.
- `stress.m`: stresses from the linear static solution.
- `geomK.m`: geometric stiffness and buckling eigenvalues/modes.
- `main.m`: runs the linear static analysis followed by the buckling analysis.

Compression is negative. Press any key when prompted to display the next mode.
The current 8 x 100 example was executed in MATLAB R2026a Update 4;
the first critical load was 27636.6732 N.

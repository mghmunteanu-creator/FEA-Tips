% *** gen ***
%==========================================================================
% It generates input data for a rectangular cross-section cantilevr beam:
%   L  - beam length
%   H  - cross-section height
%   th - cross-section width (thickness)
%   E  - Young modulus
%   nu - Poison ratio
%   F  - Force applied on the free end of the cantilever
%   nL - number of elements on the beam length
%   nH - number of elements on the beam height
%==========================================================================
% x, y  vectors that contain the nodal coordinates
%
% elem  table contains the four element nodes
%       [node1  node2  node3  node4  ...  node8
%       [node1  node2  node3  node4  ...  node8 
%        :      :      :      :    ]
%                
% cond  table contains nodal constraints 
%       (dir=1 - x direction, dir=2 - y direction)
%       [node1  dir1
%        node2  dir2
%        :      :   ]
% forze table contains nodal loads
%       [node1  dir1  force1
%        node2  dir2  force2
%        :      :     :     ]
%==========================================================================
L=500;
H=20;
th=20;
E=2.1e5;
nu=0.3;
F=1;

nH= 8%/3;
nL=100%/5;
%========================================
% Generation of the table "x"
dH=H/nH/2;
dL=L/nL/2;
nnd=(2*nL+1)*(2*nH+1);
nel= nL*nH;
elem=zeros(nel,8);
inod=0;
xx=0;
for i=1:2*nL+1
   yy=0;
   for j=1:2*nH+1
      inod=inod+1;
      x(inod,1)=xx;
      y(inod,1)=yy;
      yy=yy+dH;
   end
   xx=xx+dL;
end
%========================================
% Generation of the table "elem"
iel=0;
inod=-1;
for i=1:nL
	for j=1:nH
    	inod=inod+2;
    	iel=iel+1;
        elem(iel,:)=[inod    inod+2       inod+4*nH+4  inod+4*nH+2 ...
                     inod+1  inod+2*nH+3  inod+4*nH+3  inod+2*nH+1];
   end
   inod=inod+2*nH+2;
end
%========================================
% Generation of the table "cond"
cond=[];
for i=1:2*nH+1
    cond=[cond; [i 1]; [i 2]];
end
%========================================
% Generation of the table "forze"
dF=F/nH/2;
for i=1:2*nH+1
   forze(i,1)=nnd+1-i;
   forze(i,2)=1;
   forze(i,3)=-dF;
   if i==1 | i==2*nH+1
      forze(i,3)=-dF/2;
   end
end

% The nodes that don't belong to any finite element are eliminated:
nodi=unique(elem(:));
x=x(nodi);
y=y(nodi);
for i=1:length(nodi)
    nodj(nodi(i))=i;
end
elem=nodj(elem);
forze(:,1)=nodj(forze(:,1));
nnd=length(nodi);
%========================================
% Plot the mesh
figure(1)
clf
hold on
axis('equal')
patch('Vertices',[x y],'Faces',elem(:,[1 5 2 6 3 7 4 8]),'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b')
grid on
nd=nnd-2*nH:nnd;
ln=length(nd);
quiver(x(nd),y(nd),-3.5*dH*ones(ln,1),zeros(ln,1),'r','linewidth',1.5)
for i=1:2*nH+1
    xt=x(i); yt=y(i);
    fill([xt xt-dH/1.5 xt-dH/1.5],[yt yt+dH/3 yt-dH/3],'g')
    fill([xt xt-dH/3 xt+dH/3],[yt yt-dH/1.5 yt-dH/1.5],'g')
end
plot(x,y,'.','markersize',8)



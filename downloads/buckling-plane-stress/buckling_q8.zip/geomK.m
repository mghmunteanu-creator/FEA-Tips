%*** geomK ***
iu=[ones(1,8);zeros(1,8)];iu=iu(:)';
iv=[zeros(1,8);ones(1,8)];iv=iv(:)';
Kg=sparse(neq,neq);
ig=0;
for ie=1:nel;
	nodi=elem(ie,:);
    ip=[2*nodi-1; 2*nodi];
    ip=ip(:);
    %----------------------------------------------------------------------
	xel=x(nodi);         % nodal
	yel=y(nodi);         % coordinates 
    fel=zeros(16,1);
	kelg=zeros(16);
	for j=1:9
        ig=ig+1;
        B=Bt(:,:,ig);
        Bux=B(1,:);
        Buy=B(3,:).*iv;
        Bvx=B(3,:).*iu;
        Bvy=B(2,:);

        Gx =Bux'*Bux+Bvx'*Bvx;
        Gy =Buy'*Buy+Bvy'*Bvy;
        Gxy=Bux'*Buy+Bvx'*Bvy+Buy'*Bux+Bvy'*Bvx;
             
        kelg=kelg-wgs(j)*wgt(j)*th*(sigmt(ig,1)*Gx+sigmt(ig,2)*Gy+sigmt(ig,3)*Gxy)*detJ;
    end
    % assembling process:
    Kg(ip,ip)=Kg(ip,ip)+kelg;
end

% Constraints
loc=2*(cond(:,1)-1)+cond(:,2);
ip=setdiff(1:neq,loc);

ei=E*th^4/12; 
N_cr_Euler=pi^2*ei/L^2/4

[ev d]=eigs(Kg(ip,ip),K(ip,ip));
dd=1./diag(d);
valid=isfinite(dd) & dd>0;
ind=find(valid);
[ds is]=sort(dd(valid));
is=ind(is);
figure(10)
mx=(max(x)-min(x)+max(y)-min(y))/10;
ieigv=0;
for i=1:min(6,length(is))
    if valid(is(i))==1
        ieigv=ieigv+1;
        str = ['Eigenvalue number',num2str(ieigv),': ',num2str(dd(is(i)))];
        disp(str)
        disp(' ')
        vcr=ev(:,is(i));
        vcr=vcr/max(abs(vcr))*mx;
        vc=zeros(neq,1);
        vc(ip)=vcr;
        xc=vc(1:2:neq);
        yc=vc(2:2:neq);
        clf, hold on, grid on, axis('equal')
        patch('Vertices',[x+xc y+yc],'Faces',elem(:,1:4),'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b')
        disp('To continue, press any key')
        pause
    end
end



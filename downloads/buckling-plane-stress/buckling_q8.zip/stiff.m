% *** stiff ***
nnd=length(x(:,1));	                % number of nodes
nel=length(elem(:,1));		        % number of finite elements
neq=2*nnd;                        % total number of equations (or unknowns)
K=sparse(neq,neq);                   % Stiffness matrix initialization
F=zeros(neq,1);
% Gauss points, 3rd order
xgss=sqrt(0.6);
xgauss=[  -xgss      0     xgss];	
wgauss=[   5/9      8/9    5/9 ];	
xgs=[xgauss; xgauss; xgauss]; xgt=xgs';
xgs=xgs(:); xgt=xgt(:);
wgs=[wgauss; wgauss; wgauss]; wgt=wgs';
wgs=wgs(:); wgt=wgt(:);

E1=E/(1-nu*nu);
G=E/2/(1+nu);
DHooke=[   E1  nu*E1     0
	    nu*E1     E1     0
		    0      0     G ];
Bt=zeros(3,16,9*nel);
ig=0;
for ie=1:nel;
	nodi=elem(ie,:);
    %----------------------------------------------------------------------
	xel=x(nodi);         % nodal
	yel=y(nodi);         % coordinates 
	kel=zeros(16);
	for j=1:9
        ig=ig+1;
        s=xgs(j);
        t=xgt(j);
        dps0=[(1+t)/4  -(1+t)/4  -(1-t)/4  (1-t)/4     0     0     0     0];    
        dpt0=[(1+s)/4   (1-s)/4  -(1-s)/4 -(1+s)/4     0     0     0     0]; 	

        dps1=[   0    0    0    0    -s*(1+t)   -(1-t^2)/2  -s*(1-t)     (1-t^2)/2 ]; 	
        dpt1=[   0    0    0    0    (1-s^2)/2  -t*(1-s)    -(1-s^2)/2  -t*(1+s)   ]; 	

        dps2=[ (1-t^2)/2  -s*(1+t)    -(1-t^2)/2  -s*(1-t)      0      0     0     0]/2; 	
        dpt2=[-t*(1+s)     (1-s^2)/2  -t*(1-s)    -(1-s^2)/2    0      0     0     0]/2; 

        dps3=[-s*(1+t)    -(1-t^2)/2  -s*(1-t)     (1-t^2)/2    0      0     0     0]/2; 	
        dpt3=[ (1-s^2)/2  -t*(1-s)    -(1-s^2)/2  -t*(1+s)      0      0     0     0]/2; 	

        dps=dps0+dps1-dps2-dps3;
        dpt=dpt0+dpt1-dpt2-dpt3;

        H=[dps
           dpt];
        J=H*[ xel  yel];	% Jacobian
        detJ=abs(det(J));
        J1=inv(J);
        b=J1*H;

        % strain-displacement matrix
        Bux=[b(1,1:8)
             zeros(1,8)]; Bux=Bux(:)';
        Buy=[b(2,1:8)
            zeros(1,8)];  Buy=Buy(:)';

        Bvx=[zeros(1,8)
             b(1,1:8)];  Bvx=Bvx(:)';

        Bvy=[zeros(1,8)
            b(2,1:8)];  Bvy=Bvy(:)';

        B=[Bux; Bvy; Buy+Bvx];
        Bt(:,:,ig)=B;
        kel=kel+wgs(j)*wgt(j)*th*B'*DHooke*B*detJ;        % element stiffness matrix
    end	
    %----------------------------------------------------------------------
    ip=[2*nodi-1; 2*nodi];
    ip=ip(:);
 	K(ip,ip)=K(ip,ip)+ kel;         % assembling process
end
% Constraints
loc=2*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 
% Concentrated force
loc=2*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)+forze(:,3); 

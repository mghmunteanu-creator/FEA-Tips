% *** stress ***
sigmt=zeros(9*nel,3);
ig=0;
for ie=1:nel
	nodi=elem(ie,:);
    ip=[2*nodi-1; 2*nodi];
    ip=ip(:);
	xel=x(nodi);                        % nodal
	yel=y(nodi);                        % coordinates 
	sel=S(ip);                        % nodal displacements
	for j=1:9
        ig=ig+1;
        B=Bt(:,:,ig);
        sigma=DHooke*B*sel;             % calculate stresses
        sigmt(ig,:)=sigma;
    end
end

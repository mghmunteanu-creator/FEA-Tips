Cantilever elastica: exact large-displacement solution
======================================================

Files
-----
main_cantilever.m  Main script. Defines the beam and force components,
                   evaluates the elliptic-integral solution, and plots the
                   deformed centerline.
findm.m            Finds the elliptic parameter m by bisection on its real,
                   physically admissible interval.
eql_chck.m         Checks the solution by comparing EI times the curvature
                   with the bending moment obtained from force equilibrium.

How to run
----------
Open MATLAB in this folder and run:

    main_cantilever

The default load is V = 100 N and H = -200 N. To select another load without
editing the file, define the two components first:

    V = 100;
    H = 0;
    main_cantilever

Requirements and compatibility
------------------------------
The programs use ellipticF, ellipticK, and ellipticE and therefore require
Symbolic Math Toolbox.

Checked in MATLAB R2026a and MATLAB R2017b. The code is intended to remain
compatible with MATLAB R2017b and later.

Model assumptions
-----------------
Straight prismatic Euler-Bernoulli beam, linear elastic material, small strain,
large displacement, and an end force of fixed direction. Axial and shear
deformations are neglected.

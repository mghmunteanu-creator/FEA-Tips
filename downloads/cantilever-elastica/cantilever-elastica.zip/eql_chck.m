%*** eql_chck ***
% Compare the bending moment obtained from curvature with the moment
% obtained independently from equilibrium of the end forces.
ds=sqrt((xr(2:np)-xr(1:np-1)).^2+(yr(2:np)-yr(1:np-1)).^2);
% Nodal curvilinear coordinates:
s=[0;cumsum(ds)];                   
d=0.2;
% Equidistant nodal curvilinear coordinates:
ns=round(L/d)+1;
si=linspace(0,L,ns)';
d=si(2)-si(1);
% Interpolated nodal coordinates:
xi=interp1(s,xr,si,'pchip');
yi=interp1(s,yr,si,'pchip');
% Slope and curvature:
phi=unwrap(atan2(yi(2:ns)-yi(1:ns-1),xi(2:ns)-xi(1:ns-1)));
crv=diff(phi)/d;
sc=si(2:ns-1);
% Bending moment from the curvature:
Mc=EI*crv;
% Bending moment from equilibrium of the external forces:
Mf=-V*(xi-xi(1))-H*(yi-yi(1));
Mfi=interp1(si,Mf,sc,'pchip');
moment_relative_error=max(abs(Mc-Mfi))/max(1,max(abs(Mfi)));
fprintf('Maximum relative moment difference: %.6e\n',moment_relative_error)

figure(10),clf, hold on, grid on
plot(sc,Mc,'b','linewidth',2)
plot(si(1:ns),Mf,'--r','linewidth',2)
xlabel('s [mm]')
ylabel('Bending moment [Nmm]')
legend({'M_1=EI*curvature','M_2=V*\Deltax+H*\Deltay'},'fontsize',12,'location','northwest')



function m=findm(EI,L,P,beta)
%FINDM Determine the elliptic parameter m for the prescribed end force.
%   The principal elastica branch satisfies
%   P = (EI/L^2)*(K(m)-F(psi0,m))^2,
%   with sin(psi0)=sin(beta/2)/sqrt(m).

if EI<=0 || L<=0 || P<=0
    error('EI, L, and P must be positive.')
end
if beta<0 || beta>=pi
    error('beta must satisfy 0 <= beta < pi.')
end

% The incomplete elliptic integral is real only when
% m >= sin(beta/2)^2. This is also the zero-load limit.
m1=sin(beta/2)^2+1e-12;
m2=1-1e-12;
if m1>=m2
    error('The force direction is too close to beta = pi.')
end

tol=1e-12;
itermax=200;
m=(m1+m2)/2;
for iter=1:itermax
    m=(m1+m2)/2;
    Pc=force_from_m(m,EI,L,beta);
    if Pc<P
        m1=m;
    else
        m2=m;
    end
    if (m2-m1)<=tol*max(1,m)
        break
    end
end
if iter==itermax
    warning('findm:NoConvergence','The bisection reached the iteration limit.')
end
end

function P=force_from_m(m,EI,L,beta)
% P=EI/L^2*[K(m)-F(psi0,m)]^2
Kcomplete=ellipticK(m);
ratio=sin(beta/2)/sqrt(m);
ratio=min(1,max(-1,ratio));
psi0=asin(ratio);
F0=ellipticF(psi0,m);
C=(Kcomplete-F0)/L;
P=EI*C^2;
end

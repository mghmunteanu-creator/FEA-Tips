%*** main_cantilever ***
% Exact Euler elastica solution for a cantilever under an end force.
% The force components may be defined before running this script.
clearvars -except V H
format short e
%==========================================================================
if ~exist('V','var'), V= 100; end  % vertical force [N]
if ~exist('H','var'), H=-200; end  % horizontal force [N]
L=100;      % beam length [mm]
width=5;    % width of the rectangular cross-section [mm]
t=1;        % thickness of the rectangular cross-section [mm]
E=2e5;      % Young's modulus [MPa = N/mm^2]
np=601;     % number of points on the elastica
%==========================================================================
I=width*t^3/12;
EI=E*I;
P=hypot(V,H);
if P<=0
    error('At least one force component must be nonzero.')
end
beta=atan2(abs(V),-H);
m=findm(EI,L,P,beta);
k=sqrt(m);
thetaA=2*asin(k);
psi0=asin(sin(beta/2)/k);
Ecomplete=ellipticE(m);
Kcomplete=ellipticK(m);
F0=ellipticF(psi0,m);
C=(Kcomplete-F0)/L;
thetaValues=linspace(thetaA,beta,np);
s=zeros(np,1);
x=zeros(np,1);
y=zeros(np,1);
for i=2:np
    theta=thetaValues(i);
    psi=asin(sin(theta/2)/k);
    Eincomplete=ellipticE(psi,m);
    Fincomplete=ellipticF(psi,m);
    denominator=Kcomplete-Fincomplete;
    s(i)=denominator/C;
    x(i)=s(i)*(2*(Ecomplete-Eincomplete)/denominator-1);
    y(i)=2*k*s(i)*cos(psi)/denominator;
end
% Move the origin from the loaded end A to the clamped end O.
x=x(np)-x;
y=y(np)-y;
% Rotate the local coordinates to the global x-y frame.
xr=x*cos(beta)+y*sin(beta);
yr=x*sin(beta)-y*cos(beta);
%==========================================================================
figure(5)
clf, hold on, grid on, axis('equal')
plot(xr/L,yr/L,'b','linewidth',2)
xlabel('x/L')
ylabel('y/L')
title(['V=',num2str(V),';     H=',num2str(H)])

drawnow

eql_chck
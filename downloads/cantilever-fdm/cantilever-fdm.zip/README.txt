Cantilever beam with large displacements — finite-difference method
===================================================================

Files
-----
cantilever.m
    Main solver and plot for a straight Euler-Bernoulli cantilever.

verify_cantilever_jacobian.m
    Numerical check of the residual vector and the tangent matrix used by
    cantilever.m.

Model and sign convention
-------------------------
The beam has small strains and can undergo large displacements and rotations.
The global x axis is positive to the right and the global y axis is positive
downward. The free-end load components H and V therefore use these directions.
The end couple C is positive in the sense shown in the chapter figure.

Method
------
The beam is divided into equal arc-length intervals. The local finite-
difference residual equations are differentiated exactly. In the first tangent
equation, the current free-end coordinates are held fixed, so the overall
iteration is an under-relaxed modified Newton method. The relaxation factor
sr can be changed in cantilever.m.

Use
---
Run cantilever.m. The default example uses:
  V = 100 N, H = -200 N, C = 0 N mm,
  L = 100 mm, width = 5 mm, thickness = 1 mm, E = 2e5 MPa.

Run verify_cantilever_jacobian.m after the main program if a numerical check
of the residual and tangent matrix is desired.

Compatibility
-------------
The package uses core MATLAB functions only. It was run in MATLAB R2026a and
MATLAB R2017b.

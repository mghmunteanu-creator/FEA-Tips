%*** cantilever ***
% Large-displacement analysis of a cantilever beam by finite differences.
% The beam is modeled as an inextensible Euler-Bernoulli beam and is loaded
% at its free end by the force components V and H and the couple C.
%
% The first residual equation retains the current free-end coordinates.
% In its tangent equation, those coordinates are held fixed. The resulting
% scheme is therefore an under-relaxed modified Newton iteration.

clear
format short e

% Model data
V = 100;        % vertical force [N], positive in the positive y direction
H = -200;       % horizontal force [N], positive in the positive x direction
C = 0;          % end couple [N mm]
L = 100;        % beam length [mm]
width = 5;      % cross-section width [mm]
t = 1;          % cross-section thickness [mm]
E = 2e5;        % Young's modulus [MPa = N/mm^2]

% Iteration controls
sr = 0.025;     % under-relaxation factor
tol = 1e-5;     % tolerance for the normalized angular correction
itermax = 1000; % maximum number of iterations

% Discretization and initialization
I = width*t^3/12;
EI = E*I;
n = 201;        % number of nodes
h = L/(n-1);    % interval length
f = zeros(n,1); % nodal rotations: f(i) = phi_i
psi = zeros(n-1,1);
J = zeros(n-1);
x = linspace(0,L,n)';
y = zeros(n,1);
err = 1;
iter = 0;

while err > tol && iter < itermax
    iter = iter+1;

    % First residual equation, written for the segment next to the clamp.
    psi(1) = EI*f(2)/h+C-V*(x(n)-x(2)/2)+H*(y(n)-y(2)/2);

    % Modified tangent: x(n) and y(n) are held fixed in this first row.
    J(1,1) = EI/h-V*h/4*sin(f(2)/2)-H*h/4*cos(f(2)/2);

    % Local residual equations obtained by subtracting adjacent equilibrium
    % equations. Their Jacobian entries are exact.
    for i = 2:n-1
        cs1 = cos((f(i)+f(i+1))/2);
        cs2 = cos((f(i-1)+f(i))/2);
        sn1 = sin((f(i)+f(i+1))/2);
        sn2 = sin((f(i-1)+f(i))/2);

        psi(i) = EI/h*(f(i+1)-2*f(i)+f(i-1)) ...
            +V*h/2*(cs1+cs2)-H*h/2*(sn1+sn2);

        if i > 2
            J(i,i-2) = EI/h-V*h/4*sn2-H*h/4*cs2;
        end
        J(i,i-1) = -2*EI/h-V*h/4*(sn1+sn2)-H*h/4*(cs1+cs2);
        J(i,i) = EI/h-V*h/4*sn1-H*h/4*cs1;
    end

    % Under-relaxed correction of the nodal rotations.
    df = J\psi;
    df = [0;df];
    f = f-sr*df;
    err = sqrt(df'*df/(2*n));

    % Reconstruct the centerline from the midpoint rotations.
    fm = (f(2:n)+f(1:n-1))/2;
    x = [0;cumsum(cos(fm)*h)];
    y = [0;cumsum(sin(fm)*h)];
end

fprintf('Iterations: %d\n',iter)
fprintf('Normalized correction: %.6e\n',err)
if iter == itermax && err > tol
    warning('The iteration limit was reached before convergence.')
end

% Plot the deformed centerline.
figure(5)
clf
hold on
grid on
axis equal
plot(x/L,y/L,'b','LineWidth',2)
xlabel('x/L')
ylabel('y/L')
title('Deformed cantilever')

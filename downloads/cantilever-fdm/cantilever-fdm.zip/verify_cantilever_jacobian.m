%*** verify_cantilever_jacobian ***
% Numerical check of the residual vector and the Jacobian used in cantilever.m.
set(groot,'defaultFigureVisible','off')
run('cantilever.m')

[psi_check,J_code] = residual_and_code_jacobian(f,EI,V,H,C,h);
unknowns = f(2:end);
J_num = zeros(n-1);
step = 1e-7;
for j = 1:n-1
    perturbed = unknowns;
    perturbed(j) = perturbed(j)+step;
    f_perturbed = [0;perturbed];
    psi_perturbed = residual_only(f_perturbed,EI,V,H,C,h);
    J_num(:,j) = (psi_perturbed-psi_check)/step;
end

fprintf('Residual RMS after the final update: %.12g\n',sqrt(psi_check'*psi_check/(n-1)))
fprintf('First Jacobian row, maximum difference: %.12g\n',max(abs(J_num(1,:)-J_code(1,:))))
fprintf('Remaining Jacobian rows, maximum difference: %.12g\n',max(max(abs(J_num(2:end,:)-J_code(2:end,:)))))

function psi = residual_only(f,EI,V,H,C,h)
    n = length(f);
    fm = (f(2:n)+f(1:n-1))/2;
    x = [0;cumsum(cos(fm)*h)];
    y = [0;cumsum(sin(fm)*h)];
    psi = zeros(n-1,1);
    psi(1) = EI*f(2)/h+C-V*(x(n)-x(2)/2)+H*(y(n)-y(2)/2);
    for i = 2:n-1
        cs1 = cos((f(i)+f(i+1))/2);
        cs2 = cos((f(i-1)+f(i))/2);
        sn1 = sin((f(i)+f(i+1))/2);
        sn2 = sin((f(i-1)+f(i))/2);
        psi(i) = EI/h*(f(i+1)-2*f(i)+f(i-1))+V*h/2*(cs1+cs2)-H*h/2*(sn1+sn2);
    end
end

function [psi,J] = residual_and_code_jacobian(f,EI,V,H,C,h)
    n = length(f);
    fm = (f(2:n)+f(1:n-1))/2;
    x = [0;cumsum(cos(fm)*h)];
    y = [0;cumsum(sin(fm)*h)];
    psi = zeros(n-1,1);
    J = zeros(n-1);
    psi(1) = EI*f(2)/h+C-V*(x(n)-x(2)/2)+H*(y(n)-y(2)/2);
    J(1,1) = EI/h-V*h/4*sin(f(2)/2)-H*h/4*cos(f(2)/2);
    for i = 2:n-1
        cs1 = cos((f(i)+f(i+1))/2);
        cs2 = cos((f(i-1)+f(i))/2);
        sn1 = sin((f(i)+f(i+1))/2);
        sn2 = sin((f(i-1)+f(i))/2);
        psi(i) = EI/h*(f(i+1)-2*f(i)+f(i-1))+V*h/2*(cs1+cs2)-H*h/2*(sn1+sn2);
        if i > 2
            J(i,i-2) = EI/h-V*h/4*sn2-H*h/4*cs2;
        end
        J(i,i-1) = -2*EI/h-V*h/4*(sn1+sn2)-H*h/4*(cs1+cs2);
        J(i,i) = EI/h-V*h/4*sn1-H*h/4*cs1;
    end
end

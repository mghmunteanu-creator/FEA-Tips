# Section 16.1 - Corotational Q4

Run `main.m` from the extracted folder for the corotational quadrilateral plane-stress example. The package includes the input, element calculation and displacement/strain/stress plotting routines. Run the plotting scripts after the analysis, with its variables retained in the workspace.

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

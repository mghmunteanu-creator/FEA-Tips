% *** main ***
clear
format short e
nstep=8;                     % number of load steps
itermax=100;                 % maximum number of iterations
tol=1e-5;                    % tolerance
figure(5)
clf, hold on, grid on, axis('equal')
gen
S =zeros(neq,1);             % nodal displacements for the current load step
St=zeros(neq,nstep+1);       % nodal displacements for all load steps  
strnt=zeros(4*nel,3,nstep);  % strains in finite elements for all load steps
sigmt=zeros(4*nel,4,nstep);  % stresses in finite elements for all load steps
sr=0.5;
for istep=1:nstep
    error=1;
    iter=0;
    while (error > tol) & (iter < itermax)
        iter=iter+1;
        stiff
        dS=K\F*sr;
        S=S-dS;
        error=sqrt(dS'*dS/nnd);
    end
    u=S(1:2:neq);
    v=S(2:2:neq);
    patch('Vertices',[x+u y+v],'Faces',elem,'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b')    
    drawnow
    [istep iter error]
    St(:,istep+1)=S;
    % Von Mises stresses for the current load step:
    sigmt(:,4,istep)=sqrt(sigmt(:,1,istep).^2+sigmt(:,2,istep).^2 ...
        -sigmt(:,1,istep).*sigmt(:,2,istep)+3*sigmt(:,3,istep).^2);

    sigmtr(:,4,istep)=sqrt(sigmtr(:,1,istep).^2+sigmtr(:,2,istep).^2 ...
        -sigmtr(:,1,istep).*sigmtr(:,2,istep)+3*sigmtr(:,3,istep).^2);
    pause(0.01)
end
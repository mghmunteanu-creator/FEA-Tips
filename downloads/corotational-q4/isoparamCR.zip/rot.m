% *** rot ***
xdel=xel+u([n1 n2 n3 n4]);      % current 
ydel=yel+v([n1 n2 n3 n4]);      % configuration 
for i=1:4
    i1=mod(i,4)+1;
    dxy =[xel(i1)-xel(i)   yel(i1)-yel(i)   0];
    dxyd=[xdel(i1)-xdel(i) ydel(i1)-ydel(i) 0];

    cr=cross(dxyd,dxy);
    dt=dot(dxyd,dxy);
    thet(i)=atan2(cr(3),dt);
end
thetm=mean(thet);
cs=cos(thetm); sn=sin(thetm);
R=[cs sn; -sn cs];              % rotation matrix
xyr=R*[xel yel]';               % corotational configuration
sel=[xdel ydel]'-xyr;           % corotational nodal displacements
sel=sel(:); 

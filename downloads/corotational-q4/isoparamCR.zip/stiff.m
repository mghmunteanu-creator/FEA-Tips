% *** stiff ***
E1=E/(1-nu*nu);  
E2=nu*E1;
G=E/2/(1+nu);
DHooke=[E1 E2 0
        E2 E1 0
         0  0 G];
F=zeros(neq,1);
K=zeros(neq);
% Gauss points
st=[1  -1  -1   1
    1   1  -1  -1]*sqrt(3)/3;
u=S(1:2:neq);
v=S(2:2:neq);
ig=0;
for ie=1:nel;
	n1=elem(ie,1); 
    n2=elem(ie,2); 
    n3=elem(ie,3); 
    n4=elem(ie,4);
    %----------------------------------------------------------------------
    fel=zeros(8,1);
	kel=zeros(8);
    xel=[x(n1) x(n2) x(n3) x(n4)]';         % nodal
	yel=[y(n1) y(n2) y(n3) y(n4)]';         % coordinates 
    rot
	for j=1:4;
        ig=ig+1;
        s=st(1,j);
        t=st(2,j);
        H=[(1+t)/4  -(1+t)/4  -(1-t)/4  (1-t)/4
           (1+s)/4   (1-s)/4  -(1-s)/4 -(1+s)/4]; 	
        J=H*[xdel ydel];      
        detJ=abs(det(J));
        J1=inv(J);
        b=J1*H;
        % strain-displacement matrix
        B=[b(1,1)       0    b(1,2)       0    b(1,3)       0    b(1,4)       0
  	           0    b(2,1)       0    b(2,2)       0    b(2,3)       0    b(2,4)
     	   b(2,1)   b(1,1)   b(2,2)   b(1,2)   b(2,3)   b(1,3)   b(2,4)   b(1,4)];
        strn=B*sel;                         % strains:
        th1=(1-nu/(1-nu)*(strn(1)+strn(2)))*th;
        fel=fel+th1*(B'*DHooke*strn)*detJ;  % nodal forces of the current element
        kel=kel+th1*(B'*DHooke*B)*detJ;     % stiffness matrix of the current element
        strnt(ig,:,istep)  =strn';          % table containing the strains in finite elements for all load steps
        sg=DHooke*strn;
        sigmt(ig,1:3,istep)=sg';   % table containing the stresses in finite elements for all load steps
        sgr=R'*[sg(1), sg(3); sg(3), sg(2)]*R;  % stresses in the local reference frame
        sigmtr(ig,1:3,istep)=[sgr(1,1), sgr(2,2), sgr(1,2)];
    end
    % assembling process:
    ipos=[2*n1-1  2*n1  2*n2-1  2*n2  2*n3-1  2*n3  2*n4-1  2*n4]; 
    F(ipos)=F(ipos)+fel;
    K(ipos,ipos)=K(ipos,ipos)+kel;
end
% Constraints:
loc=2*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 
% Concentrated force:
loc=2*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;               

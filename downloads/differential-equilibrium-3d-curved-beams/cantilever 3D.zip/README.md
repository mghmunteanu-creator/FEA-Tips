# Section 23.4 — 3D cantilever equilibrium verification

Extract all files to one folder and run `main.m` in MATLAB.

The example is an initially straight cantilever along the global x-axis, clamped at the origin. It uses L = 100 mm, a 2.5 mm by 3.5 mm rectangular section, E = 200000 MPa, end forces X = -300 N, Y = 100 N, Z = 50 N, and end moments Cx = 30000 N mm, Cy = 0, Cz = 40000 N mm.

- `main.m` runs the calculation, draws the deformed beam and calls the equilibrium verification.
- `cantilever_3D.m` calculates the large-displacement configuration by the finite-difference method presented in Section 22.2.
- `graph3D.m` draws the deformed beam surface.
- `verif.m` compares the two sides of the differential moment-equilibrium equations along the deformed beam, for torsion and bending about the two local transverse axes.

Units: mm, N and MPa; moments are in N mm and moment derivatives are in N. The diagrams use the dimensionless horizontal coordinate s/L.

MATLAB: no release is claimed as tested for this package during this audit. The four MATLAB program files are unchanged.

%*** cantilever_3D ***
clear
format short e
%==========================================================================
% Input data 
%--------------------------------------------------------------------------
L=100;
bb=2.5; hh=3.5
Iy=bb*hh^3/12;
Iz=bb^3*hh/12;
It=0.196*bb^3*hh;
E=2e5; G=E/2.6;
GIt=G*It;
EIy=E*Iy;
EIz=E*Iz;
X=-300;  Y=100; Z=50;
Cx=30000; Cy=0; Cz=40000;
tol=1e-5; 
itermax=100;    
%==========================================================================
% problem solving 
%--------------------------------------------------------------------------
D1=inv(diag([GIt; EIy; EIz]));
n=2001; 
neq=3*n;
h=L/(n-1);
x=(0:h:L+h/2)';
y=zeros(n,1);
z=zeros(n,1);
a=zeros(neq,1);
error=1; iter=0; 
while error>tol & (iter < itermax)
    iter=iter+1;
    ii=1:3;
    for i=2:n
        p=a(ii(1)); t=a(ii(2)); f=a(ii(3));
        sf=sin(f); cf=cos(f);
        st=sin(t); ct=cos(t);
        sp=sin(p); cp=cos(p);
        C=inv([-st      0  1
                ct*sf  cf  0
                ct*cf -sf  0]);
        M=[Z*(y(n)-y(i))-Y*(z(n)-z(i))+Cx
           X*(z(n)-z(i))-Z*(x(n)-x(i))+Cy
           Y*(x(n)-x(i))-X*(y(n)-y(i))+Cz];
        R=[ cp*ct            sp*ct          -st
           -sp*cf+cp*st*sf   cp*cf+sp*st*sf  ct*sf
            sp*sf+cp*st*cf  -cp*sf+sp*st*cf  ct*cf];
        M=D1*R*M;
        a(ii+3)=h*C*M+a(ii);
        ii=ii+3;
    end
    xo=x; yo=y; zo=z;
    x=zeros(n,1); y=x; z=x;
    for i=2:n
        ii=3*i-3;
        p=a(ii-2)/2+a(ii+1)/2; 
        t=a(ii-1)/2+a(ii+2)/2;
        f=a(ii  )/2+a(ii+3)/2;
        sp=sin(p); cp=cos(p);
        st=sin(t); ct=cos(t);
        x(i)=x(i-1)+h*cp*ct;
        y(i)=y(i-1)+h*sp*ct;
        z(i)=z(i-1)-h*st;
    end
    dxyz=[x-xo; y-yo; z-zo];
    error=sqrt(dxyz'*dxyz/3/n);
end
number_of_iterations=iter
error


%*** graph3D ***
%==========================================================================
Rt=zeros(3,3,n);
ii=1:3;
for ie=1:n
    p=a(ii(1)); t=a(ii(2)); f=a(ii(3));
    sf=sin(f); cf=cos(f);
    st=sin(t); ct=cos(t);
    sp=sin(p); cp=cos(p);
    R=[ cp*ct            sp*ct          -st
       -sp*cf+cp*st*sf   cp*cf+sp*st*sf  ct*sf
        sp*sf+cp*st*cf  -cp*sf+sp*st*cf  ct*cf];
    ii=ii+3;
    Rt(:,:,ie)=R;
end
xyz=[x y z]; 
%==========================================================================
figure(10)
clf
hold on
for ie=1:npas:n-1
    T1=Rt(:,:,ie);
    T2=Rt(:,:,ie+npas);
    coor=[0   0   0   0
          bb -bb -bb  bb
          hh  hh -hh -hh]/2;
    n1=ie; n2=ie+npas;
    cl1=T1'*coor+[xyz(n1,:)' xyz(n1,:)' xyz(n1,:)' xyz(n1,:)'];
    cl2=T2'*coor+[xyz(n2,:)' xyz(n2,:)' xyz(n2,:)' xyz(n2,:)'];
    sgz=1;
    sgy=1;
    sgx=1;
    c='c';
    b='b';
    c=[1 1 1]*0.9;
    b=c;
    fill3(sgx*[cl1(1,1),cl1(1,2),cl2(1,2),cl2(1,1)],sgy*[cl1(2,1),cl1(2,2),cl2(2,2),cl2(2,1)],sgz*[cl1(3,1),cl1(3,2),cl2(3,2),cl2(3,1)],c)
    fill3(sgx*[cl1(1,2),cl1(1,3),cl2(1,3),cl2(1,2)],sgy*[cl1(2,2),cl1(2,3),cl2(2,3),cl2(2,2)],sgz*[cl1(3,2),cl1(3,3),cl2(3,3),cl2(3,2)],c)
    fill3(sgx*[cl1(1,3),cl1(1,4),cl2(1,4),cl2(1,3)],sgy*[cl1(2,3),cl1(2,4),cl2(2,4),cl2(2,3)],sgz*[cl1(3,3),cl1(3,4),cl2(3,4),cl2(3,3)],c)
    fill3(sgx*[cl1(1,4),cl1(1,1),cl2(1,1),cl2(1,4)],sgy*[cl1(2,4),cl1(2,1),cl2(2,1),cl2(2,4)],sgz*[cl1(3,4),cl1(3,1),cl2(3,1),cl2(3,4)],b)
    if ie==1
        fill3(sgx*[cl1(1,1),cl1(1,2),cl1(1,3),cl1(1,4)],sgy*[cl1(2,1),cl1(2,2),cl1(2,3),cl1(2,4)],sgz*[cl1(3,1),cl1(3,2),cl1(3,3),cl1(3,4)],'r')  
    else
        fill3(sgx*[cl1(1,1),cl1(1,2),cl1(1,3),cl1(1,4)],sgy*[cl1(2,1),cl1(2,2),cl1(2,3),cl1(2,4)],sgz*[cl1(3,1),cl1(3,2),cl1(3,3),cl1(3,4)],c)  
    end
    fill3(sgx*[cl2(1,1),cl2(1,2),cl2(1,3),cl2(1,4)],sgy*[cl2(2,1),cl2(2,2),cl2(2,3),cl2(2,4)],sgz*[cl2(3,1),cl2(3,2),cl2(3,3),cl2(3,4)],c)
end

view(3)
grid on
xlabel('x')
ylabel('y')
zlabel('z')
axis('equal')
drawnow

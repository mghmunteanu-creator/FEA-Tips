%*** main ***
clear
format short e
cantilever_3D
npas=20;
graph3D
verif

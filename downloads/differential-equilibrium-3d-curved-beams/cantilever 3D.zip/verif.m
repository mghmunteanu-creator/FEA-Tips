%*** verif ***
pt=a(1:3:neq);
tt=a(2:3:neq);
ft=a(3:3:neq);
D=diag([GIt EIy EIz]);
Rt=zeros(3,3,n);
for i=2:n
    % Tait - Bryan angles:
    p=pt(i-1); t=tt(i-1); f=ft(i-1);
    cp=cos(p); sp=sin(p);
    ct=cos(t); st=sin(t);
    cf=cos(f); sf=sin(f);
    % Derivatives of Tait - Bryan angles:
    pp=(pt(i)-pt(i-1))/h;
    tp=(tt(i)-tt(i-1))/h;
    fp=(ft(i)-ft(i-1))/h;
    % Curvature vector (see Section 22.2):
    kappa=[-st      0  1
            ct*sf  cf  0
            ct*cf -sf  0]*[pp tp fp]';
    % Curvature tensor:   
    kat(:,:,i)=[ 0        -kappa(3)  kappa(2)
                 kappa(3)  0        -kappa(1)
                -kappa(2)  kappa(1)  0       ]';
    % Rotation matrix:     
    R=[ cp*ct            sp*ct          -st
       -sp*cf+cp*st*sf   cp*cf+sp*st*sf  ct*sf
        sp*sf+cp*st*cf  -cp*sf+sp*st*cf  ct*cf];
  	Rt(:,:,i)=R;
    % Moment vector in local reference frame:
  	Ml(:,i)=D*kappa;        
end
%==========================================================================
XYZ=[X Y Z]'; % Shear efforts in the global reference frame
for i=3:n
    % Finite-difference derivative of the local moment vector:
    dMl(:,i)=(Ml(:,i)-Ml(:,i-1))/h;
    % Shear effort in LOCAL reference frame:
    T=Rt(:,:,i)*XYZ; 
    % Curvature tensor times the averaged local moment vector, plus [0 T(3) -T(2)]':
    kM(:,i)=kat(:,:,i)*(Ml(:,i)+Ml(:,i-1))/2 + [0 T(3) -T(2)]';
end
s=[0:h:L]/L;
figure (20)
clf, hold on, grid on
plot(s(2:n-1),dMl(1,3:n),'linewidth',2)
plot(s(2:n-1),kM(1,3:n),'--','linewidth',2)
xlabel('s/L')
ylabel('dM_t/ds [N]')
legend('Left-hand side','Right-hand side','Location','northwest')
drawnow

figure (30)
clf, hold on, grid on
plot(s(2:n-1),dMl(2,3:n),'linewidth',2)
plot(s(2:n-1),kM(2,3:n),'--','linewidth',2)
xlabel('s/L')
ylabel('dM_y/ds [N]')
legend('Left-hand side','Right-hand side')
drawnow
  
figure (40)
clf, hold on, grid on
plot(s(2:n-1),dMl(3,3:n),'linewidth',2)
plot(s(2:n-1),kM(3,3:n),'--','linewidth',2)
xlabel('s/L')
ylabel('dM_z/ds [N]')
legend('Left-hand side','Right-hand side')
drawnow


% *** gen_beam ***
% Cantilever beam, HEX8 mesh. Units: mm, N, MPa.
% Geometry: length along x, width along y, thickness along z.
L=200;
t=50;
h=6;
E=1000;
nu=0.3;
sgy=40;
coff=0.80;
F=1000*coff;
nL=40;
nt=12;
nh=1;

dL=L/nL;
dt=t/nt;
dh=h/nh;
nnd=(nt+1)*(nh+1)*(nL+1);
nel=nt*nh*nL;
neq=3*nnd;
x=zeros(nnd,1); y=zeros(nnd,1); z=zeros(nnd,1);
elem=zeros(nel,8);

% Nodes.
inod=0;
for i=1:nL+1
    xx=(i-1)*dL;
    for j=1:nt+1
        yy=(j-1)*dt;
        for k=1:nh+1
            inod=inod+1;
            x(inod)=xx;
            y(inod)=yy;
            z(inod)=(k-1)*dh;
        end
    end
end
x0=x; y0=y; z0=z;

% HEX8 connectivity; matches the natural ordering in stiff_cons.
iel=0;
inod=0;
for i=1:nL
    for j=1:nt
        for k=1:nh
            inod=inod+1;
            iel=iel+1;
            ln1=[inod inod+1 inod+nh+2 inod+nh+1];
            ln2=ln1+(nh+1)*(nt+1);
            elem(iel,:)=[ln1 ln2];
        end
        inod=inod+1;
    end
    inod=inod+nh+1;
end

% Boundary conditions: x=0 restraint, lateral reference points,
% and symmetry in the z direction on the z=0 face.
cond=zeros(0,2);
for i=1:(nt+1)*(nh+1)
    cond(end+1,:)=[i 1];
end
cond(end+1,:)=[nt+1 2];
cond(end+1,:)=[nt+2 2];
for i=1:2:nnd
    cond(end+1,:)=[i 3];
end

% Distributed tip force, converted into equivalent nodal forces.
dF=F/(nh*nt);
forze=zeros((nt+1)*(nh+1),3);
ij=0;
il=0;
for j=1:nt+1
    for k=1:nh+1
        dF0=dF;
        if k==1 || k==nh+1, dF0=dF0/2; end
        if j==1 || j==nt+1, dF0=dF0/2; end
        il=il+1;
        ij=ij+1;
        forze(ij,:)=[nnd+1-il,2,-dF0];
    end
end

% Initial mesh and load/constraint symbols.
grafic3d0
title('Mesh')
for i=1:size(forze,1)
    nod=forze(i,1);
    dir=forze(i,2);
    ff=-forze(i,3)/20;
    if dir==1
        plot3([x(nod) x(nod)-ff],[y(nod) y(nod)],[z(nod) z(nod)],'m','linewidth',2)
    elseif dir==2
        plot3([x(nod) x(nod)],[y(nod) y(nod)-ff],[z(nod) z(nod)],'m','linewidth',2)
    else
        plot3([x(nod) x(nod)],[y(nod) y(nod)],[z(nod) z(nod)-ff],'m','linewidth',2)
    end
end
dth=min([dL,dh,dt]);
for i=1:size(cond,1)
    nod=cond(i,1);
    dir=cond(i,2);
    if dir==1
        plot3([x(nod) x(nod)-dth],[y(nod) y(nod)],[z(nod) z(nod)],'r','linewidth',2)
    elseif dir==2
        plot3([x(nod) x(nod)],[y(nod) y(nod)-dth],[z(nod) z(nod)],'r','linewidth',2)
    else
        plot3([x(nod) x(nod)],[y(nod) y(nod)],[z(nod) z(nod)-dth],'r','linewidth',2)
    end
end
fprintf('Beam: %d nodes, %d HEX8 elements.\n',nnd,nel);

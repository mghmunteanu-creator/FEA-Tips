% *** grafic3d0 *** Initial/current HEX8 mesh.
iposf=[1 2 3 4 5 6 7 8 1 2 6 5 2 3 7 6 3 4 8 7 4 1 5 8];
elemsf=reshape(reshape(elem(:,iposf)',[],1),4,6*nel)';
figure(5)
clf, hold on, grid on, axis('equal')
patch('Vertices',[x y z],'Faces',elemsf,...
      'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b')
xlabel('x'); ylabel('y'); zlabel('z')
view(2)

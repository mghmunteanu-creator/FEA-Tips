% *** main *** HEX8, consistent UL, elastic-perfectly plastic material.
% Typical use: clear; example='beam'; nstep=10; main
clear
format short e
iprob=2;
if iprob==1
    gen_beam
elseif iprob==2
    gen_lastra
end
nstep=50;
itermax=20;
tol=1e-4;
St=zeros(neq,nstep+1);
strnt=zeros(8*nel,6,nstep+1);
sigmt=zeros(8*nel,7,nstep+1);
iplst=zeros(8*nel,nstep+1);
niter=zeros(nstep,1);
for istep=1:nstep
    S=zeros(neq,1);
    errNR=Inf;
    iter=0;
    while errNR>tol && iter<itermax
        iplst(:,istep+1)=iplst(:,istep);
        iter=iter+1;
        stiff_cons
        dS=K\F;
        S=S-dS;
        errNR=sqrt(dS'*dS/neq);
        x=x-dS(1:3:neq);
        y=y-dS(2:3:neq);
        z=z-dS(3:3:neq);
    end
    if errNR>tol
        error('Global Newton-Raphson did not converge at step %d (%d iterations, residual %.4g).',istep,iter,errNR);
    end
    St(:,istep+1)=St(:,istep)+S;
    niter(istep)=iter;
    fprintf('Step %3d/%3d: %2d NR iterations, displacement correction %.4e\n',istep,nstep,iter,errNR);
        
    grafic3d0
    title(sprintf('Load step %d / %d',istep,nstep));
    drawnow
end

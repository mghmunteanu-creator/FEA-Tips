% *** plot_disp *** Displacement field at a selected load step.
iedge=0;
idisp=input('Displacement (1-u, 2-v, 3-w, Default=2): ');
if isempty(idisp), idisp=2; end
scale=input('Displacement scale (Default=1): ');
if isempty(scale), scale=1; end
istep=input('Load step (Default=nstep): ');
if isempty(istep), istep=nstep; end
if ~ismember(idisp,1:3) || istep<0 || istep>nstep
    error('Invalid displacement component or load step.');
end
Su=St(:,istep+1);
x1=x0+scale*Su(1:3:neq);
y1=y0+scale*Su(2:3:neq);
z1=z0+scale*Su(3:3:neq);
displ=Su(idisp:3:neq);
dmx=max(displ); dmn=min(displ);
iposf=[1 2 3 4 5 6 7 8 1 2 6 5 2 3 7 6 3 4 8 7 4 1 5 8];
faces=reshape(reshape(elem(:,iposf)',[],1),4,6*nel)';
figure(10)
clf, hold on, axis equal
if exist('turbo','file')==2, colormap(turbo(16)); else, colormap(jet(16)); end
if iedge==0
    patch('Vertices',[x1 y1 z1],'Faces',faces,'CData',displ,'FaceColor','interp','EdgeColor','none')
else
    patch('Vertices',[x1 y1 z1],'Faces',faces,'CData',displ,'FaceColor','interp','EdgeColor','w')
end
colorbar
names={'u','v','w'};
title({sprintf('%s, Load step %d',names{idisp},istep);...
       sprintf('min=%.6g  max=%.6g',dmn,dmx)})
xlabel('x'); ylabel('y'); zlabel('z')
view(2)
sides
drawnow
fprintf('Displacement min = %.6g; max = %.6g\n',dmn,dmx);

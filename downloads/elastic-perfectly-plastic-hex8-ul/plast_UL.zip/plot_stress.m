% *** plot_stress *** Stress recovered from eight Gauss points per HEX8.
iedge=0;
istress=input('Stress (1-sx, 2-sy, 3-sz, 4-txy, 5-tyz, 6-tzx, 7-VM, Default=1): ');
if isempty(istress), istress=1; end
scale=input('Displacement scale (Default=0): ');
if isempty(scale), scale=0; end
istep=input('Load step (Default=nstep): ');
if isempty(istep), istep=nstep; end
if ~ismember(istress,1:7) || istep<0 || istep>nstep
    error('Invalid stress component or load step.');
end
Su=St(:,istep+1);
x1=x0+scale*Su(1:3:neq);
y1=y0+scale*Su(2:3:neq);
z1=z0+scale*Su(3:3:neq);

% Gauss points are ordered to correspond to local HEX8 nodes.
accum=zeros(nnd,1);
count=zeros(nnd,1);
ig=0;
for ie=1:nel
    for j=1:8
        ig=ig+1;
        nod=elem(ie,j);
        accum(nod)=accum(nod)+sigmt(ig,istress,istep+1);
        count(nod)=count(nod)+1;
    end
end
stress=accum./max(count,1);
smx=max(stress); smn=min(stress);
faces=zeros(6*nel,4);
for ie=1:nel
    k=6*ie-5; nd=elem(ie,:);
    faces(k:k+5,:)=[nd([1 2 3 4]); nd([5 6 7 8]); ...
        nd([1 5 6 2]); nd([2 6 7 3]); nd([3 7 8 4]); nd([4 8 5 1])];
end
[~,~,ic]=unique(sort(faces,2),'rows');
face_count=accumarray(ic,1);
faces=faces(face_count(ic)==1,:);

figure(15+istress)
clf, hold on, axis equal
if exist('turbo','file')==2, colormap(turbo(16)); else, colormap(jet(16)); end
if iedge==0
    patch('Vertices',[x1 y1 z1],'Faces',faces,'CData',stress,'FaceColor','interp','EdgeColor','none')
else
    patch('Vertices',[x1 y1 z1],'Faces',faces,'CData',stress,'FaceColor','interp','EdgeColor','w')
end
colorbar
names={'\sigma_x','\sigma_y','\sigma_z','\tau_{xy}',...
       '\tau_{yz}','\tau_{zx}','\sigma_{VM}'};
title({sprintf('%s, Load step %d',names{istress},istep);...
       sprintf('min=%.6g  max=%.6g',smn,smx)})
xlabel('x'); ylabel('y'); zlabel('z')
view(2)
sides
drawnow
fprintf('Stress min = %.6g; max = %.6g\n',smn,smx);

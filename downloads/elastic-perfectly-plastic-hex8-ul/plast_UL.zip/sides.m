% *** sides *** Draw unique external HEX8 edges, using coordinates x1,y1,z1.
sid=zeros(12*nel,2);
is=0;
for ie=1:nel
    nodi=elem(ie,:);
    sid(is+1:is+12,:)=[nodi([1 2]); nodi([2 3]); nodi([3 4]); nodi([4 1]); ...
        nodi([5 6]); nodi([6 7]); nodi([7 8]); nodi([8 5]); ...
        nodi([1 5]); nodi([2 6]); nodi([3 7]); nodi([4 8])];
    is=is+12;
end
[~,~,ic]=unique(sort(sid,2),'rows');
nr=accumarray(ic,1);
sid=sid(nr(ic)==1,:);
for i=1:size(sid,1)
    nd=sid(i,:);
    plot3(x1(nd),y1(nd),z1(nd),'k')
end

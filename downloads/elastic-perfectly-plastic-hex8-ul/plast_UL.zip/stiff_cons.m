% *** stiff_cons ***
% HEX8 UL: spatial internal forces, consistent geometric tangent,
% and the original elastic-perfectly plastic local return algorithm.
E1=E*(1-nu)/((1+nu)*(1-2*nu));
nu1=nu/(1-nu);
G=E/(2*(1+nu));
D=[E1 nu1*E1 nu1*E1 0 0 0
   nu1*E1 E1 nu1*E1 0 0 0
   nu1*E1 nu1*E1 E1 0 0 0
   0 0 0 G 0 0
   0 0 0 0 G 0
   0 0 0 0 0 G];
tolii=1e-4;
iimax=20;
F=zeros(neq,1);
K=zeros(neq,neq);

% Gauss points in natural HEX8 node order, for nodal stress recovery.
str=[ 1 -1 -1  1  1 -1 -1  1
      1  1 -1 -1  1  1 -1 -1
      1  1  1  1 -1 -1 -1 -1]*sqrt(3)/3;
ig=0;
for ie=1:nel
    nodi=elem(ie,:);
    ip=zeros(1,24);
    ip(1:3:24)=3*nodi-2;
    ip(2:3:24)=3*nodi-1;
    ip(3:3:24)=3*nodi;
    xel0=x0(nodi); yel0=y0(nodi); zel0=z0(nodi);
    xelt=x(nodi);  yelt=y(nodi);  zelt=z(nodi);
    fel=zeros(24,1);
    kel=zeros(24,24);
    for j=1:8
        ig=ig+1;
        s=str(1,j); t=str(2,j); r=str(3,j);
        H=1/8*[(1+t)*(1+r) -(1+t)*(1+r) -(1-t)*(1+r)  (1-t)*(1+r)  (1+t)*(1-r) -(1+t)*(1-r) -(1-t)*(1-r)  (1-t)*(1-r)
               (1+s)*(1+r)  (1-s)*(1+r) -(1-s)*(1+r) -(1+s)*(1+r)  (1+s)*(1-r)  (1-s)*(1-r) -(1-s)*(1-r) -(1+s)*(1-r)
               (1+s)*(1+t)  (1-s)*(1+t)  (1-s)*(1-t)  (1+s)*(1-t) -(1+s)*(1+t) -(1-s)*(1+t) -(1-s)*(1-t) -(1+s)*(1-t)];

        Jt=H*[xelt yelt zelt];
        detJ=det(Jt);
        if ~isfinite(detJ) || detJ<=0
            error('Nonpositive current det(J) in element %d, Gauss point %d: %.6g',ie,j,detJ);
        end
        b=Jt\H;

        % 6x24 spatial strain-displacement matrix (engineering shear).
        B=zeros(6,24);
        for a=1:8
            ia=3*a-2:3*a;
            bx=b(1,a); by=b(2,a); bz=b(3,a);
            B(:,ia)=[bx 0 0
                     0 by 0
                     0 0 bz
                     by bx 0
                     0 bz by
                     bz 0 bx];
        end

        % Total Euler-Almansi strains measured from the initial geometry.
        J0=H*[xel0 yel0 zel0];
        detJ0=det(J0);
        if ~isfinite(detJ0) || detJ0<=0
            error('Nonpositive initial det(J) in element %d, Gauss point %d: %.6g',ie,j,detJ0);
        end
        Ftot=(J0\Jt)';
        Q=(Ftot*Ftot')\eye(3);
        ee=(eye(3)-Q)/2;
        e=[ee(1,1) ee(2,2) ee(3,3) 2*ee(1,2) 2*ee(2,3) 2*ee(3,1)];
        strnt(ig,:,istep+1)=e;

        % Original local elastic-perfectly plastic stress correction.
        % Keep the yield check and the plastic indicator as in the source.
        Dep=D;
        sig0=sigmt(ig,1:6,istep)';
        de=e'-strnt(ig,:,istep)';
        ds=D*de;
        if vonMises(sig0+ds)>sgy
            iplst(ig,istep+1)=1;
            ii=0; err=Inf; dlam=0;
            while err>tolii && ii<iimax
                ii=ii+1;
                sig=sig0+ds;
                sgm=mean(sig(1:3));
                svM=vonMises(sig);
                Fj=svM-sgy;
                V=3*[sig(1:3)-sgm; 2*sig(4:6)];
                Fsg=V/(2*svM);
                Fsg2=[ 2 -1 -1  0  0  0
                      -1  2 -1  0  0  0
                      -1 -1  2  0  0  0
                       0  0  0  6  0  0
                       0  0  0  0  6  0
                       0  0  0  0  0  6]/(2*svM) - (V*V')/(4*svM^3);
                p=[ds-D*de+dlam*D*Fsg; Fj];
                pd=[eye(6)+dlam*D*Fsg2 D*Fsg; Fsg' 0];
                dp=-pd\p;
                ds=ds+dp(1:6);
                dlam=dlam+dp(7);
                err=sqrt(dp'*dp);
            end
            if err>tolii
                error('Local plastic correction did not converge: element %d, Gauss %d, step %d',ie,j,istep);
            end
            D0=D-D*Fsg*Fsg'*D/(Fsg'*D*Fsg);
            Dep=(eye(6)+dlam*D0*Fsg2)\D0;
        end
        sig1=sig0+ds;
        sigmt(ig,:,istep+1)=[sig1' vonMises(sig1)];
        sig=sig1;
        sigma=[sig(1) sig(4) sig(6)
               sig(4) sig(2) sig(5)
               sig(6) sig(5) sig(3)];

        % Internal force and consistent UL element tangent.
        fel=fel+B'*sig*detJ;
        BQ=zeros(6,24);
        for a=1:8
            ia=3*a-2:3*a;
            BQ(:,ia)=B(:,ia)*Q;
        end
        km=B'*Dep*BQ;
        kg=zeros(24,24);
        for a=1:8
            ia=3*a-2:3*a;
            ba=b(:,a);
            sba=sigma*ba;
            for c=1:8
                ic=3*c-2:3*c;
                bc=b(:,c);
                kg(ia,ic)=sba*bc'-(sigma*bc)*ba';
            end
        end
        kel=kel+(km+kg)*detJ;
    end
    F(ip)=F(ip)+fel;
    K(ip,ip)=K(ip,ip)+kel;
end

% Essential boundary conditions.
loc=3*(cond(:,1)-1)+cond(:,2);
K(loc,:)=0; K(:,loc)=0; F(loc)=0;
K(loc,loc)=eye(numel(loc));
% Proportional fixed nodal loads.
loc=3*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;

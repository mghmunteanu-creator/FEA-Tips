# Section 21.1 — Finite rotations

Run `main.m` from this folder in MATLAB. Press any key at each pause to display the next slice.

The example constructs a complete three-dimensional finite element mesh from one slice, using six angular positions and a reflected and non-reflected slice at each position.

- `main.m`: computes and applies the rotations, reflection and translation.
- `nodes.m`: supplies the nodal coordinates of one slice.
- `elements.m`: supplies its element connectivity.
- `grafic3d0.m`: draws the finite element mesh.

The translation used in `main.m` is `[20 10 5]`. The MATLAB files are supplied unchanged. No MATLAB release was executed as part of the page revision; a tested release is not specified for this package.

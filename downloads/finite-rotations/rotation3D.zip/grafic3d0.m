% *** grafic3d0 ***
iposf=[1 2 3 1 2 4 1 3 4 2 3 4]; % pentru tetraedru cu 4 noduri
elemsf=elem(:,iposf)';
elemsf=reshape(elemsf(:),3,4*nel)';
patch('Vertices',x,'Faces',elemsf,'Facecolor',clr,'linewidth',0.5,'edgecolor',[0 0 1]*0.3)
drawnow


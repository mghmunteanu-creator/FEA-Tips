% main
clear 
format short e
nodes                               % nodal coordinates
elements                            % list of elements
figure(1), clf, hold on, grid on, axis('equal'), view(3)
xlabel('x'), ylabel('y'), zlabel('z')
axis([5 35 0 25 -8 20])
clr='g'; grafic3d0;                 % graphic representation of finite elements 
n0=[0 1 0];
%==========================================================================
Dxyz=[20 10 5];                     % translation
n=[2.5 1.7 1.5]; n=n/norm(n);       % unit vector
nt=[ 0     -n(3)   n(2)
     n(3)   0     -n(1)
    -n(2)   n(1)   0   ];
%First rotation matrix   
phi=acos(dot(n0,n));
nc=cross(n0,n);
nc=nc/norm(nc);
nct=[ 0      -nc(3)   nc(2)
     nc(3)   0      -nc(1)
    -nc(2)   nc(1)   0   ];
R1=eye(3)+sin(phi)*nct+(1-cos(phi))*nct^2;      % rotation matrix R1
%--------------------------------------------------------------------------
x0=x;   
Ra=[1  0  0; 0  1  0; 0  0 -1];                 % matrix Ra for reflection
for i=1:6
    phi0=(i-1)*pi/3;
    % Second rotation matrix
    pause
    R2=eye(3)+sin(phi0)*nt+(1-cos(phi0))*nt^2;  % rotation matrix R2
    x=(R2*R1*Ra*x0')'+ones(nnd,3)*diag(Dxyz);   % rotation, reflection & translation  
    clr='c'; grafic3d0
    pause
    x=(R2*R1*x0')'   +ones(nnd,3)*diag(Dxyz);   % rotation & translation
    clr='y'; grafic3d0
end
%light('position',[2.5 -1.1 1.5]*100)
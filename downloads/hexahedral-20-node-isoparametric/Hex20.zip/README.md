# Section 25.3 — HEX20

Linear elastic analysis of the cantilever using 20-node hexahedral elements
and 3 × 3 × 3 Gauss integration. Run `main.m` with all files in one folder.

- `gen.m`: input data, structured mesh, constraints and loading.
- `brick3d_20.m`: element stiffness, assembly and linear solution.
- `shape20.m`: interpolation functions and natural derivatives.
- `grafic3d0.m`: mesh display.
- `plot_disp.m`: displacement maps (default deformation scale 1).
- `plot_stress.m`: stress maps (default deformation scale 0).
- `sides.m`: element-edge display.

MATLAB is required. No solver-release compatibility test is claimed for this package.
`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases,
replace `turbo` with `jet`. This affects visualization only and does not change
the numerical results.

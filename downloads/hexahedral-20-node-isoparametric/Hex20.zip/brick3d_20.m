%*** brick3d_20 ***
n=length(x(:,1));	                % number of nodes
nel=length(elem(:,1));		        % number of finite elements
neq=3*n;                            % total number of equations (or unknowns)
K=sparse(neq,neq);                  % Stiffness matrix initialization
F=zeros(neq,1);                     % Load vector initialization

% Hooke's law:
E1 =E*(1-nu)/(1+nu)/(1-2*nu);
nu1=nu/(1-nu);
G=E/2/(1+nu);
DHooke=[     E1   nu1*E1       nu1*E1
	     nu1*E1       E1       nu1*E1
         nu1*E1   nu1*E1       E1 ];
DHooke(4,4)=G; DHooke(5,5)=G; DHooke(6,6)=G;
% Gauss points:
a = sqrt(3/5);
str=a*[-1  -1  -1  -1  -1  -1  -1  -1  -1   0   0   0   0   0   0   0   0   0   1   1   1   1   1   1   1   1   1
       -1  -1  -1   0   0   0   1   1   1  -1  -1  -1   0   0   0   1   1   1  -1  -1  -1   0   0   0   1   1   1
       -1   0   1  -1   0   1  -1   0   1  -1   0   1  -1   0   1  -1   0   1  -1   0   1  -1   0   1  -1   0   1];
ind= [  1   9   2  12   0  10   4  11   3  17   0  18   0   0   0  20   0  19   5  13   6  16   0  14   8  15   7];
 
wg = [1.7147e-01   2.7435e-01   1.7147e-01   2.7435e-01   4.3896e-01   2.7435e-01   1.7147e-01   2.7435e-01   1.7147e-01 ...
      2.7435e-01   4.3896e-01   2.7435e-01   4.3896e-01   7.0233e-01   4.3896e-01   2.7435e-01   4.3896e-01   2.7435e-01 ...
      1.7147e-01   2.7435e-01   1.7147e-01   2.7435e-01   4.3896e-01   2.7435e-01   1.7147e-01   2.7435e-01   1.7147e-01];
Bt=zeros(6,60,27*nel);
ib=0;
for ie=1:nel;
    nodi=elem(ie,:);
    %----------------------------------------------------------------------
    xel=x(nodi); 	% nodal
	yel=y(nodi); 	% coordinates
	zel=z(nodi); 	% 
	kel=zeros(60);
	for j=1:27;
        s=str(1,j);
        t=str(2,j);
        r=str(3,j);
        [~,dNds,dNdt,dNdr] = shape20(s,t,r);

        H=[dNds dNdt dNdr]';
        J= H*[ xel    yel   zel]; 	% Jacobian

        detJ=abs(det(J));
        J1=inv(J);
        b=J1*H;
        % strain-displacement matrix:
    	B(1,1:3:60)=b(1,:);
      	B(2,2:3:60)=b(2,:);
     	B(3,3:3:60)=b(3,:);

        B(4,1:3:60)=b(2,:);  B(4,2:3:60)=b(1,:); 
     	B(5,2:3:60)=b(3,:);  B(5,3:3:60)=b(2,:); 
        B(6,3:3:60)=b(1,:);  B(6,1:3:60)=b(3,:); 	 
        ib=ind(j);
        if ib~=0
            ii=20*ie-20+ib;
            Bt(:,:,ii)=B;
        end
        % element stiffness matrix:
        kel=kel+wg(j)*B'*DHooke*B*detJ;
    end	
    %----------------------------------------------------------------------
    % connectivity matrix:
    ipos(1:3:60)=3*nodi-2;
    ipos(2:3:60)=3*nodi-1;
    ipos(3:3:60)=3*nodi;
    K(ipos,ipos)=K(ipos,ipos)+kel;	% assembling process
end
% Constraints
loc=3*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 
% Concentrated force
loc=3*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)+forze(:,3); 
% solve the linear system
for i=1:neq
    if K(i,i)==0, K(i,i)=1;end
end
S=K\F;                                      

%*** gen ***
%==========================================================================
% Generates a structured mesh of 20-node brick elements
% ANSYS SOLID186 node numbering
%
% Local node numbering:
%
% Corners:
%   1=I, 2=J, 3=K, 4=L
%   5=M, 6=N, 7=O, 8=P
%
% Midside nodes:
%   9 =Q : I-J
%   10=R : J-K
%   11=S : K-L
%   12=T : L-I
%
%   13=U : M-N
%   14=V : N-O
%   15=W : O-P
%   16=X : P-M
%
%   17=Y : I-M
%   18=Z : J-N
%   19=A : K-O
%   20=B : L-P
%==========================================================================
% dimensions
L=200;  % Length (along x-axis)
t=50;   % cross-section width (along y-axis)
h=40;   % cross-section height (along z-axis)

E=2e5;  % Young's modulus
nu=0.3; % Poisson's ratio
F=8000; % Force

in=3;
nL= 8*in;   % number of elements along x-axis
nt= 3*in;   % number of elements along y-axis
nh= 2*in;   % number of elements along z-axis

%==========================================================================
% ELEMENT SIZE

dL=L/nL;
dt=t/nt;
dh=h/nh;

nel=nL*nt*nh;

%--------------------------------------------------------------------------
% Number of nodes for a conforming 20-node brick mesh:
%
% vertices
% + midside nodes parallel to x
% + midside nodes parallel to y
% + midside nodes parallel to z

nndmax = ...
    (nL+1)*(nt+1)*(nh+1) + ...
     nL   *(nt+1)*(nh+1) + ...
    (nL+1)* nt   *(nh+1) + ...
    (nL+1)*(nt+1)* nh;

x=zeros(nndmax,1);
y=zeros(nndmax,1);
z=zeros(nndmax,1);

elem=zeros(nel,20);

%==========================================================================
% NODE GENERATION
%
% A lattice with half-element spacing is used.
%
% Only:
%   - corner nodes
%   - midside nodes
% are retained.
%
% Face-center and element-center nodes are NOT generated.
ID=zeros(2*nL+1,2*nt+1,2*nh+1);
inod=0;
for ix=0:2*nL
    for iy=0:2*nt
        for iz=0:2*nh
            % Number of odd indices
            no = mod(ix,2)+mod(iy,2)+mod(iz,2);
            % no=0 -> corner
            % no=1 -> midside node
            if no<=1
                inod=inod+1;
                ID(ix+1,iy+1,iz+1)=inod;
                x(inod)=ix*dL/2;
                y(inod)=iy*dt/2;
                z(inod)=iz*dh/2;
            end
        end
    end
end
nnd=inod;
%==========================================================================
% ELEMENT CONNECTIVITY
%
% ANSYS SOLID186 numbering:
%
%       P---------W---------O
%      /|                  /|
%     X |                 V |
%    /  |                /  |
%   M---------U---------N    |
%   |   T                |   S
%   |   |                |   |
%   Y   L---------S------|---K
%   |  /                 Z  /
%   | T                  | R
%   |/                   |/
%   I---------Q----------J
%
% Here I-J-K-L is the x = const left face,
% and M-N-O-P is the x = const right face.

iel=0;
for i=1:nL
    ix0=2*(i-1)+1;
    ixm=ix0+1;
    ix1=ix0+2;
    for j=1:nt
        iy0=2*(j-1)+1;
        iym=iy0+1;
        iy1=iy0+2;
        for k=1:nh
            iz0=2*(k-1)+1;
            izm=iz0+1;
            iz1=iz0+2;
            iel=iel+1;
            %--------------------------------------------------------------
            % Corner nodes I,J,K,L,M,N,O,P
            I = ID(ix0,iy0,iz0);
            J = ID(ix0,iy0,iz1);
            K = ID(ix0,iy1,iz1);
            L1= ID(ix0,iy1,iz0);
            M = ID(ix1,iy0,iz0);
            N = ID(ix1,iy0,iz1);
            O = ID(ix1,iy1,iz1);
            P = ID(ix1,iy1,iz0);
            %--------------------------------------------------------------
            % Midside nodes Q,...,B
            Q = ID(ix0,iy0,izm);   % I-J
            R = ID(ix0,iym,iz1);   % J-K
            S = ID(ix0,iy1,izm);   % K-L
            T = ID(ix0,iym,iz0);   % L-I

            U = ID(ix1,iy0,izm);   % M-N
            V = ID(ix1,iym,iz1);   % N-O
            W = ID(ix1,iy1,izm);   % O-P
            X = ID(ix1,iym,iz0);   % P-M

            Y = ID(ixm,iy0,iz0);   % I-M
            Z = ID(ixm,iy0,iz1);   % J-N
            A = ID(ixm,iy1,iz1);   % K-O
            B = ID(ixm,iy1,iz0);   % L-P
            %--------------------------------------------------------------
            elem(iel,:) = ...
                [I J K L1 M N O P ...
                 Q R S T U V W X Y Z A B];
        end
    end
end
nel=iel;
%==========================================================================
% CONSTRAINTS
%
% All SOLID186 nodes belonging to x=0 are included.
tol=1.e-10;
face0=find(abs(x)<tol);
cond=zeros(0,2);
% x displacement = 0 on x=0 face
cond=[cond;
      face0 ones(length(face0),1)];
% Transverse displacement constraints:
% y and z constrained along z = round(nh/2)*dh
z0=round(nh/2)*dh;
line0=face0(abs(z(face0)-z0)<tol);
cond=[cond;
      line0 2*ones(length(line0),1);
      line0 3*ones(length(line0),1)];
%==========================================================================
% LOADS
% loads are applied to the CORNER nodes of the end face x=L.
dF=F/nh/nt;
forze=zeros((nt+1)*(nh+1),3);
ij=0;
for j=0:nt
    for k=0:nh
        nod=ID(2*nL+1,2*j+1,2*k+1);
        dF0=dF;
        if k==0 || k==nh
            dF0=dF0/2;
        end
        if j==0 || j==nt
            dF0=dF0/2;
        end
        ij=ij+1;
        forze(ij,1)=nod;
        forze(ij,2)=3;
        forze(ij,3)=-dF0;

    end
end
%==========================================================================
nnd
nel
neq=3*nnd
%==========================================================================
grafic3d0
title('Mesh')
nl=length(forze(:,1));       
for i=1:nl
    nod=forze(i,1);
    dir=forze(i,2);
    ff =-dh*0.9*forze(i,3)/max(abs(forze(:,3)));
    if dir==1
        plot3([x(nod) x(nod)-ff],[y(nod) y(nod)],   [z(nod) z(nod)],'m','linewidth',2.5)
    elseif dir==2
        plot3([x(nod) x(nod)],   [y(nod) y(nod)-ff],[z(nod) z(nod)],'m','linewidth',2.5)
    elseif dir==3
        plot3([x(nod) x(nod)],   [y(nod) y(nod)],   [z(nod) z(nod)-ff],'m','linewidth',2.5)
    end
end

dth=min([dL,dh,dt])*0.45;
for i=1:length(cond(:,1))
    nod=cond(i,1);
    dir=cond(i,2);
    if dir==1
        plot3([x(nod) x(nod)-dth],[y(nod) y(nod)],    [z(nod) z(nod)],'r','linewidth',2)
    elseif dir==2
        plot3([x(nod) x(nod)],    [y(nod) y(nod)-dth],[z(nod) z(nod)],'r','linewidth',2)
    elseif dir==3
        plot3([x(nod) x(nod)],    [y(nod) y(nod)],    [z(nod) z(nod)-dth],'r','linewidth',2)
    end
end

drawnow

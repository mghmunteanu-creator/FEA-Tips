%*** grafic3d0 ***
format short e
iposf=[1 2 3 4 5 6 7 8 1 2 6 5 2 3 7 6 3 4 8 7 4 1 5 8];
elemsf=elem(:,iposf)';
elemsf=reshape(elemsf(:),4,6*nel)';
figure(1)
clf
hold on
axis('equal')
plot3(x,y,z,'.','markersize',8)
patch('Vertices',[x y z],'Faces',elemsf,'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b')
grid on
xlabel('x')
ylabel('y')
zlabel('z')
view(3)

%*** main ***
clear
gen
brick3d_20
plot_disp
plot_stress

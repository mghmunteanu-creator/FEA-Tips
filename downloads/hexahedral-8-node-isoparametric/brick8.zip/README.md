# Section 25.1 — HEX8 linear analysis

Run `main.m` in MATLAB with all files in the current folder.

- `main.m`: runs input generation, the HEX8 solver, and result plotting.
- `gen.m`: cantilever geometry, mesh, constraints and loads (60 × 16 × 12 elements).
- `brick3d.m`: element stiffness, sparse assembly and linear solution.
- `grafic3d0.m`: displays the mesh.
- `plot_disp.m`: displacement colour maps.
- `plot_stress.m`: stress and von Mises colour maps.
- `sides.m`: draws selected edges of the deformed mesh.

Units: mm, N and MPa. The default deformation scale is 1 in `plot_disp.m` and 0 in `plot_stress.m`. Press Enter at the scale prompt to use the default. Enter 120 only to reproduce the deformed display used for the Section 25.1 figures; this affects displayed geometry only, not computed values.

MATLAB with graphics support is required. This package has not been executed as part of the website preparation.
`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results. This note does not establish compatibility of the full solver with older releases.

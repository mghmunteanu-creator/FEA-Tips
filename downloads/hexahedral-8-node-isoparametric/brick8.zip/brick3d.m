%*** brick3d ***
n=length(x(:,1));	                % number of nodes
nel=length(elem(:,1));		        % number of finite elements
neq=3*n;                           % total number of equations (or unknowns)
K=sparse(neq,neq);                  % Stiffness matrix initialization
F=zeros(neq,1);                     % Load vector initialization
% Gauss points

str=[ 1  -1  -1   1   1  -1  -1   1
      1   1  -1  -1   1   1  -1  -1
      1   1   1   1  -1  -1  -1  -1]*sqrt(3)/3;

E1 =E*(1-nu)/(1+nu)/(1-2*nu);
nu1=nu/(1-nu);
G=E/2/(1+nu);
DHooke=[     E1   nu1*E1       nu1*E1
	     nu1*E1       E1       nu1*E1
         nu1*E1   nu1*E1       E1 ];
DHooke(4,4)=G; DHooke(5,5)=G; DHooke(6,6)=G;
for ie=1:nel;
    nodi=elem(ie,1:8);
    %----------------------------------------------------------------------
    xel=x(nodi); 	% nodal
	yel=y(nodi); 	% coordinates
	zel=z(nodi); 	% 
	kel=zeros(24);
	for j=1:8;
        s=str(1,j);
        t=str(2,j);
        r=str(3,j);
        H=1/8*[(1+t)*(1+r)  -(1+t)*(1+r)  -(1-t)*(1+r)   (1-t)*(1+r)   (1+t)*(1-r)   -(1+t)*(1-r)   -(1-t)*(1-r)   (1-t)*(1-r)   	% derivatives of the
               (1+s)*(1+r)   (1-s)*(1+r)  -(1-s)*(1+r)  -(1+s)*(1+r)   (1+s)*(1-r)    (1-s)*(1-r)   -(1-s)*(1-r)  -(1+s)*(1-r) 	    % shape functions
               (1+s)*(1+t)   (1-s)*(1+t)   (1-s)*(1-t)   (1+s)*(1-t)  -(1+s)*(1+t)   -(1-s)*(1+t)   -(1-s)*(1-t)  -(1+s)*(1-t)]; 	% shape functions
        J= H*[ xel    yel   zel]; 	% Jacobian

        detJ=abs(det(J));
        J1=inv(J);
        b=J1*H;
        % strain-displacement matrix:
    	B(1,1:3:24)=b(1,:);
      	B(2,2:3:24)=b(2,:);
     	B(3,3:3:24)=b(3,:);

        B(4,1:3:24)=b(2,:);  B(4,2:3:24)=b(1,:); 
     	B(5,2:3:24)=b(3,:);  B(5,3:3:24)=b(2,:); 
        B(6,3:3:24)=b(1,:);  B(6,1:3:24)=b(3,:); 	 

        % element stiffness matrix:
        kel=kel+B'*DHooke*B*detJ;
    end	
    %----------------------------------------------------------------------
    % connectivity matrix:
    ipos(1:3:24)=3*nodi-2;
    ipos(2:3:24)=3*nodi-1;
    ipos(3:3:24)=3*nodi;
    K(ipos,ipos)=K(ipos,ipos)+kel;	% assembling process
end
% Constraints
loc=3*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 
% Concentrated force
loc=3*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)+forze(:,3); 
% solve the linear system
for i=1:neq
    if K(i,i)==0, K(i,i)=1;end
end
S=K\F;                                      

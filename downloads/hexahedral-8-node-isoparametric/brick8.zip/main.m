%*** main ***
clear
gen
brick3d
plot_disp
plot_stress

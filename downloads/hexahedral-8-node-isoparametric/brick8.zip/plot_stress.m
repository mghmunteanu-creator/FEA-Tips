%*** plot_stress ***

iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - does not plot         
istress=input('Stress (1-sx, 2-sy, 3-sz, 4-txy, 5-tyz, 6-tzx, 7-VM, Default=1): ');
if length(istress)==0, istress=1; end
scale=input('Displacement scale, Default=0: ');
if length(scale)==0, scale=0; end
u=S(1:3:neq);
v=S(2:3:neq);
w=S(3:3:neq);

% Hooke's law:
E1 =E*(1-nu)/(1+nu)/(1-2*nu);
nu1=nu/(1-nu);
G=E/2/(1+nu);
DHooke=[     E1   nu1*E1       nu1*E1
    nu1*E1       E1       nu1*E1
    nu1*E1   nu1*E1       E1 ];
DHooke(4,4)=G; DHooke(5,5)=G;; DHooke(6,6)=G;

% Gauss points:
str=[ 1  -1  -1   1   1  -1  -1   1
      1   1  -1  -1   1   1  -1  -1
      1   1   1   1  -1  -1  -1  -1]*sqrt(3)/3;

B=zeros(6,24);
ig=0;
sigmat=zeros(8*nel,7);
for ie=1:nel;
    nodi=elem(ie,1:8);
    ip(1:3:24)=3*nodi-2;
    ip(2:3:24)=3*nodi-1;
    ip(3:3:24)=3*nodi;
    sel=S(ip);
    %----------------------------------------------------------------------
    xel=x(nodi); 	% nodal
	yel=y(nodi); 	% coordinates
	zel=z(nodi); 	% 
	kel=zeros(24);
	for j=1:8
        ig=ig+1;
        s=str(1,j);
        t=str(2,j);
        r=str(3,j);
        H=1/8*[(1+t)*(1+r)  -(1+t)*(1+r)  -(1-t)*(1+r)   (1-t)*(1+r)   (1+t)*(1-r)   -(1+t)*(1-r)   -(1-t)*(1-r)   (1-t)*(1-r)   	% derivatives of the
               (1+s)*(1+r)   (1-s)*(1+r)  -(1-s)*(1+r)  -(1+s)*(1+r)   (1+s)*(1-r)    (1-s)*(1-r)   -(1-s)*(1-r)  -(1+s)*(1-r) 	    % shape functions
               (1+s)*(1+t)   (1-s)*(1+t)   (1-s)*(1-t)   (1+s)*(1-t)  -(1+s)*(1+t)   -(1-s)*(1+t)   -(1-s)*(1-t)  -(1+s)*(1-t)]; 	% shape functions
        J= H*[ xel    yel   zel]; 	% Jacobian

        detJ=abs(det(J));
        J1=inv(J);
        b=J1*H;
        % strain-displacement matrix:
    	B(1,1:3:24)=b(1,:);
      	B(2,2:3:24)=b(2,:);
     	B(3,3:3:24)=b(3,:);

        B(4,1:3:24)=b(2,:);  B(4,2:3:24)=b(1,:); 
     	B(5,2:3:24)=b(3,:);  B(5,3:3:24)=b(2,:); 
        B(6,3:3:24)=b(1,:);  B(6,1:3:24)=b(3,:); 	 


        sigma=DHooke*B*sel;   % stress calculation
        sgech=sqrt(sigma(1)^2+sigma(2)^2+sigma(3)^2-...
            sigma(1)*sigma(2)-sigma(2)*sigma(3)-sigma(3)*sigma(1)+...
            3*sigma(4)^2+3*sigma(5)^2+3*sigma(6)^2);
        sigmat(ig,:)=[sigma' sgech];
    end
end

x1=x+scale*u;
y1=y+scale*v;
z1=z+scale*w;
strs=zeros(nnd,2);
ig=0;
for i=1:nel
    for j=1:8
        nod=elem(i,j);
        strs(nod,2)=strs(nod,2)+1;
        ig=ig+1;
        strs(nod,1)=strs(nod,1)+sigmat(ig,istress);
    end
end
stress(:,1)=strs(:,1)./strs(:,2);
smx=max(stress);
smn=min(stress);

elem6=zeros(6*nel,4);
for ie=1:nel
    ii=6*ie-5;
    nodi=elem(ie,:);
    elem6(ii:ii+5,:)=[nodi([1 2 3 4])
                      nodi([5 6 7 8])
                      nodi([1 5 6 2])
                      nodi([2 6 7 3])
                      nodi([3 7 8 4])
                      nodi([4 8 5 1])];
end
elem6_sort=sort(elem6,2);
[~,~,ic]=unique(elem6_sort,'rows');
nr=accumarray(ic,1);
elem6=elem6(nr(ic)==1,:);

figure(5+istress)
clf
hold on
axis('equal')
colormap(turbo(16));
if iedge==0
    patch('Vertices',[x1 y1 z1],'Faces',elem6,'CData',stress,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[x1 y1 z1],'Faces',elem6,'CData',stress,'Facecolor','interp','edgecolor','w')
end
colorbar
view(3)
max_value=smx
min_value=smn

lighting phong

titlu='\sigma_x\sigma_y\sigma_z\tau_x_y\tau_y_z\tau_z_xVM      u       v       w       ';
sss=titlu(8*(istress-1)+1:8*istress);
title({sss;['min= ',num2str(smn),'  max=',num2str(smx)]})

xlabel('x')
ylabel('y')
zlabel('z')
view([-234 12]);
view(3)
sides

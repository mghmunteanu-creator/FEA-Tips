# Section 18.2 MATLAB programs

This package contains the Q4 plane-stress Total Lagrangian example for the nearly incompressible Mooney-Rivlin material.

- `main.m` controls the load steps and Newton iterations.
- `gen.m` reads the mesh and defines the material constants, boundary conditions, and loading.
- `stiff.m` evaluates the element internal-force vector and tangent stiffness matrix.
- `MoonRiv_stress.m` evaluates the plane-stress constitutive response using the approximation `J=1`.
- `plot_disp.m`, `plot_strain.m`, and `plot_stress.m` plot displacement, Green-Lagrange-strain, and second Piola-Kirchhoff-stress maps.
- `nodes` and `elements` contain the mesh data.

Run `main.m`. The plotting programs have explicit prompts and defaults. `plot_disp.m` uses a default deformation scale of 1. `plot_strain.m` and `plot_stress.m` retain the default scale of 0 so that their maps are displayed on the undeformed configuration.

The package was executed successfully with MATLAB R2026a.

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

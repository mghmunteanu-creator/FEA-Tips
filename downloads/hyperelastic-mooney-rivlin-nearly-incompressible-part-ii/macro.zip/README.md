# Section 18.2 ANSYS macro

`hip_pl_str.mac` reproduces the perforated-plate plane-stress example with the Mooney-Rivlin material model.

This macro was validated in the original version of the example. It has been transferred to the present edition without technical modification and was therefore not re-executed during the current revision.

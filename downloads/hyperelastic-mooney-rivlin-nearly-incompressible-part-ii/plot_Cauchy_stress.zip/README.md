# Section 18.2 Cauchy-stress postprocessing

The package contains `convert_stress.m`, which converts the stored second Piola-Kirchhoff stresses to Cauchy stresses, and `plot_stress_Cauchy.m`, which averages the selected component at the nodes and plots it.

Run the main Section 18.2 analysis first, then run `plot_stress_Cauchy.m`. In this formulation `J=1`, so the conversion is `sigma=F*S*F'`. The plotting program has explicit prompts and retains the default scale of 0 so that the stress map is displayed on the undeformed configuration.

The postprocessing programs were executed successfully with MATLAB R2026a.

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

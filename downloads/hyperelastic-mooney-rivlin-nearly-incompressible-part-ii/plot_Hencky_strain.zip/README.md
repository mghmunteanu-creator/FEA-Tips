# Section 18.2 Hencky-strain postprocessing

The package contains `strain_Hencky.m`, which evaluates Hencky strains at the Gauss points, and `plot_strain_Hencky.m`, which averages the selected component at the nodes and plots it.

Run the main Section 18.2 analysis first, then run `plot_strain_Hencky.m`. The plotting program has explicit prompts and retains the default scale of 0 so that the strain map is displayed on the undeformed configuration.

The postprocessing programs were executed successfully with MATLAB R2026a.

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

# Section 18.1 MATLAB programs

The package contains the Q4 plane-strain Total Lagrangian example for the nearly incompressible Mooney–Rivlin material.

- `main.m` controls the load steps and Newton iterations.
- `gen.m` reads the supplied mesh, defines the boundary conditions, loading, and material constants.
- `stiff.m` evaluates the element internal-force vector and tangent stiffness matrix.
- `MoonRiv_strain.m` evaluates the invariants, reduced invariants, second Piola–Kirchhoff stresses, and material tangent.
- `plot_disp.m` and `plot_strain.m` plot displacement and Green–Lagrange-strain maps.
- `nodes` and `elements` contain the mesh data.

Run `main.m`. The plotting programs have explicit defaults. `plot_disp.m` uses a default deformation scale of 1, while `plot_strain.m` uses the original default scale of 0 so that the strain map is displayed on the undeformed configuration.

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

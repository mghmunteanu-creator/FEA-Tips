# Section 18.1 Hencky-strain postprocessing

The package contains `strain_Hencky.m`, which evaluates the Hencky strains at the Gauss points, and `plot_strain_Hencky.m`, which averages the selected component at the nodes and plots it.

Run the main Section 18.1 analysis first, then run `plot_strain_Hencky.m`. The plotting program has explicit defaults and uses the original default scale of 0 so that the strain map is displayed on the undeformed configuration.

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

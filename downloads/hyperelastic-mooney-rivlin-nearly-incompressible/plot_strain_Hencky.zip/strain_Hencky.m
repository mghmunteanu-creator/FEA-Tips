%*** strain_Hencky ***
st=[1  -1  -1   1
    1   1  -1  -1]*sqrt(3)/3;
strainH=zeros(4*nel,3,nstep+1); 
ig=0;
for i=1:nel;
    nodo1=elem(i,1); nodo2=elem(i,2); nodo3=elem(i,3); nodo4=elem(i,4);
    % conectivity matrix:
    ipos=[2*nodo1-1  2*nodo1  2*nodo2-1  2*nodo2  2*nodo3-1  2*nodo3  2*nodo4-1  2*nodo4];
    sel=St(ipos,istep+1);
	xel=[x(nodo1) x(nodo2) x(nodo3) x(nodo4)]';
	yel=[y(nodo1) y(nodo2) y(nodo3) y(nodo4)]'; 
	for j=1:4;
        ig=ig+1;
        s=st(1,j);
        t=st(2,j);
        H=[(1+t)/4  -(1+t)/4  -(1-t)/4  (1-t)/4
           (1+s)/4   (1-s)/4  -(1-s)/4 -(1+s)/4]; 	
        J=H*[ xel    yel];                           % Jacobian
        J1=inv(J);
        b=J1*H;
        Bux=[b(1,1)       0    b(1,2)       0    b(1,3)       0    b(1,4)       0];
        Buy=[b(2,1)       0    b(2,2)       0    b(2,3)       0    b(2,4)       0];
        Bvx=[   0    b(1,1)       0    b(1,2)       0    b(1,3)       0    b(1,4)];
        Bvy=[   0    b(2,1)       0    b(2,2)       0    b(2,3)       0    b(2,4)];    
        ux=Bux*sel;
        uy=Buy*sel;
        vx=Bvx*sel;
        vy=Bvy*sel; 
        FF =[1+ux uy; vx 1+vy];
        C=FF'*FF;
        U=sqrtm(C);
        ee=logm(U);      % Hencky strain tensor
        %ee=U-eye(2);    % Biot strain
        strainH(ig,:,istep+1)=[ee(1,1) ee(2,2) 2*ee(1,2)];
    end
end


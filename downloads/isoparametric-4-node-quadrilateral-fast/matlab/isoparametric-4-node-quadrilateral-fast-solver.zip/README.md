# Q4 fast MATLAB solver — Section 9.5

## Purpose

`plane2d_fast.m` is the vectorized alternative to the standard Q4 solver
presented in Section 9.4 of FEA Tips. It evaluates all four Gauss-point
contributions for every element simultaneously, uses `multiprod.m` for the
batched matrix products, and assembles the global sparse stiffness matrix
directly.

## How to use the routine

1. Download the complete MATLAB package from Section 9.4.
2. Add `plane2d_fast.m` and `multiprod.m` to the same MATLAB folder.
3. In `main.m`, replace the call `plane2d` with `plane2d_fast`.
4. Run `main`.

The geometry, material, loading, constraints, and plotting routines remain
those supplied in Section 9.4.

## Files in this package

- `plane2d_fast.m` — vectorized four-node quadrilateral solver and sparse assembly
- `multiprod.m` — simultaneous products of matrices stored in N-D arrays
- `LICENSE-multiprod.txt` — BSD-style license accompanying `multiprod.m`
- `README.md` — these instructions

## `multiprod` dependency

`multiprod.m` is by Paolo de Leva and is redistributed under its BSD-style
license. The license text is included in this package. The official MATLAB
Central distribution page is:

https://www.mathworks.com/matlabcentral/fileexchange/8773-multiple-matrix-multiplications-with-array-expansion-enabled

## Verification and compatibility

The standard and fast routines were executed in MATLAB R2026a on the
80 × 200 and 100 × 250 benchmark meshes. The nodal displacements and recovered
stress components agreed to normal double-precision accuracy.

The routine uses standard MATLAB sparse-matrix operations. `multiprod` uses
`bsxfun`, which is available in MATLAB R2007a and later. Compatibility with
MATLAB releases other than R2026a is expected but was not tested for this
package.

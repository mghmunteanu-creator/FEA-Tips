%*** plane2d_fast ***
tic
nnd=length(x(:,1));	                % number of nodes
nel=length(elem(:,1));		        % number of finite elements
ngn=2;                              % number of DOF/node
ngel=8;                             % dimension of element stiffness matrix
neq=nnd*ngn;                        % total number of equations (unknowns)
gss=sqrt(3)/3;
K=sparse(neq,neq);                  % Stiffness matrix initialization
F=zeros(neq,1);                     % Load vector initialization

nodo1=ones(4,1)*elem(:,1)'; 
nodo2=ones(4,1)*elem(:,2)'; 
nodo3=ones(4,1)*elem(:,3)'; 
nodo4=ones(4,1)*elem(:,4)'; 
nodo1=nodo1(:); nodo2=nodo2(:); nodo3=nodo3(:); nodo4=nodo4(:);
E1=E/(1-nu*nu);		
G=E/2/(1+nu);
nel4=4*nel;
xel=[x(nodo1) x(nodo2) x(nodo3) x(nodo4)]'; 	
yel=[y(nodo1) y(nodo2) y(nodo3) y(nodo4)]'; 	
xyel=zeros(4,2,nel4);
xyel(:,1,:)=xel;
xyel(:,2,:)=yel;

ss=[gss -gss -gss  gss]'*ones(1,nel); ss=ss(:);    % Gauss points
tt=[gss  gss -gss -gss]'*ones(1,nel); tt=tt(:);

dNst=zeros(2,4,nel4); 
dNst(1,1,:)= (1+tt)/4; dNst(1,2,:)=-(1+tt)/4; dNst(1,3,:)=-(1-tt)/4; dNst(1,4,:)= (1-tt)/4;
dNst(2,1,:)= (1+ss)/4; dNst(2,2,:)= (1-ss)/4; dNst(2,3,:)=-(1-ss)/4; dNst(2,4,:)=-(1+ss)/4;

J=multiprod(dNst,xyel);                             % Jacobian
detJ=J(1,1,:).*J(2,2,:)-J(1,2,:).*J(2,1,:);
J1=zeros(2,2,nel4);                                 % J1=inv(J);
J1(1,1,:)= J(2,2,:)./detJ;
J1(2,2,:)= J(1,1,:)./detJ;
J1(1,2,:)=-J(1,2,:)./detJ;
J1(2,1,:)=-J(2,1,:)./detJ;
br=multiprod(J1,dNst);
B=zeros(3,8,nel4);
B(1,1,:)=br(1,1,:); B(1,3,:)=br(1,2,:); B(1,5,:)=br(1,3,:); B(1,7,:)=br(1,4,:);
B(2,2,:)=br(2,1,:); B(2,4,:)=br(2,2,:); B(2,6,:)=br(2,3,:); B(2,8,:)=br(2,4,:);
B(3,1,:)=br(2,1,:); B(3,3,:)=br(2,2,:); B(3,5,:)=br(2,3,:); B(3,7,:)=br(2,4,:);
B(3,2,:)=br(1,1,:); B(3,4,:)=br(1,2,:); B(3,6,:)=br(1,3,:); B(3,8,:)=br(1,4,:);

detJ=abs(detJ(:))*th(:);
E1=E1*detJ;
G =G *detJ;
DHooke=zeros(3,3,nel4);
DHooke(1,1,:)=E1;
DHooke(1,2,:)=nu*E1;
DHooke(2,1,:)=nu*E1;
DHooke(2,2,:)=E1;
DHooke(3,3,:)=G;

DB=multiprod(DHooke,B);
kelt=reshape(multiprod(permute(B,[2 1 3]),DB),ngel^2,nel4);

ipos0=[ngn*nodo1-1 ngn*nodo1 ngn*nodo2-1 ngn*nodo2 ngn*nodo3-1 ngn*nodo3 ngn*nodo4-1 ngn*nodo4]';
ipos1=[ipos0; ipos0; ipos0; ipos0; ipos0; ipos0; ipos0; ipos0];
ipos2=permute(reshape(ipos1,ngel,ngel,nel4),[2 1 3]);
K=sparse(ipos1,ipos2(:),kelt(:),neq,neq);           % assembling

% Constraints
loc=ngn*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 

% Concentrated force
loc=ngn*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)+forze(:,3);      
toc
tic
S=K\F;                                      % solving the linear system                                     
toc
DHooke=DHooke(:,:,1)/detJ(1);

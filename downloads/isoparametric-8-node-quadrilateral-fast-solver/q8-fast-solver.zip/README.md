# Section 9.7 — Q8 Fast Solver

Run `main.m` for the linear plane-stress cantilever example. This calls
`gen`, `plane2d8_fast`, `plot_disp`, and `plot_stress` in that order.

- `gen.m`: geometry, Q8 mesh, material, constraints, loading, and mesh plot.
- `plane2d8_fast.m`: vectorized nine-Gauss-point Q8 stiffness calculation,
  direct sparse assembly, and solution. Its two printed times cover assembly
  and solution, respectively.
- `plane2d8.m`: standard Q8 solver for comparison; replace the fast call in
  `main.m` with `plane2d8` to use it.
- `multiprod.m`: page-wise matrix products by Paolo de Leva; see the included
  `LICENSE-multiprod.txt`.
- `plot_disp.m`: displacement plot; selector defaults to 2, scale to 1.
- `plot_stress.m`: nodally averaged stresses; selector defaults to 1, scale to 0.

The default example mesh in `gen.m` is `nH=80`, `nL=200`.
The Section 9.7 timing comparisons use only `nH=60, nL=150` and
`nH=80, nL=200`. Dimensions are in mm, forces in N, stresses in MPa.
The standard and fast formulations solve the same finite-element problem.

Tested in MATLAB R2026a Update 4 on the two Section 9.7 benchmark meshes.
`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases,
replace `turbo` with `jet`. This affects visualization only and does not
change the numerical results.

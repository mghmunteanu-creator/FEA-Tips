clear
gen
plane2d8_fast
plot_disp
plot_stress

% *** plane2d8_fast ***
% Vectorized Q8 plane-stress finite element formulation
% Requires multiprod.m
tic
nnd=length(x(:,1));                 % number of nodes
nel=length(elem(:,1));              % number of finite elements
ngn=2;                              % number of DOF/node
ngel=16;                            % dimension of element stiffness matrix
neq=nnd*ngn;                        % total number of equations (unknowns)
K=sparse(neq,neq);                  % stiffness matrix initialization
F=zeros(neq,1);                     % load vector initialization

% -------------------------------------------------------------------------
% 3x3 Gauss integration
xgss=sqrt(0.6);
xgauss=[-xgss 0 xgss];
wgauss=[5/9 8/9 5/9];

sgp=[-xgss -xgss -xgss  0 0 0  xgss xgss xgss]';
tgp=[-xgss  0      xgss -xgss 0 xgss -xgss 0 xgss]';
wgp=[5/9*5/9
     5/9*8/9
     5/9*5/9
     8/9*5/9
     8/9*8/9
     8/9*5/9
     5/9*5/9
     5/9*8/9
     5/9*5/9];

ngp=9;
nel9=ngp*nel;

ss=repmat(sgp,nel,1);
tt=repmat(tgp,nel,1);
ww=repmat(wgp,nel,1);

% -------------------------------------------------------------------------
% Element nodes repeated for the 9 Gauss points
nodo=zeros(nel9,8);
for k=1:8
    a=ones(ngp,1)*elem(:,k)';
    nodo(:,k)=a(:);
end

% Nodal coordinates for all elements / Gauss points
xel=zeros(8,nel9);
yel=zeros(8,nel9);
for k=1:8
    xel(k,:)=x(nodo(:,k))';
    yel(k,:)=y(nodo(:,k))';
end

xyel=zeros(8,2,nel9);
xyel(:,1,:)=xel;
xyel(:,2,:)=yel;

% -------------------------------------------------------------------------
% Derivatives of Q8 interpolation functions in natural coordinates
dNst=zeros(2,8,nel9);

dNst(1,1,:)=(1+tt)/4 -(1-tt.^2)/4 + ss.*(1+tt)/2;
dNst(1,2,:)=-(1+tt)/4 +(1-tt.^2)/4 + ss.*(1+tt)/2;
dNst(1,3,:)=-(1-tt)/4 +(1-tt.^2)/4 + ss.*(1-tt)/2;
dNst(1,4,:)=(1-tt)/4 -(1-tt.^2)/4 + ss.*(1-tt)/2;
dNst(1,5,:)=-ss.*(1+tt);
dNst(1,6,:)=-(1-tt.^2)/2;
dNst(1,7,:)=-ss.*(1-tt);
dNst(1,8,:)=(1-tt.^2)/2;

dNst(2,1,:)= ss.^2/4 + ss/4 + tt.*(ss+1)/2;
dNst(2,2,:)= ss.^2/4 - ss/4 - tt.*(ss-1)/2;
dNst(2,3,:)=-ss.^2/4 + ss/4 - tt.*(ss-1)/2;
dNst(2,4,:)=-ss.^2/4 - ss/4 + tt.*(ss+1)/2;
dNst(2,5,:)=(1-ss.^2)/2;
dNst(2,6,:)= tt.*(ss-1);
dNst(2,7,:)=(ss.^2-1)/2;
dNst(2,8,:)=-tt.*(ss+1);

% -------------------------------------------------------------------------
% Jacobian matrices and Cartesian derivatives
J=multiprod(dNst,xyel);
detJ=J(1,1,:).*J(2,2,:)-J(1,2,:).*J(2,1,:);

J1=zeros(2,2,nel9);                 % J1=inv(J)
J1(1,1,:)= J(2,2,:)./detJ;
J1(2,2,:)= J(1,1,:)./detJ;
J1(1,2,:)=-J(1,2,:)./detJ;
J1(2,1,:)=-J(2,1,:)./detJ;

br=multiprod(J1,dNst);

% Strain-displacement matrices
B=zeros(3,16,nel9);
for k=1:8
    iu=2*k-1;
    iv=2*k;
    B(1,iu,:)=br(1,k,:);
    B(2,iv,:)=br(2,k,:);
    B(3,iu,:)=br(2,k,:);
    B(3,iv,:)=br(1,k,:);
end

% -------------------------------------------------------------------------
% Plane-stress constitutive matrix, including integration factor
E1=E/(1-nu*nu);
G=E/2/(1+nu);

fac=abs(detJ(:)).*ww*th;

E1g=E1*fac;
Gg =G *fac;

DHooke=zeros(3,3,nel9);
DHooke(1,1,:)=E1g;
DHooke(1,2,:)=nu*E1g;
DHooke(2,1,:)=nu*E1g;
DHooke(2,2,:)=E1g;
DHooke(3,3,:)=Gg;

DB=multiprod(DHooke,B);
kelt=reshape(multiprod(permute(B,[2 1 3]),DB),ngel^2,nel9);

% -------------------------------------------------------------------------
% Vectorized assembling
ipos0=zeros(ngel,nel9);
for k=1:8
    ipos0(2*k-1,:)=ngn*nodo(:,k)'-1;
    ipos0(2*k  ,:)=ngn*nodo(:,k)';
end

ipos1=repmat(ipos0,ngel,1);
ipos2=permute(reshape(ipos1,ngel,ngel,nel9),[2 1 3]);

K=sparse(ipos1,ipos2(:),kelt(:),neq,neq);

% -------------------------------------------------------------------------
% Constraints
loc=ngn*(cond(:,1)-1)+cond(:,2);
K(loc,:)=0;
K(:,loc)=0;
F(loc)=0;
K(loc,loc)=eye(length(loc));

% Concentrated / equivalent nodal forces
loc=ngn*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)+forze(:,3);

toc
tic
S=K\F;                              % solving the linear system
toc

% Restore the unweighted constitutive matrix for post-processing
DHooke=[E1    nu*E1   0
        nu*E1 E1      0
        0     0       G];

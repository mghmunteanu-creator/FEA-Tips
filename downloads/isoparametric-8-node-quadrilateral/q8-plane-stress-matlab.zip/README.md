# Section 9.6 — Q8 linear plane-stress analysis

Extract all files into one folder, make it the MATLAB current folder, and run `main.m`.

Tested in MATLAB R2026a Update 4 (26.1.0.3312084).

- `main.m`: runs the complete example.
- `gen.m`: generates the Q8 cantilever mesh, supports and distributed end load.
- `plane2d8.m`: assembles the linear plane-stress system using 3×3 Gauss quadrature and solves for the nodal displacements.
- `plot_disp.m`: displays horizontal or vertical displacement; Enter selects vertical displacement (2) and scale 1.
- `plot_stress.m`: displays normal, shear or von Mises stress; Enter selects sigma_x (1) and scale 0. Element-node stresses are averaged at shared nodes.

Units: mm, N and MPa. The example has 96 elements, 333 nodes and 666 equations. The resultant vertical load is −1000 N. Half nodal loads are applied at the two ends of the loaded boundary.

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

The positive integration measure is evaluated with `abs(det(J))`; the strain derivatives use the signed Jacobian inverse. The main program opens the mesh, displacement and stress figures. Press Enter at a prompt to accept its default value.

clear
gen
plane2d8
plot_disp
plot_stress

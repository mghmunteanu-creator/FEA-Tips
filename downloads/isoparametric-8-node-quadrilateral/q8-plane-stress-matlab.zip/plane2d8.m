%*** plane2d8 ***
nnd=length(x(:,1));	                % number of nodes
nel=length(elem(:,1));		        % number of finite elements
ngn=2;                              % number of DOF/node
ngel=16;                            % dimension of element stiffness matrix
neq=nnd*ngn;                        % total number of equations (or unknowns)
K=sparse(neq,neq);                  % stiffness matrix initialization
F=zeros(neq,1);                     % load vector initialization
% Gauss points, 3rd order
xgss=sqrt(0.6);
xgauss=[  -xgss      0     xgss];	
wgauss=[   5/9      8/9    5/9 ];	

xgs=[xgauss; xgauss; xgauss]; xgt=xgs';
xgs=xgs(:); xgt=xgt(:);
wgs=[wgauss; wgauss; wgauss]; wgt=wgs';
wgs=wgs(:); wgt=wgt(:);
E1=E/(1-nu*nu);
G=E/2/(1+nu);
DHooke=[   E1  nu*E1     0
	    nu*E1     E1     0
		    0      0     G ];
for ie=1:nel;
	nodi=elem(ie,:);
    %----------------------------------------------------------------------
	xel=x(nodi);         % nodal
	yel=y(nodi);         % coordinates 
	kel=zeros(ngel);
	for j=1:9
        s=xgs(j);
        t=xgt(j);
        dps0=[(1+t)/4  -(1+t)/4  -(1-t)/4  (1-t)/4     0     0     0     0];    
        dpt0=[(1+s)/4   (1-s)/4  -(1-s)/4 -(1+s)/4     0     0     0     0]; 	

        dps1=[   0    0    0    0    -s*(1+t)   -(1-t^2)/2  -s*(1-t)     (1-t^2)/2 ]; 	
        dpt1=[   0    0    0    0    (1-s^2)/2  -t*(1-s)    -(1-s^2)/2  -t*(1+s)   ]; 	

        dps2=[ (1-t^2)/2  -s*(1+t)    -(1-t^2)/2  -s*(1-t)      0      0     0     0]/2; 	
        dpt2=[-t*(1+s)     (1-s^2)/2  -t*(1-s)    -(1-s^2)/2    0      0     0     0]/2; 

        dps3=[-s*(1+t)    -(1-t^2)/2  -s*(1-t)     (1-t^2)/2    0      0     0     0]/2; 	
        dpt3=[ (1-s^2)/2  -t*(1-s)    -(1-s^2)/2  -t*(1+s)      0      0     0     0]/2; 	

        dps=dps0+dps1-dps2-dps3;
        dpt=dpt0+dpt1-dpt2-dpt3;

        H=[dps
            dpt];
        J=H*[ xel  yel];	% Jacobian
        detJ=abs(det(J));
        J1=inv(J);
        br=J1*H;

        % strain displacement matrix:
        B=[br(1,1) 0       br(1,2) 0       br(1,3) 0       br(1,4) 0       br(1,5) 0       br(1,6) 0       br(1,7) 0       br(1,8) 0
           0       br(2,1) 0       br(2,2) 0       br(2,3) 0       br(2,4) 0       br(2,5) 0       br(2,6) 0       br(2,7) 0       br(2,8)
           br(2,1) br(1,1) br(2,2) br(1,2) br(2,3) br(1,3) br(2,4) br(1,4) br(2,5) br(1,5) br(2,6) br(1,6) br(2,7) br(1,7) br(2,8) br(1,8)];

	    % element stiffness matrix
        kel=kel+wgs(j)*wgt(j)*th*B'*DHooke*B*detJ;
    end	
    %----------------------------------------------------------------------
    ip=[ngn*nodi-1; ngn*nodi];
    ip=ip(:);
 	K(ip,ip)=K(ip,ip)+ kel;         % assembling process
end

% Constraints
loc=2*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 

% Concentrated force
loc=2*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)+forze(:,3); 

% solve the linear system
S=K\F;                                      

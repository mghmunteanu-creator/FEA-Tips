%*** plot_stress ***

iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - does not plot         
istress=input('Stress (1-sx, 2-sy, 3-txy, 4-VM) [Default: 1]: ');
if length(istress)==0; istress=1; end
scale=input('Displacement scale [Default: 0]: ');
if length(scale)==0; scale=0; end
u=S(1:ngn:neq);
v=S(2:ngn:neq);
xgs=[1 -1 -1  1  0 -1  0  1];
xgt=[1  1 -1 -1  1  0 -1  0];
B=zeros(3,16);   
sigmat=zeros(8*nel,4);
ig=0;
for ie=1:nel
	nodi=elem(ie,:);
    ip=[ngn*nodi-1; ngn*nodi];
    ip=ip(:);
	xel=x(nodi);         % nodal
	yel=y(nodi);         % coordinates 
	sel=S(ip);
	for j=1:8;
        s=xgs(j);
        t=xgt(j);
        dps0=[(1+t)/4  -(1+t)/4  -(1-t)/4  (1-t)/4     0     0     0     0];    % derivatele
        dpt0=[(1+s)/4   (1-s)/4  -(1-s)/4 -(1+s)/4     0     0     0     0]; 	% f-ctiilor h

        dps1=[   0    0    0    0    -s*(1+t)   -(1-t^2)/2  -s*(1-t)     (1-t^2)/2 ]; 	
        dpt1=[   0    0    0    0    (1-s^2)/2  -t*(1-s)    -(1-s^2)/2  -t*(1+s)   ]; 	

        dps2=[ (1-t^2)/2  -s*(1+t)    -(1-t^2)/2  -s*(1-t)      0      0     0     0]/2; 	
        dpt2=[-t*(1+s)     (1-s^2)/2  -t*(1-s)    -(1-s^2)/2    0      0     0     0]/2; 

        dps3=[-s*(1+t)    -(1-t^2)/2  -s*(1-t)     (1-t^2)/2    0      0     0     0]/2; 	
        dpt3=[ (1-s^2)/2  -t*(1-s)    -(1-s^2)/2  -t*(1+s)      0      0     0     0]/2; 	

        dps=dps0+dps1-dps2-dps3;
        dpt=dpt0+dpt1-dpt2-dpt3;

        H=[dps
            dpt];
        J=H*[ xel  yel];	% Jacobianul
        detJ=abs(det(J));
        J1=inv(J);
        br=J1*H;

        % matricea deformatii-deplasari nodale
        B=[br(1,1) 0       br(1,2) 0       br(1,3) 0       br(1,4) 0       br(1,5) 0       br(1,6) 0       br(1,7) 0       br(1,8) 0
           0       br(2,1) 0       br(2,2) 0       br(2,3) 0       br(2,4) 0       br(2,5) 0       br(2,6) 0       br(2,7) 0       br(2,8)
           br(2,1) br(1,1) br(2,2) br(1,2) br(2,3) br(1,3) br(2,4) br(1,4) br(2,5) br(1,5) br(2,6) br(1,6) br(2,7) br(1,7) br(2,8) br(1,8)];
        % stresses (sigma_x, sigma_y, tau_xy):
		sigma=DHooke*B*sel; 
        % von Mises stress:
	   	sgech=sigma(1)^2+sigma(2)^2-sigma(1)*sigma(2)+3*sigma(3)^2;
        % sigma_x, sigma_y, tau_xy, von Mises stress:
        sigma=[sigma' sqrt(sgech)]; 	
        ig=ig+1;
        sigmat(ig,:)=sigma;
	end;
end;
x1=x+scale*u;
y1=y+scale*v;
strs=zeros(nnd,2);
ig=0;
for ie=1:nel
    for j=1:8
        nod=elem(ie,j);
        strs(nod,2)=strs(nod,2)+1;
        ig=ig+1;
        strs(nod,1)=strs(nod,1)+sigmat(ig,istress);
    end
end
stress(:,1)=strs(:,1)./strs(:,2);
smx=max(stress);
smn=min(stress);
figure(3)
clf
hold on
axis('equal')
colormap(turbo(16));
if iedge==0
    patch('Vertices',[x1 y1],'Faces',elem(:,[1 5 2 6 3 7 4 8]),'CData',stress,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[x1 y1],'Faces',elem(:,[1 5 2 6 3 7 4 8]),'CData',stress,'Facecolor','interp','edgecolor','w')
end
colorbar
sigma_max=smx
sigma_min=smn
if istress==1
    title('\sigma_x')
elseif istress==2
    title('\sigma_y')    
elseif istress==3
    title('\tau_x_y')   
elseif istress==4
    title('\sigma_V_M')
end
drawnow

% *** MoonRiv_bulk ***
i1=[2 2 2 1 1 1]';
i2=i1*i1';
Cxx=2*ex+1; Cyy=2*ey+1; Czz=2*ez+1; Cxy=exy;  Cyz=eyz;  Czx=ezx;
I3 =- Czz*Cxy^2 + 2*Cxy*Cyz*Czx - Cxx*Cyz^2 - Cyy*Czx^2 + Cxx*Cyy*Czz;
      
I3E =[      Cyy*Czz - Cyz^2
            Cxx*Czz - Czx^2
            Cxx*Cyy - Cxy^2
      2*Cyz*Czx - 2*Cxy*Czz
      2*Cxy*Czx - 2*Cxx*Cyz
      2*Cxy*Cyz - 2*Cyy*Czx].*i1;
  
I3EE =[     0,    Czz,    Cyy,      0, -2*Cyz,      0
          Czz,      0,    Cxx,      0,      0, -2*Czx
          Cyy,    Cxx,      0, -2*Cxy,      0,      0
            0,      0, -2*Cxy, -2*Czz,  2*Czx,  2*Cyz
       -2*Cyz,      0,      0,  2*Czx, -2*Cxx,  2*Cxy
            0, -2*Czx,      0,  2*Cyz,  2*Cxy, -2*Cyy].*i2;
 
J3  =sqrt(I3);
J3E =1/2*I3^(-1/2)*I3E;
%==========================================================================
% 2nd Piola-Kirchhoff stresses
SS=KK*(J3-1)*J3E;
sx =SS(1);
sy =SS(2);
sz =SS(3);
sxy=SS(4);
syz=SS(5);
szx=SS(6);
%==========================================================================
% D matrix
J3EE=1/2*I3^(-1/2)*I3EE-1/4*I3^(-3/2)*I3E*I3E';
D=KK*(J3-1)*J3EE+KK*J3E*J3E';

% *** MoonRiv_distortion ***
i1=[2 2 2 1 1 1]';
i2=i1*i1';
Cxx=2*ex+1; Cyy=2*ey+1; Czz=2*ez+1; Cxy=exy;  Cyz=eyz;  Czx=ezx;

I1 =  Cxx + Cyy + Czz;
I2 =- Cxy^2 - Cyz^2 - Czx^2 + Cxx*Cyy + Cxx*Czz + Cyy*Czz;
I3 =- Czz*Cxy^2 + 2*Cxy*Cyz*Czx - Cxx*Cyz^2 - Cyy*Czx^2 + Cxx*Cyy*Czz;
 
I1E =[1
      1
      1
      0
      0
      0].*i1;
 
I2E =[Cyy + Czz
      Cxx + Czz
      Cxx + Cyy
         -2*Cxy
         -2*Cyz
         -2*Czx].*i1;
     
I3E =[      Cyy*Czz - Cyz^2
            Cxx*Czz - Czx^2
            Cxx*Cyy - Cxy^2
      2*Cyz*Czx - 2*Cxy*Czz
      2*Cxy*Czx - 2*Cxx*Cyz
      2*Cxy*Cyz - 2*Cyy*Czx].*i1;
  
I1EE =zeros(6);
 
I2EE =[0, 1, 1,  0,  0,  0
       1, 0, 1,  0,  0,  0
       1, 1, 0,  0,  0,  0
       0, 0, 0, -2,  0,  0
       0, 0, 0,  0, -2,  0
       0, 0, 0,  0,  0, -2].*i2;

I3EE =[     0,    Czz,    Cyy,      0, -2*Cyz,      0
          Czz,      0,    Cxx,      0,      0, -2*Czx
          Cyy,    Cxx,      0, -2*Cxy,      0,      0
            0,      0, -2*Cxy, -2*Czz,  2*Czx,  2*Cyz
       -2*Cyz,      0,      0,  2*Czx, -2*Cxx,  2*Cxy
            0, -2*Czx,      0,  2*Cyz,  2*Cxy, -2*Cyy].*i2;
  
J1E=I1E*I3^(-1/3)-1/3*I1*I3^(-4/3)*I3E;

J2E=I2E*I3^(-2/3)-2/3*I2*I3^(-5/3)*I3E;
%==========================================================================
% 2nd Piola-Kirchhoff stresses
SS=A10*J1E+A01*J2E;
sx =SS(1);
sy =SS(2);
sz =SS(3);
sxy=SS(4);
syz=SS(5);
szx=SS(6);
%==========================================================================
% D matrix

J1EE=I1EE*I3^(-1/3)-1/3*I3^(-4/3)*(I1E*I3E'+I3E*I1E')+ 4/9*I1*I3^(-7/3)*I3E*I3E'-1/3*I1*I3^(-4/3)*I3EE;
J2EE=I2EE*I3^(-2/3)-2/3*I3^(-5/3)*(I2E*I3E'+I3E*I2E')+10/9*I2*I3^(-8/3)*I3E*I3E'-2/3*I2*I3^(-5/3)*I3EE;

D=A10*J1EE+A01*J2EE;


% *** convert Hencky strain ***
ig=0;ipos=[];
for ie=1:nel;
    nodi=elem(ie,1:8);
    % conectivity matrix:
    ipos(1:3:24)=3*nodi-2;
    ipos(2:3:24)=3*nodi-1;
    ipos(3:3:24)=3*nodi;
    sel=S(ipos);
    %----------------------------------------------------------------------
    xel=x(nodi);    % nodal
    yel=y(nodi);    % coordinates
    zel=z(nodi);    % 
    
	for j=1:8;
        ig=ig+1;
        s=str(1,j);
        t=str(2,j);
        r=str(3,j);
        H=1/8*[(1+t)*(1+r)  -(1+t)*(1+r)  -(1-t)*(1+r)   (1-t)*(1+r)   (1+t)*(1-r)   -(1+t)*(1-r)   -(1-t)*(1-r)   (1-t)*(1-r)     
               (1+s)*(1+r)   (1-s)*(1+r)  -(1-s)*(1+r)  -(1+s)*(1+r)   (1+s)*(1-r)    (1-s)*(1-r)   -(1-s)*(1-r)  -(1+s)*(1-r)     
               (1+s)*(1+t)   (1-s)*(1+t)   (1-s)*(1-t)   (1+s)*(1-t)  -(1+s)*(1+t)   -(1-s)*(1+t)   -(1-s)*(1-t)  -(1+s)*(1-t)];   
        J= H*[ xel    yel   zel];   % Jacobian
        J1=inv(J);
        b=J1*H;
        Bux(1:3:24)=b(1,:); Bux(24)=0;
        Buy(1:3:24)=b(2,:); Buy(24)=0;
        Buz(1:3:24)=b(3,:); Buz(24)=0;
        
        Bvx(2:3:24)=b(1,:); Bvx(24)=0;
        Bvy(2:3:24)=b(2,:); Bvy(24)=0;
        Bvz(2:3:24)=b(3,:); Bvz(24)=0;
        
        Bwx(3:3:24)=b(1,:);
        Bwy(3:3:24)=b(2,:);
        Bwz(3:3:24)=b(3,:);
        
        ux=Bux*sel; uy=Buy*sel; uz=Buz*sel;
        vx=Bvx*sel; vy=Bvy*sel; vz=Bvz*sel; 
        wx=Bwx*sel; wy=Bwy*sel; wz=Bwz*sel;
        
        FF =[1+ux uy uz; vx 1+vy vz; wx wy 1+wz];
        C=FF'*FF;
        U=sqrtm(C);
        ee=logm(U);      % Hencky strain tensor
        strnH(ig,:,istep+1)=[ee(1,1) ee(2,2) ee(3,3) 2*ee(1,2) 2*ee(2,3) 2*ee(3,1)];
    end	
end


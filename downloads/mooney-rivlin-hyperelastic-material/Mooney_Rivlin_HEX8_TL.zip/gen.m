% *** gen ***
E=4;                % Young modulus
nu=0.495;           % Poisson ratio

A10=0.48;           % Mooney-Rivlin 
A01=0.11;           % material constants

KK=E/3/(1-2*nu);    % Bulk modulus
th=1;               % thickness
F=-160;              % Load
load nodes
xyz=nodes(:,2:3);
n0=length(xyz(:,1));
xyz=[xyz zeros(n0,1)];
xyz=[xyz;[xyz(:,1:2) -ones(n0,1)*th]];  % second layer: z = -th, positive HEX8 Jacobians
x=xyz(:,1); y=xyz(:,2); z=xyz(:,3);
x0=x; y0=y; z0=z;
nnd=length(x);
load elements
elem0=elements(:,7:10);
elem=[elem0 (elem0+n0)];
nel=length(elem(:,1));

ndfx=[  27    62    63    64    65    66    67    68    69    70    71    72    73    74    75    76    77    78    79    80 81    82    83    84    85    86];
ic=0;
for i=1:length(ndfx)
    ic=ic+1;
    cond(ic,1)=ndfx(i);
    cond(ic,2)=2;
    ic=ic+1;
    cond(ic,1)=ndfx(i)+n0;
    cond(ic,2)=2;
end
ic=ic+1;
cond(ic,1)=74;
cond(ic,2)=1;
ic=ic+1;
cond(ic,1)=74+n0;
cond(ic,2)=1;

ic=ic+1;
cond(ic,1)=74;
cond(ic,2)=3;
ic=ic+1;
cond(ic,1)=74+n0;
cond(ic,2)=3;

nld= [ 1     2     3     4     5     6     7     8     9    10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25    26];
lnld=length(nld);
dF=F/25/2;
for i=1:lnld
   forze(i,1)=nld(i);
   forze(i,2)=2;
   forze(i,3)=dF;
   if i==1 | i==2
      forze(i,3)=dF/2;
   end
end
for i=1:lnld
   i1=i+lnld;
   forze(i1,1)=nld(i)+n0;
   forze(i1,2)=2;
   forze(i1,3)=dF;
   if i==1 | i==2
      forze(i1,3)=dF/2;
   end
end

neq=3*nnd;                          % number of nodal unknowns
u=z*0; v=u; w=v;
grafic3d0
title('Mesh')

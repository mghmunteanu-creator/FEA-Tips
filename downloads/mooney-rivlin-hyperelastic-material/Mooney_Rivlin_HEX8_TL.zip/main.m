% *** main ***
clear
format short e
nstep=50;                       % number of load steps
itermax=100;                    % maximum number of iterations
tol=1e-4;                       % tolerance
figure(5)
gen
S=zeros(neq,1);                 % nodal displacemens for the current load step
St=zeros(neq,nstep+1);            % nodal displacements for all load steps
strnt=zeros(8*nel,6,nstep+1);   % Green-Lagrange strain for all elements & for all load steps
sigmt=zeros(8*nel,7,nstep+1);   % 2nd Piola-Kirchh0ff stresses for all elements & for all load steps
for istep=1:nstep
    error=1;
    iter=0;
    while (error > tol) & (iter < itermax)
        iter=iter+1;
        stiff
        dS=K\F;
        S=S-dS;
        error=sqrt(dS'*dS/neq); 
    end
    u=S(1:3:neq);
    v=S(2:3:neq);
    w=S(3:3:neq);
    grafic3d0
    [istep iter error]
    St(:,istep+1)=S;
end

% von Mises-type equivalent of SECOND Piola-Kirchhoff stress (not Cauchy).
% Components: [S11 S22 S33 S12 S23 S13].
sigmt(:,7,:)=sqrt(0.5*((sigmt(:,1,:)-sigmt(:,2,:)).^2 + ...
                       (sigmt(:,2,:)-sigmt(:,3,:)).^2 + ...
                       (sigmt(:,3,:)-sigmt(:,1,:)).^2) + ...
                 3*(sigmt(:,4,:).^2+sigmt(:,5,:).^2+sigmt(:,6,:).^2));

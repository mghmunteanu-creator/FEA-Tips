% *** plot_strain_Hencky ***
iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - does not plot
istrain=input('Hencky strain (1-ex, 2-ey, 3-ez, 4-gxy, 5-gyz, 6-gzx, Default=2): ');
if length(istrain)==0, istrain=2; end
scale=input('Displacement scale (Default=0): ');
if length(scale)==0, scale=0; end
istep=input('Load case (Default=nstep): ');
if length(istep)==0, istep=nstep; end
S=St(:,istep+1);
u=S(1:3:neq);
v=S(2:3:neq);
w=S(3:3:neq);
x1=x0+scale*u;
y1=y0+scale*v;
z1=z0+scale*w;
convert_strain      % compute Hencky strains

strain0=zeros(nnd,2);
is=0;
for i=1:nel
    for j=1:8
        nod=elem(i,j);
        strain0(nod,2)=strain0(nod,2)+1;
        is=is+1;
        strain0(nod,1)=strain0(nod,1)+strnH(is,istrain,istep+1);
    end
end
strain(:,1)=strain0(:,1)./(strain0(:,2)+1e-55);
smx=max(strain);
smn=min(strain);
%==========================================================================
figure(15)
clf
hold on
axis('equal')
colormap(jet(16));
iposf=[1 2 3 4 5 6 7 8 1 2 6 5 2 3 7 6 3 4 8 7 4 1 5 8];
elemsf=elem(:,iposf)';
elemsf=reshape(elemsf(:),4,6*nel)';
if iedge==0
    patch('Vertices',[x1 y1 z1],'Faces',elemsf(:,1:4),'CData',strain,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[x1 y1 z1],'Faces',elemsf(:,1:4),'CData',strain,'Facecolor','interp','edgecolor','w')
end
colorbar
max_value=smx
min_value=smn
lighting phong
titlu='\epsilon_x\epsilon_y\epsilon_z\gamma_x_y\gamma_y_z\gamma_z_x';
sss=titlu(10*(istrain-1)+1:10*istrain);
sss=[sss,' - Hencky strain'];
title({[sss,',   Load step ',num2str(istep)]; ...
       ['min= ',num2str(smn),'  max=',num2str(smx)]})
xlabel('x')
ylabel('y')
zlabel('z')
view(2);

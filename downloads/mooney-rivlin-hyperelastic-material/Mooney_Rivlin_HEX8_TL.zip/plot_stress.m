% *** plot_stress ***
iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - does not plot
istress=input('2nd PK stress (1-Sxx, 2-Syy, 3-Szz, 4-Sxy, 5-Syz, 6-Szx, 7-VM, Default=2): ');
if length(istress)==0, istress=2; end
scale=input('Displacement scale (Default=0): ');
if length(scale)==0, scale=0; end
istep=input('Load case (Default=nstep): ');
if length(istep)==0, istep=nstep; end
S=St(:,istep+1);
u=S(1:3:neq);
v=S(2:3:neq);
w=S(3:3:neq);
x1=x0+scale*u;
y1=y0+scale*v;
z1=z0+scale*w;

stress0=zeros(nnd,2);
is=0;
for i=1:nel
    for j=1:8
        nod=elem(i,j);
        stress0(nod,2)=stress0(nod,2)+1;
        is=is+1;
        stress0(nod,1)=stress0(nod,1)+sigmt(is,istress,istep+1);
    end
end
stress(:,1)=stress0(:,1)./(stress0(:,2)+1e-55);
smx=max(stress);
smn=min(stress);
%==========================================================================
figure(15)
clf
hold on
axis('equal')
if exist('turbo','file')
    colormap(turbo(16));
else
    colormap(jet(16));  % fallback for MATLAB versions before R2020b
end
iposf=[1 2 3 4 5 6 7 8 1 2 6 5 2 3 7 6 3 4 8 7 4 1 5 8];
elemsf=elem(:,iposf)';
elemsf=reshape(elemsf(:),4,6*nel)';
if iedge==0
    patch('Vertices',[x1 y1 z1],'Faces',elemsf(:,1:4),'CData',stress,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[x1 y1 z1],'Faces',elemsf(:,1:4),'CData',stress,'Facecolor','interp','edgecolor','w')
end
colorbar
max_value=smx
min_value=smn
labels={'S_{xx}','S_{yy}','S_{zz}','S_{xy}','S_{yz}','S_{zx}','von Mises equivalent'};
sss=[labels{istress},' - Second Piola-Kirchhoff stress'];
title({[sss,',   Load step ',num2str(istep)]; ...
       ['min= ',num2str(smn),'  max=',num2str(smx)]})

xlabel('x')
ylabel('y')
zlabel('z')
view(2)
sides
drawnow

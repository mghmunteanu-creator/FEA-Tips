% *** stiff_distortion ***
ig=0;
for ie=1:nel;
    nodi=elem(ie,1:8);
    % conectivity matrix:
    ipos(1:3:24)=3*nodi-2;
    ipos(2:3:24)=3*nodi-1;
    ipos(3:3:24)=3*nodi;
    sel=S(ipos);
    %----------------------------------------------------------------------
    xel=x(nodi);    % nodal
    yel=y(nodi);    % coordinates
    zel=z(nodi);    % 
    
	for j=1:8;
        ig=ig+1;
        s=str(1,j);
        t=str(2,j);
        r=str(3,j);
        H=1/8*[(1+t)*(1+r)  -(1+t)*(1+r)  -(1-t)*(1+r)   (1-t)*(1+r)   (1+t)*(1-r)   -(1+t)*(1-r)   -(1-t)*(1-r)   (1-t)*(1-r)     
               (1+s)*(1+r)   (1-s)*(1+r)  -(1-s)*(1+r)  -(1+s)*(1+r)   (1+s)*(1-r)    (1-s)*(1-r)   -(1-s)*(1-r)  -(1+s)*(1-r)     
               (1+s)*(1+t)   (1-s)*(1+t)   (1-s)*(1-t)   (1+s)*(1-t)  -(1+s)*(1+t)   -(1-s)*(1+t)   -(1-s)*(1-t)  -(1+s)*(1-t)];   
        J= H*[ xel    yel   zel];   % Jacobian
        detJ=det(J);
        if detJ<=0
            error('Nonpositive HEX8 Jacobian in stiff_distortion, element %d.',ie);
        end
        J1=inv(J);
        b=J1*H;
        Bux(1:3:24)=b(1,:); Bux(24)=0;
        Buy(1:3:24)=b(2,:); Buy(24)=0;
        Buz(1:3:24)=b(3,:); Buz(24)=0;
        
        Bvx(2:3:24)=b(1,:); Bvx(24)=0;
        Bvy(2:3:24)=b(2,:); Bvy(24)=0;
        Bvz(2:3:24)=b(3,:); Bvz(24)=0;
        
        Bwx(3:3:24)=b(1,:);
        Bwy(3:3:24)=b(2,:);
        Bwz(3:3:24)=b(3,:);
        
        ux=Bux*sel; uy=Buy*sel; uz=Buz*sel;
        vx=Bvx*sel; vy=Bvy*sel; vz=Bvz*sel; 
        wx=Bwx*sel; wy=Bwy*sel; wz=Bwz*sel; 
        % Green-Lagrange strains:
        ex =ux+ux^2/2+vx^2/2+wx^2/2;
        ey =vy+uy^2/2+vy^2/2+wy^2/2;
        ez =wz+uz^2/2+vz^2/2+wz^2/2;
        exy=uy+vx +ux*uy+vx*vy+wx*wy;
        eyz=vz+wy +uy*uz+vy*vz+wy*wz;
        ezx=wx+uz +uz*ux+vz*vx+wz*wx;
        MoonRiv_distortion
        % stress updating:
        sigmt(ig,1:6,istep+1)=[sx sy sz sxy syz szx];   
        %G matrices:
        Gx =Bux'*Bux+Bvx'*Bvx+Bwx'*Bwx;
        Gy =Buy'*Buy+Bvy'*Bvy+Bwy'*Bwy;
        Gz =Buz'*Buz+Bvz'*Bvz+Bwz'*Bwz;
        Gxy=Bux'*Buy +Bvx'*Bvy +Bwx'*Bwy+ Buy'*Bux +Bvy'*Bvx +Bwy'*Bwx;
        Gyz=Buy'*Buz +Bvy'*Bvz +Bwy'*Bwz+ Buz'*Buy +Bvz'*Bvy +Bwz'*Bwy;
        Gzx=Buz'*Bux +Bvz'*Bvx +Bwz'*Bwx+ Bux'*Buz +Bvx'*Bvz +Bwx'*Bwz;
        % B matrix:
        B0=[Bux; Bvy; Bwz; Buy+Bvx;  Bvz+Bwy; Bwx+Buz];
        BL=[sel'*Gx; sel'*Gy; sel'*Gz; sel'*Gxy; sel'*Gyz; sel'*Gzx];
        B=B0+BL;
        % strain updating:
        strnt(ig,:,istep+1)=[ex ey ez exy eyz ezx];   
        % force and tangent stiffness matrices:
        fel=detJ*B'*[sx sy sz sxy syz szx]';
        kel=detJ*(B'*D*B+sx*Gx+sy*Gy+sz*Gz+sxy*Gxy+syz*Gyz+szx*Gzx);
        % assembling process:
        F(ipos)=F(ipos)+fel;
        K(ipos,ipos)=K(ipos,ipos)+kel;
    end	
end

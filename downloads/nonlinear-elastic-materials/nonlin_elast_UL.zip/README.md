# FEA Tips — Chapter 29: Nonlinear Elastic Materials

Run `main.m` in MATLAB, with all included files in the same folder.
The supplied example uses 480 HEX8 elements, 30 load steps, F1 = 40 N and
F2 = 160 N. Units: mm, N, MPa. Newton tolerance: 1e-4.

- `gen.m`: unchanged mesh/connectivity, constraints, loads and constitutive data.
- `stiff_cons.m`: direct Euler–Almansi strain, secant stress evaluation,
  consistent nonsymmetric material/spatial tangent, and assembly.
- `grafic3d0.m`: configuration plot during solution.
- `plot_disp.m`: selected displacement and load step; default scale 1.
- `plot_stress.m`: selected stress and load step; default scale 0.
- `sides.m`: exterior-edge plotting helper.

`gen.m` creates PCHIP samples at strain intervals of 0.001. Outside the initial
linear branch, `stiff_cons.m` interpolates those samples linearly and uses the
active segment slope in the material tangent. No tangent symmetrization is used.
The strain storage array has six columns; equivalent strain is evaluated by the
constitutive routine, not stored as a seventh column.

Gauss-point ordering follows the HEX8 local nodes. Stress plots retain the
node-associated Gauss-point averaging and use the selected step. Positive current
Jacobians are checked. A warning is issued if Newton reaches its iteration limit.

Tested in MATLAB R2026a. `turbo(16)` requires R2020b or later; the plotting routines
automatically fall back to `jet(16)` when unavailable. Older solver compatibility
has not been established. The ANSYS APDL macro is a separate download.

%*** gen ***
%==========================================================================
% Input data for a cantilever beam with a rectangular cross-section:
%   L - beam length
%   t - cross-section width
%   h - cross-section height
%   E - Young's modulus
%   nu - Poisson's ratio
%==========================================================================
% cl    constitutive law 
%
% x, y, z - tables containing the nodal coordinates
%
% elem  table contains:  
%       [node1  node2  node3  node4  node5  node6  node7  node8
%        :      :      :      :      :      :      :      :    ]
%
% cond  table contains nodal constraints 
%       (dir=1 - x direction, dir=2 - y direction, dir=3 - z direction)
%       [node1  dir1
%        node2  dir2
%        :      :   ]
% forze table contains nodal loads
%       [node1  dir1  force1
%        node2  dir2  force2
%        :      :     :     ]
%==========================================================================
% dimensions:
L=200;   % length (along x-axis)
t=20;    % cross-section width (along y-axis)
h= 5;    % cross-section height (along z-axis)
% material
E=5000;
nu=0.3;
% load
F1=40;
F2=4*F1; 
% constitutive law:
%  epsilon_eq    sigma_eq
cl=[        0            0
   0.1000e-01   5.0000e+01
   0.2000e-01   7.8750e+01
   0.3000e-01   8.7150e+01
   0.4000e-01   8.9048e+01
   0.5000e-01   8.9985e+01
   0.6000e-01   9.0578e+01
   0.7000e-01   9.0998e+01
   0.8000e-01   9.1350e+01
   0.9000e-01   9.1699e+01
   1.0000e-01   9.2042e+01];

% Sample the constitutive curve; stiff_cons interpolates these samples linearly.
eei = 0:1e-3:0.1;
sgi = interp1(cl(:,1),cl(:,2),eei,'pchip');

figure(1), clf, hold on, grid on
plot(cl(:,1),cl(:,2),'--','LineWidth',2)
plot(cl(:,1),cl(:,2),'o','LineWidth',2)
plot(eei,sgi,'LineWidth',2)
xlabel('\epsilon','fontsize',14)
ylabel('\sigma [MPa]','fontsize',14)
title('Constitutive law')

nL=30;              % number of elements along x direction
nt=4;               % number of elements along y direction
nh=4;               % number of elements along z direction
%==========================================================================
dL=L/nL;
dt=t/nt;
dh=h/nh;

nnd=(nt+1)*(nh+1)*(nL+1);
nel=nt*nh*nL;
x=zeros(nnd,1); y=zeros(nnd,1); z=zeros(nnd,1);
elem=ones(nel,8);
%========================================
% Generation of the table "x"
inod=0;
zz=0;
for i=1:nL+1
    yy=0;
    for j=1:nt+1   
        xx=0;
        for k=1:nh+1      
            inod=inod+1;
            x(inod)=zz;
            y(inod)=yy;
            z(inod)=xx;
            xx=xx+dh;
        end
        yy=yy+dt;
   end
   zz=zz+dL;
end
nnd=inod;
x0=x; y0=y; z0=z;
%========================================
% Generation of the table "elem"
iel=0;
inod=0;
for i=1:nL
	for j=1:nt
        for k=1:nh
            inod=inod+1;
            iel=iel+1;
            ln1=[inod inod+1 inod+nh+2 inod+nh+1];
            ln2=ln1+(nh+1)*(nt+1);
            elem(iel,:)=[ln1  ln2];
        end
        inod=inod+1;
    end
    inod=inod+nh+1;
end
nel=iel;
%===========================================
% Generation of the table "cond"
ic=0;
for i=1:(nt+1)*(nh+1)
    ic=ic+1;
    cond(ic,1)=i;
    cond(ic,2)=1;
    ic=ic+1;
    cond(ic,1)=i;
    cond(ic,2)=2;
    ic=ic+1;
    cond(ic,1)=i;
    cond(ic,2)=3;
end
%===========================================
% Generation of the table "forze" 
dF=F1/nh/nt;
ij=0;
il=0;
for j=1:nt+1 
    for i=1:nh+1
       	dF0=dF;
        if i==1 | i==nh+1
            dF0=dF0/2;
        end
        if j==1 | j==nt+1
            dF0=dF0/2;
        end
        il=il+1;
        ij=ij+1;
        forze(ij,:)=[nnd+1-il 3 -dF0];
        ij=ij+1;
        forze(ij,:)=[nnd+1-il 2 -dF0*F2/F1];
    end
end

nnd
nel
neq=3*nnd
grafic3d0
title('Mesh')
%===========================================
[nl ~]=size(forze);          
for i=1:nl
    nod=forze(i,1);
    dir=forze(i,2);
    ff =-forze(i,3);
    if dir==1
        plot3([x(nod) x(nod)-ff],[y(nod) y(nod)],   [z(nod) z(nod)],'m','linewidth',2)
    elseif dir==2
        plot3([x(nod) x(nod)],   [y(nod) y(nod)-ff],[z(nod) z(nod)],'m','linewidth',2)
    elseif dir==3
        plot3([x(nod) x(nod)],   [y(nod) y(nod)],   [z(nod) z(nod)-ff],'m','linewidth',2)
    end
end

dth=min([dL,dh,dt]);
for i=1:length(cond(:,1))
    nod=cond(i,1);
    dir=cond(i,2);
    if dir==1
        plot3([x(nod) x(nod)-dth],[y(nod) y(nod)],    [z(nod) z(nod)],'r','linewidth',2)
    elseif dir==2
        plot3([x(nod) x(nod)],    [y(nod) y(nod)-dth],[z(nod) z(nod)],'r','linewidth',2)
    elseif dir==3
        plot3([x(nod) x(nod)],    [y(nod) y(nod)],    [z(nod) z(nod)-dth],'r','linewidth',2)
    end
end


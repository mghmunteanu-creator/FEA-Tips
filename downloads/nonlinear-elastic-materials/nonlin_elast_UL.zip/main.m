%*** main ***
clear
format short e
nstep=30;            % number of load steps
tol=1e-4;           % tolerance
itermax=100;        % maximum number of iterations
gen
St=zeros(neq,nstep+1);
strnt=zeros(8*nel,6,nstep+1);
sigmt=zeros(8*nel,7,nstep+1);
for istep=1:nstep
    S=zeros(neq,1);
    errNR=1;
    iter=0;
    while (errNR > tol) & (iter < itermax)
        iter=iter+1;
        stiff_cons
        dS=K\F;
        S=S-dS;
        errNR=sqrt(dS'*dS/neq);
        x=x-dS(1:3:neq);
        y=y-dS(2:3:neq);
        z=z-dS(3:3:neq);
    end
    if iter >= itermax && errNR > tol
        warning('FEATips:NewtonNotConverged', ...
            'Load step %d did not converge after %d iterations (errNR=%g, tol=%g).', ...
            istep,iter,errNR,tol);
    end
    grafic3d0
    [istep iter errNR]
    St(:,istep+1)=St(:,istep)+S;
end
% Compute von Mises stress:
sgech=sqrt(sigmt(:,1,:).^2+sigmt(:,2,:).^2+sigmt(:,3,:).^2-...
sigmt(:,1,:).*sigmt(:,2,:)-sigmt(:,2,:).*sigmt(:,3,:)-sigmt(:,3,:).*sigmt(:,1,:)+...        
3*sigmt(:,4,:).^2+3*sigmt(:,5,:).^2+3*sigmt(:,6,:).^2);
sigmt(:,7,:)=sgech;

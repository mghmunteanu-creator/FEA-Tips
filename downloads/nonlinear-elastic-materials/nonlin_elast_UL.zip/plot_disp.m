%*** plot_disp ***

iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - hide element contours
            
idisp=input('Displacement (1-u, 2-v, 3-w, Default=3): ');
if length(idisp)==0, idisp=3; end
scale=input('Displacement scale (Default=1): ');
if length(scale)==0, scale=1; end
istep=input('Load case (Default=nstep): ');
if length(istep)==0, istep=nstep; end
S=St(:,istep+1);
u=S(1:3:neq);
v=S(2:3:neq);
w=S(3:3:neq);
x1=x0+scale*u;
y1=y0+scale*v;
z1=z0+scale*w;

figure(2)
clf
hold on
axis('equal')

if exist('turbo','file') || exist('turbo','builtin')
    colormap(turbo(16));
else
    colormap(jet(16)); % Visualization-only alternative for older MATLAB releases
end
displ=S(idisp:3:neq);

dmx=max(displ);
dmn=min(displ);
iposf=[1 2 3 4 5 6 7 8 1 2 6 5 2 3 7 6 3 4 8 7 4 1 5 8];
elemsf=elem(:,iposf)';
elemsf=reshape(elemsf(:),4,6*nel)';
if iedge==0
    patch('Vertices',[x1 y1 z1],'Faces',elemsf,'CData',displ,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[x1 y1 z1],'Faces',elemsf,'CData',displ,'Facecolor','interp','edgecolor','w')
end
colorbar
lighting phong
disp_max=dmx
disp_min=dmn

if idisp==1
    sss='u';
elseif idisp==2
    sss='v';    
elseif idisp==3
    sss='w';
end
title({[sss,',   Load step ',num2str(istep)]; ['min= ',num2str(dmn),'  max=',num2str(dmx)]})
xlabel('x')
ylabel('y')
zlabel('z')
view(3);
sides
drawnow

%*** plot_stress ***
iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - hide element contours
istress=input('Stress (1-sx, 2-sy, 3-sz, 4-txy, 5-tyz, 6-tzx, 7-VM, Default=1): ');
if length(istress)==0, istress=1; end
scale=input('Displacement scale (Default=0): ');
if length(scale)==0, scale=0; end
istep=input('Load case (Default=nstep): ');
if length(istep)==0, istep=nstep; end
S=St(:,istep+1);
u=S(1:3:neq);
v=S(2:3:neq);
w=S(3:3:neq);
x1=x0+scale*u;
y1=y0+scale*v;
z1=z0+scale*w;
%===================================
if istress<=7
    stress0=zeros(nnd,2);
    is=0;
    for i=1:nel
        for j=1:8
            nod=elem(i,j);
            stress0(nod,2)=stress0(nod,2)+1;
            is=is+1;
            % Gauss points and local nodes have corresponding positions.
            stress0(nod,1)=stress0(nod,1)+sigmt(is,istress,istep+1);
        end
    end
    stress(:,1)=stress0(:,1)./(stress0(:,2)+1e-55);
end
smx=max(stress);
smn=min(stress);

elem6=zeros(6*nel,4);
for ie=1:nel
    ii=6*ie-5;
    nodi=elem(ie,:);
    elem6(ii:ii+5,:)=[nodi([1 2 3 4])
        nodi([5 6 7 8])
        nodi([1 5 6 2])
        nodi([2 6 7 3])
        nodi([3 7 8 4])
        nodi([4 8 5 1])];
end
elem6_sort=sort(elem6,2);
[~,~,ic]=unique(elem6_sort,'rows');
nr=accumarray(ic,1);
elem6=elem6(nr(ic)==1,:);
%==========================================================================
figure(15+istress)
clf
hold on
axis('equal')
if exist('turbo','file') || exist('turbo','builtin')
    colormap(turbo(16));
else
    colormap(jet(16)); % Visualization-only alternative for older MATLAB releases
end
if iedge==0
    patch('Vertices',[x1 y1 z1],'Faces',elem6,'CData',stress,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[x1 y1 z1],'Faces',elem6,'CData',stress,'Facecolor','interp','edgecolor','w')
end
colorbar
max_value=smx
min_value=smn

lighting phong

titlu='\sigma_x\sigma_y\sigma_z\tau_x_y\tau_y_z\tau_z_xVM      ';
sss=titlu(8*(istress-1)+1:8*istress);
title({[sss,',   Load step ',num2str(istep)]; ['min= ',num2str(smn),'  max=',num2str(smx)]})

xlabel('x')
ylabel('y')
zlabel('z')
view(3)
sides
drawnow

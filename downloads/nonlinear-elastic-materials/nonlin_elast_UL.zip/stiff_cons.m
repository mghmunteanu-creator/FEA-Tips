%*** stiff_cons ***
% HEX8 UL - consistent spatial internal forces and tangent stiffness
E1 =E*(1-nu)/(1+nu)/(1-2*nu);
nu1=nu/(1-nu);
G=E/2/(1+nu);
DHooke=[     E1   nu1*E1       nu1*E1
         nu1*E1       E1       nu1*E1
         nu1*E1   nu1*E1       E1 ];
DHooke(4,4)=G; DHooke(5,5)=G; DHooke(6,6)=G;
F=zeros(neq,1);
K=zeros(neq);
% Gauss points in the same order as the local HEX8 nodes
str=[ 1  -1  -1   1   1  -1  -1   1
      1   1  -1  -1   1   1  -1  -1
      1   1   1   1  -1  -1  -1  -1]*sqrt(3)/3;
ig=0;
for ie=1:nel;
    nodi=elem(ie,1:8);
    % Connectivity matrix
    ip(1:3:24)=3*nodi-2;
    ip(2:3:24)=3*nodi-1;
    ip(3:3:24)=3*nodi;

    % Initial nodal coordinates
    xel0=x0(nodi);
    yel0=y0(nodi);
    zel0=z0(nodi);
    % Current trial nodal coordinates
    xelt=x(nodi);
    yelt=y(nodi);
    zelt=z(nodi);

    fel=zeros(24,1);
    kel=zeros(24);
    for j=1:8;
        ig=ig+1;
        s=str(1,j);
        t=str(2,j);
        r=str(3,j);
        H=1/8*[(1+t)*(1+r)  -(1+t)*(1+r)  -(1-t)*(1+r)   (1-t)*(1+r)   (1+t)*(1-r)   -(1+t)*(1-r)   -(1-t)*(1-r)   (1-t)*(1-r)
               (1+s)*(1+r)   (1-s)*(1+r)  -(1-s)*(1+r)  -(1+s)*(1+r)   (1+s)*(1-r)    (1-s)*(1-r)   -(1-s)*(1-r)  -(1+s)*(1-r)
               (1+s)*(1+t)   (1-s)*(1+t)   (1-s)*(1-t)   (1+s)*(1-t)  -(1+s)*(1+t)   -(1-s)*(1+t)   -(1-s)*(1-t)  -(1+s)*(1-t)];

        % Spatial derivatives in the current trial configuration
        Jt=H*[xelt yelt zelt];
        detJ=det(Jt);
        if detJ <= 0
            error('FEATips:NonpositiveJacobian', ...
                'Nonpositive current Jacobian in element %d at Gauss point %d.',ie,j);
        end
        J1=inv(Jt);
        b=J1*H;
        % B matrix
        Bux(1:3:24)=b(1,:);Bux(24)=0;
        Buy(1:3:24)=b(2,:);Buy(24)=0;
        Buz(1:3:24)=b(3,:);Buz(24)=0;
        Bvx(2:3:24)=b(1,:);Bvx(24)=0;
        Bvy(2:3:24)=b(2,:);Bvy(24)=0;
        Bvz(2:3:24)=b(3,:);Bvz(24)=0;
        Bwx(3:3:24)=b(1,:);
        Bwy(3:3:24)=b(2,:);
        Bwz(3:3:24)=b(3,:);
        B=[Bux; Bvy; Bwz; Buy+Bvx; Bvz+Bwy; Bwx+Buz];

        % Total Euler-Almansi strains
        J0=H*[xel0 yel0 zel0];
        Ftot=(J0\Jt)';
        Q=inv(Ftot*Ftot');
        e=(eye(3)-Q)/2;
        ex=e(1,1);   ey=e(2,2);   ez=e(3,3);
        exy=2*e(1,2); eyz=2*e(2,3); ezx=2*e(3,1);
        strnt(ig,:,istep+1)=[ex ey ez exy eyz ezx];
%--------------------------------------------------------------------------
        % Equivalent strain (engineering shear components)

        ev = [ex ey ez exy eyz ezx];

        e0 = sqrt(ex^2 + ey^2 + ez^2 ...
            - ex*ey - ey*ez - ez*ex ...
            + 3/4*(exy^2 + eyz^2 + ezx^2));

        eeq = e0/(1+nu);
    
        % Linear elastic stress corresponding to ev
        sig0 = DHooke*ev';

        if eeq <= cl(2,1)
        % Initial linear branch
            alpha = 1;
            Dtan = DHooke;
        else
            % Piecewise-linear interpolation between the PCHIP samples
            % prepared in gen.m; slope is its exact segment derivative.
            if eeq > eei(end)
                error('Equivalent strain exceeds material table');
            end
            k = find(eei <= eeq,1,'last');
            k = min(k,length(eei)-1);

            % Slope of the active interpolation segment
            slope = (sgi(k+1)-sgi(k))/(eei(k+1)-eei(k));

            sge = sgi(k) + slope*(eeq-eei(k));

            % Secant factor and its derivative
            alpha = sge/(E*eeq);
            dalpha = (slope*eeq-sge)/(E*eeq^2);

            % Gradient of equivalent strain
            deq = [2*ex-ey-ez, ...
                   2*ey-ex-ez, ...
                   2*ez-ex-ey, ...
                   1.5*exy, 1.5*eyz, 1.5*ezx] ...
                   /(2*(1+nu)*e0);

            % Consistent constitutive tangent
            Dtan = alpha*DHooke + sig0*(dalpha*deq);
        end

        % Actual stresses
        sig = alpha*sig0;
        sigmt(ig,1:6,istep+1) = sig';
%--------------------------------------------------------------------------        
        sigma=[sig(1) sig(4) sig(6)
               sig(4) sig(2) sig(5)
               sig(6) sig(5) sig(3)];

        % Internal forces in the current trial configuration
        fel=fel+B'*sig*detJ;

        % Consistent material tangent: BQ differs from B by the factor Q
        BQ=zeros(6,24);
        for i=1:8;
            ii=3*i-2:3*i;
            BQ(:,ii)=B(:,ii)*Q;
        end
        km=B'*Dtan*BQ;

        % Consistent geometric tangent: changes of volume and of B
        kg=zeros(24);
        for i=1:8;
            ii=3*i-2:3*i;
            bi=b(:,i);
            sbi=sigma*bi;
            for j=1:8;
                jj=3*j-2:3*j;
                bj=b(:,j);
                kg(ii,jj)=sbi*bj'-(sigma*bj)*bi';
            end
        end
        kel=kel+(km+kg)*detJ;
    end
    % Assembly
    F(ip)=F(ip)+fel;
    K(ip,ip)=K(ip,ip)+kel;
end
% Constraints
loc=3*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;
K(loc,loc)=eye(length(loc));
% Concentrated force
loc=3*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;

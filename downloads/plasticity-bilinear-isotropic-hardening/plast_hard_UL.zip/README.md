# FEA Tips — Section 30.3

HEX8 finite elements with a direct and consistent Updated Lagrangian formulation and bilinear isotropic hardening.

Run `main.m` from this folder. Choose `example=1` for uniform tension (13,000 N) or `example=2` for the perforated plate (5,000 N). The supplied default is Example 2 with 100 load steps.

- `gen_tens.m`, `gen_lastra.m`: geometry, mesh, material data, supports and nodal loads. The plate requires the included `nodes` and `elements` files.
- `stiff_cons.m`, `vonMises.m`: equilibrium assembly, material correction, consistent tangent and equivalent stress.
- `grafic3d0.m`, `sides.m`: mesh and edge display.
- `plot_disp.m`, `plot_stress.m`, `plot_plast.m`: selected-load-step postprocessing.
- `make_movie_plast.m`: run after the analysis to create a white/red plastic-zone movie on the deformed geometry (`movie_scale=1`), using nodal averaging.

Executed locally with MATLAB R2026a Update 4. No additional toolbox is required by the supplied code. Older MATLAB releases have not been tested.

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results. The plotting routines already include this fallback.

The small-strain constitutive assumptions limit physical interpretation of the extreme-strain plate example; it is a demanding numerical illustration.

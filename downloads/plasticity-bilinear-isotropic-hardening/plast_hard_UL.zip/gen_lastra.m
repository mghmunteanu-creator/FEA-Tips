% *** gen_lastra ***
% Perforated plate, extruded Q4 mesh; requires 'nodes' and 'elements'.
E=1000;
Et=100;
nu=0.3;
sgy=40;
th=2;
F=5000;
load nodes
xy=nodes(:,2:3);
n0=size(xy,1);
xyz=[xy zeros(n0,1); xy th*ones(n0,1)];
x=xyz(:,1); y=xyz(:,2); z=xyz(:,3);
x0=x; y0=y; z0=z;
nnd=numel(x);
load elements
elem0=elements(:,7:10);
% Through-thickness node order gives positive HEX8 Jacobians.
elem=[elem0+n0 elem0];
nel=size(elem,1);
neq=3*nnd;

% Boundary conditions.
ndfx=[27 62:86];
cond=zeros(0,2);
for i=1:numel(ndfx)
    cond(end+1,:)=[ndfx(i) 2];
    cond(end+1,:)=[ndfx(i)+n0 2];
end
for i=1:n0
    cond(end+1,:)=[i 3];
end
cond(end+1,:)=[74 1];
cond(end+1,:)=[74+n0 1];
cond(end+1,:)=[74+n0 3];

% Fixed equivalent nodal loads.
nld=1:26;
lnld=numel(nld);
dF=-F/25/2;
forze=zeros(2*lnld,3);
for i=1:lnld
    f0=dF;
    if i==1 || i==2, f0=dF/2; end
    forze(i,:)=[nld(i),2,f0];
    forze(i+lnld,:)=[nld(i)+n0,2,f0];
end

grafic3d0
title('Mesh')
for i=1:size(forze,1)
    nod=forze(i,1);
    dir=forze(i,2);
    ff=-forze(i,3)/6;
    if dir==1
        plot3([x(nod) x(nod)-ff],[y(nod) y(nod)],[z(nod) z(nod)],'m','linewidth',2)
    elseif dir==2
        plot3([x(nod) x(nod)],[y(nod) y(nod)-ff],[z(nod) z(nod)],'m','linewidth',2)
    else
        plot3([x(nod) x(nod)],[y(nod) y(nod)],[z(nod) z(nod)-ff],'m','linewidth',2)
    end
end
dth=1;
for i=1:size(cond,1)
    nod=cond(i,1);
    dir=cond(i,2);
    if dir==1
        plot3([x(nod) x(nod)-dth],[y(nod) y(nod)],[z(nod) z(nod)],'r','linewidth',2)
    elseif dir==2
        plot3([x(nod) x(nod)],[y(nod) y(nod)+dth],[z(nod) z(nod)],'r','linewidth',2)
    else
        plot3([x(nod) x(nod)],[y(nod) y(nod)],[z(nod) z(nod)-dth],'r','linewidth',2)
    end
end
fprintf('Plate: %d nodes, %d HEX8 elements.\n',nnd,nel);
drawnow

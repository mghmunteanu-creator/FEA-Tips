%*** gen_tens ***
% Dimensions:
L=200;  % Length (along x-axis)
t=50;   % Cross-section width (along y-axis)
h= 6;   % Cross-section height (along z-axis)

E=1000;
Et=100;
nu=0.3;
sgy=40

F=13000;

tol=1e-4;
itermax=50;

nL=2;
nt=2;
nh=1;

dL=L/nL;
dt=t/nt;
dh=h/nh;

n=(nt+1)*(nh+1)*(nL+1);
nel=nt*nh*nL;
x=zeros(n,1); y=zeros(n,1); z=zeros(n,1);
elem=ones(nel,8);
%========================================
% Generation of the table "x"
inod=0;
zz=0;
for i=1:nL+1
    yy=0;
    for j=1:nt+1   
        xx=0;
        for k=1:nh+1      
            inod=inod+1;
            x(inod)=zz;
            y(inod)=yy;
            z(inod)=xx;
            xx=xx+dh;
        end
        yy=yy+dt;
   end
   zz=zz+dL;
end
n=inod;
nnd=n; % Node count used by the postprocessing routines.
x0=x; y0=y; z0=z;
%========================================
% Generation of the table "elem"
iel=0;
inod=0;
for i=1:nL
	for j=1:nt
        for k=1:nh
            inod=inod+1;
            iel=iel+1;
            ln1=[inod inod+1 inod+nh+2 inod+nh+1];
            ln2=ln1+(nh+1)*(nt+1);
            elem(iel,:)=[ln1  ln2];
        end
        inod=inod+1;
    end
    inod=inod+nh+1;
end
nel=iel;
%===========================================
% Generation of the table "cond"
ic=0;
for i=1:(nt+1)*(nh+1)
    ic=ic+1;
    cond(ic,1)=i;
    cond(ic,2)=1;
end
ic=ic+1;
cond(ic,1)=nt+1;
cond(ic,2)=2;
ic=ic+1;
cond(ic,1)=nt+2;
cond(ic,2)=2;
for i=1:2:n
    ic=ic+1;
    cond(ic,:)=[i 3]; 
end
%===========================================
% Generation of the table "forze" 
dF=F/nh/nt;
ij=0;
il=0;
for j=1:nt+1 
    for i=1:nh+1
       	dF0=dF;
        if i==1 | i==nh+1
            dF0=dF0/2;
        end
        if j==1 | j==nt+1
            dF0=dF0/2;
        end
        il=il+1;
        ij=ij+1;
        forze(ij,1)=n+1-il;
        forze(ij,2)=1;
        forze(ij,3)=dF0;
    end
end

n
nel
neq=3*n
grafic3d0
title('Mesh')
%===========================================
nl=size(forze,1);              % Display the applied nodal forces.
for i=1:nl
    nod=forze(i,1);
    dir=forze(i,2);
    ff =-forze(i,3)/2/20;
    if dir==1
        quiver3(x(nod),y(nod),z(nod), -ff,0,0,'m','linewidth',2)
    elseif dir==2
        plot3([x(nod) x(nod)],   [y(nod) y(nod)-ff],[z(nod) z(nod)],'m','linewidth',2)
    elseif dir==3
        plot3([x(nod) x(nod)],   [y(nod) y(nod)],   [z(nod) z(nod)-ff],'m','linewidth',2)
    end
end

dth=min([dL,dh,dt])*2;
for i=1:length(cond(:,1))
    nod=cond(i,1);
    dir=cond(i,2);
    if dir==1
        plot3([x(nod) x(nod)-dth],[y(nod) y(nod)],    [z(nod) z(nod)],'r','linewidth',2)
    elseif dir==2
        plot3([x(nod) x(nod)],    [y(nod) y(nod)-dth],[z(nod) z(nod)],'r','linewidth',2)
    elseif dir==3
        plot3([x(nod) x(nod)],    [y(nod) y(nod)],    [z(nod) z(nod)-dth],'r','linewidth',2)
    end
end

drawnow

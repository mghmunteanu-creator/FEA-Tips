%*** main *** HEX8, consistent UL, bilinear isotropic hardening.
% Select example=1 for uniform tension or example=2 for the perforated plate.
clear
format short e
example=2;
if example==1
    gen_tens
elseif example==2
    gen_lastra
end
nstep=100;
itermax=50;
tol=1e-4;
HH=Et/(1-Et/E);                 % plastic modulus
St=zeros(neq,nstep+1);
strnt=zeros(8*nel,6,nstep+1);
sigmt=zeros(8*nel,7,nstep+1);
sgyt=ones(8*nel,nstep+1)*sgy;   % yield stress
ept=zeros(8*nel,nstep+1);       % equivalent plastic strain
iplst=zeros(8*nel,nstep+1);
niter=zeros(nstep,1);
for istep=1:nstep
    S=zeros(neq,1);
    errNR=Inf;
    iter=0;
    while errNR>tol && iter<itermax
        iplst(:,istep+1)=iplst(:,istep);
        iter=iter+1;
        stiff_cons
        dS=K\F;
        S=S-dS;
        errNR=sqrt(dS'*dS/neq);
        x=x-dS(1:3:neq);
        y=y-dS(2:3:neq);
        z=z-dS(3:3:neq);
    end
    if errNR>tol
        error('Global Newton-Raphson did not converge at step %d (%d iterations, residual %.4g).',istep,iter,errNR);
    end
    St(:,istep+1)=St(:,istep)+S;
    niter(istep)=iter;
    fprintf('Step %3d/%3d: %2d NR iterations, displacement correction %.4e\n',istep,nstep,iter,errNR);
        
    grafic3d0
    title(sprintf('Load step %d / %d',istep,nstep));
    drawnow
end


% *** make_movie_plast ***
% Plastic-zone animation for HEX8 UL.
% Same nodal averaging as plot_plast.m.
% Run AFTER main.m.
% Uses standard MATLAB graphics and VideoWriter.

% ---------------------------------------------------------
% Settings
% ---------------------------------------------------------
movie_fps   = 5;
movie_scale = 1;       % 0 = initial geometry
movie_edges = 1;       % 1 = show element contours

if exist('iprob','var')
    switch iprob
        case 0
            movie_file='plastic_zone_tension.mp4';
        case 1
            movie_file='plastic_zone_beam.mp4';
        case 2
            movie_file='plastic_zone_lastra.mp4';
        otherwise
            movie_file='plastic_zone.mp4';
    end
else
    movie_file='plastic_zone.mp4';
end

% ---------------------------------------------------------
% Check results
% ---------------------------------------------------------
if ~exist('St','var') || ~exist('iplst','var')
    error('Run main.m before make_movie_plast.m');
end

if size(St,2)~=nstep+1 || ...
        any(size(iplst)~=[8*nel,nstep+1])
    error('Incorrect dimensions of stored results.');
end

nnd_movie=numel(x0);

% ---------------------------------------------------------
% External faces
% ---------------------------------------------------------
local_faces=[1 2 3 4
             5 6 7 8
             1 2 6 5
             2 3 7 6
             3 4 8 7
             4 1 5 8];

all_faces=zeros(6*nel,4);

for ie=1:nel
    ii=(ie-1)*6+(1:6);
    nd=elem(ie,1:8);
    all_faces(ii,:)=nd(local_faces);
end

[~,~,ic]=unique(sort(all_faces,2),'rows');
nr=accumarray(ic,1);
faces=all_faces(nr(ic)==1,:);

% ---------------------------------------------------------
% Gauss-point to node correspondence
% Exactly the same averaging as in plot_plast.m
% ---------------------------------------------------------
node_ids=reshape(elem(:,1:8)',[],1);

flag_count=accumarray(node_ids,...
    ones(numel(node_ids),1),[nnd_movie,1]);

% ---------------------------------------------------------
% Fixed axis limits for all frames
% ---------------------------------------------------------
xmin=min(x0); xmax=max(x0);
ymin=min(y0); ymax=max(y0);
zmin=min(z0); zmax=max(z0);

if movie_scale~=0
    for k=1:nstep+1
        U=St(:,k);

        xx=x0+movie_scale*U(1:3:neq);
        yy=y0+movie_scale*U(2:3:neq);
        zz=z0+movie_scale*U(3:3:neq);

        xmin=min(xmin,min(xx));
        xmax=max(xmax,max(xx));
        ymin=min(ymin,min(yy));
        ymax=max(ymax,max(yy));
        zmin=min(zmin,min(zz));
        zmax=max(zmax,max(zz));
    end
end

margin=0.04*max([xmax-xmin,ymax-ymin,zmax-zmin]);

limits=[xmin-margin xmax+margin ...
        ymin-margin ymax+margin ...
        zmin-margin zmax+margin];

% ---------------------------------------------------------
% Initialize figure and video
% ---------------------------------------------------------
fig=figure(23);
set(fig,'Color','w',...
    'Position',[100 100 1000 650],...
    'Resize','off');

video=VideoWriter(movie_file,'MPEG-4');
video.FrameRate=movie_fps;
open(video);

% ---------------------------------------------------------
% Generate frames
% ---------------------------------------------------------
try
    for istep_movie=0:nstep

        U=St(:,istep_movie+1);

        xx=x0+movie_scale*U(1:3:neq);
        yy=y0+movie_scale*U(2:3:neq);
        zz=z0+movie_scale*U(3:3:neq);

        vertices=[xx yy zz];

        % Nodal averages of the eight Gauss-point flags.
        gp_plastic=double(iplst(:,istep_movie+1)>0);

        flag_sum=accumarray(node_ids,gp_plastic,...
            [nnd_movie,1]);

        plastic_value=flag_sum./max(flag_count,1);

        % Plot using interpolated nodal values.
        clf(fig);
        hold on;

        colormap([1 1 1; 1 0 0]);
        caxis([0 1]);

        if movie_edges==1
            edge_color=[0.01 0.01 0.01];
        else
            edge_color='none';
        end

        patch('Vertices',vertices,...
              'Faces',faces,...
              'CData',plastic_value,...
              'FaceColor','interp',...
              'EdgeColor',edge_color,...
              'LineWidth',0.35);

        axis equal;
        axis(limits);
        view(2);

        xlabel('x');
        ylabel('y');

        title(sprintf(...
            'Plastic zone - load step %d/%d (load %.0f%%)',...
            istep_movie,nstep,...
            100*istep_movie/nstep));

        drawnow;
        writeVideo(video,getframe(fig));
    end

    close(video);

catch ME
    close(video);
    rethrow(ME);
end

fprintf('\nMovie created: %s\n',movie_file);

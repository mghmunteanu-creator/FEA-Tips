% *** plot_plast *** Elastic/plastic indicator on the outer HEX8 faces.
% Select a load step and a deformation scale interactively.
iedge=1;

scale=input('Displacement scale (Default=0): ');
if isempty(scale), scale=0; end
istep=input('Load step (Default=nstep): ');
if isempty(istep), istep=nstep; end

if istep<0 || istep>nstep || istep~=floor(istep)
    error('Load step must be an integer from 0 to nstep.');
end
Su=St(:,istep+1);
x1=x0+scale*Su(1:3:neq);
y1=y0+scale*Su(2:3:neq);
z1=z0+scale*Su(3:3:neq);

% Arithmetic nodal averages of the eight Gauss-point plastic flags,
% ordered consistently with the local HEX8 nodes.
flag_sum=zeros(nnd,1);
flag_count=zeros(nnd,1);
ig=0;
for ie=1:nel
    for j=1:8
        ig=ig+1;
        nod=elem(ie,j);
        flag_sum(nod)=flag_sum(nod)+iplst(ig,istep+1);
        flag_count(nod)=flag_count(nod)+1;
    end
end
plastic_value=flag_sum./max(flag_count,1);

% Exterior quadrilateral faces only.
faces=zeros(6*nel,4);
for ie=1:nel
    k=6*ie-5;
    nd=elem(ie,:);
    faces(k:k+5,:)=[nd([1 2 3 4]); nd([5 6 7 8]); ...
        nd([1 5 6 2]); nd([2 6 7 3]); nd([3 7 8 4]); nd([4 8 5 1])];
end
[~,~,ic]=unique(sort(faces,2),'rows');
face_count=accumarray(ic,1);
faces=faces(face_count(ic)==1,:);

figure(23)
clf, hold on, axis equal
cmap=[1 1 1; 1 0 0];
colormap(cmap)
caxis([0 1])
if iedge==0
    patch('Vertices',[x1 y1 z1],'Faces',faces,'CData',plastic_value,...
          'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[x1 y1 z1],'Faces',faces,'CData',plastic_value,...
          'Facecolor','interp','edgecolor',[0.01 0.01 0.01])
end
title(sprintf('Plastic zone - load step %d / %d',istep,nstep))
xlabel('x'); ylabel('y'); zlabel('z')
view(2)
if exist('movie_axes','var') && numel(movie_axes)==6
    axis(movie_axes)
end
sides
drawnow

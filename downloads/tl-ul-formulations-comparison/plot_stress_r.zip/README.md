# Section 15.4 - Stress plotting

This package contains `plot_stress_r.m`, the stress postprocessor used in the TL/UL comparison. Run the corresponding analysis first, retain its results in the MATLAB workspace, then run `plot_stress_r` and answer its load-step and stress-component prompts. This is a plotting utility, not a standalone analysis.

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

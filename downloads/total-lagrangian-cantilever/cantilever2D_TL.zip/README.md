# Cantilever beam — Total Lagrangian formulation

This package implements the two-node isoparametric Timoshenko beam formulation presented in FEA Tips, Section 7.1. The initial undeformed configuration is the Total Lagrangian reference.

## Files

- `main.m` — load stepping and Newton–Raphson iterations
- `gen.m` — cantilever geometry, material, section, mesh, constraints, and loads
- `stiff.m` — element residual, tangent stiffness, assembly, constraints, and external loads
- `deriv.m` — generalized strains and their first and second derivatives
- `print_results.m` — nodal displacements and element efforts for a selected load step
- `diagrams.m` — axial-force, shear-force, and bending-moment diagrams

## Running the example

1. Place all files in the same folder.
2. Make that folder the MATLAB current folder.
3. Run `main`.
4. At the prompt, enter a load-step number from `0` to `10`, or press Enter for the final load step.

The supplied data use a 100 mm cantilever with a 5 mm × 1 mm rectangular cross-section, Young's modulus `E = 2e5 MPa`, vertical free-end force `V = 100 N`, and horizontal free-end force `H = -200 N`. Set `H0 = 0` in `gen.m` for the purely transverse-load example.

## MATLAB compatibility

Prepared for MATLAB R2024a. The code uses standard MATLAB syntax and is expected to be compatible with R2024a and newer MATLAB versions. No additional toolbox is required.

## Sign and result conventions

The element effort array is stored in the order `N, M, T`. Printed results are ordered `N, T, M`. The angular nodal degree of freedom is `psi`, the rotation of the cross-section.

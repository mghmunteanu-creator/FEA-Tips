%*** deriv ***
u1=s(1); v1=s(2); psi1=s(3); u2=s(4); v2=s(5); psi2=s(6);
% axial strain and its derivatives:
ep=sqrt((L+u2-u1)^2+(v2-v1)^2)/L-1;
ep1 =[ -(L - u1 + u2)
            (v1 - v2)
                    0
        (L - u1 + u2)
           -(v1 - v2)
                    0]/L^2; 
ep2 =[[ 1,  0,  0, -1,  0, 0]
      [ 0,  1,  0,  0, -1, 0]
      [ 0,  0,  0,  0,  0, 0]
      [-1,  0,  0,  1,  0, 0]
      [ 0, -1,  0,  0,  1, 0]
      [ 0,  0,  0,  0,  0, 0]]/L^2; 
% shear angle and its derivatives:  
be= atan2((v2 - v1),(L - u1 + u2)) - psi2/2 - psi1/2;
be1 =[   -v1+v2
       -L+u1-u2
         -L^2/2
          v1-v2
        L-u1+u2
         -L^2/2]/L^2;
be2 =[ 0 -1  0  0  1  0
       1  0  0 -1  0  0
       0  0  0  0  0  0
       0  1  0  0 -1  0 
      -1  0  0  1  0  0
       0  0  0  0  0  0]/L^2; 
% curvature and its derivatives:
ca =-(psi1 - psi2)/L;
ca1 =[0
      0
   -1/L
      0
      0
    1/L];
ca2=zeros(6);

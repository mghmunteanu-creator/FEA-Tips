%*** gen ***
%==========================================================================
% It generates input data for a straight beam with a rectangular cross-section:
%   Lb - length of the beam
%   width - width of the rectangular cross-section
%   t - height of the cross section
%   E - Young's modulus
%   V0 - vertical force applied on the cantilever free end
%   H0 - horizontal force applied on the cantilever free end
%==========================================================================
% x, y  contain x and y nodal coordinates respectively    
%         
% elem  table contains element nodes
%       [node1  node2 
%        :      :     ]
%
% cond  table contains nodal constraints
%       (dir=1 - x direction, dir=2 - y direction)
%       [node1  dir1  
%        node2  dir2
%        :      :   ]
%
% forze table contains nodal loads: node, direction, value
%       [node1  dir1  force1
%        node2  dir2  force2
%        :      :     :           :     ]
%==========================================================================
V0= 100;                % vertical force
H0=-200;                % horizontal force
Lb=100;             	% length of beam
width=5;                % width of cross-section
t=1;                    % thickness of cross-section
E=2e5;                  % Young's modulus
EI=E*width*t^3/12;
EA=E*width*t;
GA=EA/2.6/1.2;
nel=90;                 % number of finite elements
nnd=nel+1;              % number of nodes
neq=3*nnd;
x=[0:Lb/nel:Lb+0.01]';	% nodal coordinates
elem=[1:nel;2:nnd]';    % beam elements
y=x*0;
cond=[1  1              % boundary constraints
      1  2
      1  3];
nf=nnd; 
forze=[nf 1 H0
       nf 2 V0];        % load
for ie=1:nel            % initial length of the beam elements
    n1=elem(ie,1);
    n2=elem(ie,2);
    dx=x(n2)-x(n1);
    dy=y(n2)-y(n1);
    L=sqrt(dx*dx+dy*dy);
    Lt(ie)=L;
end

%*** main ***
clear
format short e
gen
nstep=10;                % number of load steps
tol=1e-5;                % tolerance
itermax=100;             % maximum number of iterations
S=zeros(neq,1);
St=zeros(neq,nstep+1);
stress=zeros(nel,3,nstep+1);
figure(5), clf, hold on, grid on, axis('equal')
plot(x/Lb,y/Lb,'k','linewidth',1.5)
for istep=1:nstep
    error=1;
    iter=0;
    while (error > tol) & (iter < itermax)
        iter=iter+1;
        stiff
        dS=K\F;
        S=S-dS;
        error=sqrt(dS'*dS/nnd);
    end
    plot((x+S(1:3:neq))/Lb,(y+S(2:3:neq))/Lb,'b','linewidth',1)
    [istep iter error]
    St(:,istep+1)=S;
    pause(0.01)
end
print_results
diagrams

# Section 12.1 — ANSYS comparison model

This package contains the ANSYS Mechanical APDL macro for Example 2 in Section 12.1 of FEA Tips.

The macro defines the same 400 mm × 20 mm cantilever domain, 5 mm thickness, plane-stress material model, clamped boundary, 100 N free-end load, and 120 × 16 rectangular subdivision pattern used for the MATLAB comparison.

The macro was inspected for consistency with the published example but was not executed during preparation of this package.

This macro was validated in the original version of the example. It has been transferred to the present edition without technical modification and was therefore not re-executed during the current revision.


# Section 12.1 — CST Finite Element (Total Lagrangian formulation)

This package contains the MATLAB programs used for the nonlinear plane-stress CST examples in Section 12.1 of FEA Tips.

## Files

- `main.m` — runs the load-step and Newton–Raphson solution.
- `gen.m` — defines the cantilever geometry, mesh, material, constraints, and loading for Example 2.
- `stiff.m` — computes Green–Lagrange strains, second Piola–Kirchhoff stresses, the internal-force vector, and the tangent stiffness matrix.
- `plot_disp.m` — plots a selected displacement component.
- `plot_stress.m` — plots a selected stress component or the Von Mises stress.

## How to run

1. Place all files in the same MATLAB folder.
2. Run `main`.
3. Run `plot_disp` or `plot_stress` and follow the prompts. Press Enter at the load-step prompt to select the final load step.

The distributed input data correspond to Example 2: a plane-stress cantilever of length 400 mm, height 20 mm, and thickness 5 mm, subjected to a 100 N force at its free end. The mesh has 3,840 CST elements and 2,057 nodes.

## MATLAB compatibility

Tested in MATLAB R2026a. The programs use standard MATLAB syntax and are expected to be compatible with newer MATLAB versions.

The `turbo` colormap is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

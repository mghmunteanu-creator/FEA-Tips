%*** gen ***
%==========================================================================
% It generates input data for a rectangular-cross-section cantilever beam:
%   L - beam length
%   H - cross-section height
%   t - cross-section width
%   E - Young's modulus
%   nu - Poisson's ratio
%   nL - number of elements along the beam length
%   nH - number of elements on beam height
%==========================================================================
% x, y - nodal coordinates
%
% elem  table contains element nodes
%       [node1  node2  node3 
%       [node1  node2  node3 
%        :      :      :    ]
%               
% cond  table contains nodal constraints
%       (dir=1 - x direction, dir=2 - y direction)
%       [node1  dir1
%        node2  dir2
%        :      :   ]
%
% forze table contains nodal loads
%       [node1  direction1  force1
%        node2  direction2  force2
%        :      :     :           :     ]
%==========================================================================
L=400;                      % Beam length 
H=20;                       % Beam width  
th=5;                       % Thickness
E=1000;                     % Young's modulus
nu=0.3;                     % Poisson's ratio
F=100;                      % Force applied on the free end of the beam

nL=120;                     % Number of finite elements along the beam
nH=16;                      % Number of elements on the beam width
%==========================================================================
% Generation of the table "x"
dH=H/nH;
dL=L/nL;

nnd=(nL+1)*(nH+1);          % number of nodes
nel=2*nL*nH;                % number of finite elements
elem=zeros(nel,3);
neq=2*nnd;                    % number of nodal unknowns

inod=0;
xx=0;
for i=1:nL+1
   yy=0;
   for j=1:nH+1
      inod=inod+1;
      x(inod,1)=xx;
      y(inod,1)=yy;
      yy=yy+dH;
   end
   xx=xx+dL;
end
%========================================
% Generation of the table "elem"
iel=0;
inod=0;
for i=1:nL
    for j=1:nH
        j1=rem(j,2);
        inod=inod+1;
        iel=iel+1;
        if j1==0
            elem(iel,:)=[inod   inod+nH+1 inod+nH+2];
            iel=iel+1;
            elem(iel,:)=[inod   inod+1    inod+nH+2];
        elseif j1==1
            elem(iel,:)=[inod   inod+1    inod+nH+1];
            iel=iel+1;
            elem(iel,:)=[inod+1 inod+nH+2 inod+nH+1];
        end 
   end
   inod=inod+1;
end
%========================================
% Generation of the table "cond"
ic=0;
for i=1:nH+1
    ic=ic+1;
    cond(ic,1)=i;
    cond(ic,2)=1;
    ic=ic+1;
    cond(ic,1)=i;
    cond(ic,2)=2;
end
%========================================
% Generation of the table "forze"
dF=F/nH;
for i=1:nH+1
   forze(i,1)=nnd+1-i;
   forze(i,2)=2;
   forze(i,3)=-dF;
   if i==1 | i==nH+1
      forze(i,3)=-dF/2;
   end
end
patch('Vertices',[x y],'Faces',elem,'Facecolor',[1 1 1],'linewidth',0.25,'edgecolor','b')
drawnow

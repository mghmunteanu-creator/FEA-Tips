%*** main ***
clear
format short e
nstep=5;                    % number of load steps
itermax=100;                % Max number of iterations
tol=1e-5;                   % Tolerance
figure(5)
clf, hold on, grid on, axis('equal')
gen
S=zeros(neq,1);
St=zeros(neq,nstep+1);
strnt=zeros(nel,3,nstep);
sigmt=zeros(nel,4,nstep);
for istep=1:nstep
    error=1;
    iter=0;
    while (error > tol) & (iter < itermax)
        iter=iter+1;
        stiff
        dS=K\F;
        S=S-dS;
        error=sqrt(dS'*dS/neq);
    end
    u=S(1:2:neq);
    v=S(2:2:neq);
    patch('Vertices',[x+u y+v],'Faces',elem,'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b')    
    [istep iter error]
    St(:,istep+1)=S;
    pause(0.01)
end
% Compute Von Mises stress:
sgech=sqrt(sigmt(:,1,istep).^2+sigmt(:,2,istep).^2-sigmt(:,1,istep).*sigmt(:,2,istep)+3*sigmt(:,3,istep).^2);
sigmt(:,4,istep)=sgech;

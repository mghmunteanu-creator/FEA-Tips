%*** plot_stress ***
iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - does not plot
istress=input('Stress (1-sx, 2-sy, 3-txy, 4-VM; default 1): ');
if length(istress)==0; istress=1; end
istep=input('Load step (default nstep): ');
if length(istep)==0; istep=nstep; end
scale=1;
u=St(1:2:neq,istep+1);
v=St(2:2:neq,istep+1);
disp(' ');
disp('Load step');
istep
%===================================
nodelem=zeros(nnd,7);
for i=1:nel
        for j=1:3
                nod=elem(i,j);
                nodelem(nod,1)=nodelem(nod,1)+1;
                iloc=nodelem(nod,1)+1;
                nodelem(nod,iloc)=i;
        end
end         
%===================================
x1=x+scale*u;
y1=y+scale*v;
figure(15)
clf
hold on
axis('equal')
colormap(turbo(16))
for i=1:nnd                     % Computing of stresses in each node
        nmax=nodelem(i,1);
        nrel=nodelem(i,2:nmax+1);
        stress(i)=sum(sigmt(nrel',istress,istep))/nmax;
end
smx=max(stress);
smn=min(stress);
if iedge==0
    patch('Vertices',[x1 y1],'Faces',elem(:,1:3),'CData',stress,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[x1 y1],'Faces',elem(:,1:3),'CData',stress,'Facecolor','interp','edgecolor','w')
end
colorbar
lighting phong
sigma_max=smx
sigma_min=smn
if istress==1
    title(['\sigma_x  -  ','Load step ',num2str(istep)])
elseif istress==2
    title(['\sigma_y  -  ','Load step ',num2str(istep)])   
elseif istress==3
    title(['\tau_x_y  -  ','Load step ',num2str(istep)])  
elseif istress==4
    title(['\sigma_v_o_n_ _M_i_s_e_s  -  ','Load step ',num2str(istep)])
end

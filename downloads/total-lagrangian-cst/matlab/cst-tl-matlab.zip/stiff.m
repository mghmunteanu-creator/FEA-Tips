%*** stiff ***
E1=E/(1-nu*nu);  
E2=nu*E1;
G=E/2/(1+nu);
DHooke=[E1 E2 0
        E2 E1 0
         0  0 G];
F=zeros(neq,1);
K=zeros(neq);
for ie=1:nel
	n1=elem(ie,1); n2=elem(ie,2); n3=elem(ie,3);
    ip=[2*n1-1  2*n1  2*n2-1 2*n2   2*n3-1  2*n3]; 
    
    uel=S(ip);
    y23=y(n2)-y(n3); y31=y(n3)-y(n1); y12=y(n1)-y(n2);
    x32=x(n3)-x(n2); x13=x(n1)-x(n3); x21=x(n2)-x(n1);
    Ael=(x21*y31-x13*y12)/2;                
    Bux=[ y23    0   y31    0   y12     0 ]/2/Ael;
    Buy=[ x32    0   x13    0   x21     0 ]/2/Ael;
    
    Bvx=[   0  y23     0  y31     0   y12 ]/2/Ael;    
    Bvy=[   0  x32     0  x13     0   x21 ]/2/Ael;
                    
    ux=Bux*uel;
    uy=Buy*uel;
    vx=Bvx*uel;
    vy=Bvy*uel;
    B0=[Bux; Bvy; Buy+Bvx];
    
    % Green-Lagrange strains:
    ex =ux+ux^2/2+vx^2/2;
    ey =vy+uy^2/2+vy^2/2;
    exy=uy+vx+ux*uy+vx*vy;
    
    Gx =Bux'*Bux+Bvx'*Bvx;
    Gy =Buy'*Buy+Bvy'*Bvy;
    Gxy=Bux'*Buy+Bvx'*Bvy+Buy'*Bux+Bvy'*Bvx;
    BL=[uel'*Gx; uel'*Gy; uel'*Gxy];
    
    B=B0+BL;
    Vel=abs(th*Ael);
        
    sigmt(ie,1:3,istep)=[ex ey exy]*DHooke;
    fel=Vel*(B'*sigmt(ie,1:3,istep)');
    kel=Vel*(B'*DHooke*B+sigmt(ie,1,istep)*Gx+sigmt(ie,2,istep)*Gy+sigmt(ie,3,istep)*Gxy);
    % assembling process:
    F(ip)=F(ip)+fel;
    K(ip,ip)=K(ip,ip)+kel;
    strnt(ie,:,istep)=[ex ey exy];
end
% Constraints
loc=2*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 
% Concentrated force
loc=2*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;               

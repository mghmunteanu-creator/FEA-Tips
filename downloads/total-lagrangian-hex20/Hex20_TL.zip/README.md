# Section 26.2 — Total Lagrangian HEX20

Run `main.m` in MATLAB with all files in the same folder.
The cantilever example uses 240 HEX20 elements and 27 Gauss points per element,
with small strains, large displacements and a linear elastic material.

- `main.m`: load steps and Newton–Raphson iterations.
- `gen.m`: mesh, material, constraints and loading.
- `stiff.m`: element internal forces, tangent stiffness and assembly.
- `shape20.m`: interpolation functions and natural-coordinate derivatives.
- `grafic3d0.m`, `sides.m`: geometry plotting support.
- `plot_disp.m`, `plot_stress.m`: displacement and stress visualization.

A MATLAB installation supporting the functions in these files is required.
`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases,
replace `turbo` with `jet`. This affects visualization only and does not change
the numerical results. This does not guarantee full solver compatibility with
older releases.

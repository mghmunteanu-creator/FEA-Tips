% *** main ***
clear
format short e
nstep=20;                      % number of load steps
tol=1e-4;
itermax=50;
gen
S =zeros(neq,1);              % nodal displacements for the current load step
St=zeros(neq,nstep+1);        % nodal displacements for all load steps  
strnt=zeros(27*nel,6,nstep+1); % strains in finite elements for all load steps
sigmt=zeros(27*nel,7,nstep+1); % stresses in finite elements for all load steps
for istep=1:nstep
    error=1;
    iter=0;
    while (error > tol) & (iter < itermax)
        iter=iter+1;
        stiff
        dS=K\F;
        S=S-dS;
        error=sqrt(dS'*dS/neq);
    end
    grafic3d0    
    drawnow
    [istep iter error]
    St(:,istep+1)=S;
    % Von Mises stresses:
    sgech=sqrt( sigmt(:,1,istep+1).^2+sigmt(:,2,istep+1).^2+sigmt(:,3,istep+1).^2-...
                sigmt(:,1,istep+1).*sigmt(:,2,istep+1)-sigmt(:,2,istep+1).*sigmt(:,3,istep+1)-sigmt(:,3,istep+1).*sigmt(:,1,istep+1)+...
                3*sigmt(:,4,istep+1).^2+3*sigmt(:,5,istep+1).^2+3*sigmt(:,6,istep+1).^2);
    sigmt(:,7,istep+1)=sgech;
end

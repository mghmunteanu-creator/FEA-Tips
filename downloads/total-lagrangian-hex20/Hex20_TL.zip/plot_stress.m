% *** plot_stress ***

iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - does not plot         
istress=input('Stress (1-sx, 2-sy, 3-sz, 4-txy, 5-tyz, 6-tzx, 7-VM, Default=1): ');
if length(istress)==0, istress=1; end
scale=input('Displacement scale, Default=0: ');
if length(scale)==0, scale=0; end
istep=input('Load case (Default=nstep): ');
if length(istep)==0, istep=nstep; end
S=St(:,istep+1);
u=S(1:3:neq);
v=S(2:3:neq);
w=S(3:3:neq);

% Hooke's law:
E1 =E*(1-nu)/(1+nu)/(1-2*nu);
nu1=nu/(1-nu);
G=E/2/(1+nu);
DHooke=[     E1   nu1*E1       nu1*E1
         nu1*E1       E1       nu1*E1
         nu1*E1   nu1*E1       E1 ];
DHooke(4,4)=G; DHooke(5,5)=G;; DHooke(6,6)=G;
ind= [  1   9   2  12   0  10   4  11   3  17   0  18   0   0   0  20   0  19   5  13   6  16   0  14   8  15   7];
B=zeros(6,60);
ig=0;
sigmat=zeros(20*nel,1);                                   
for ie=1:nel
    ii=20*(ie-1);
	for j=1:27
        ig=ig+1;
        jj=ind(j);
        if jj~=0
            sigmat(ii+jj)=sigmt(ig,istress,istep+1);
        end
    end
end

x1=x+scale*u;
y1=y+scale*v;
z1=z+scale*w;
strs=zeros(nnd,2);
ig=0;
for i=1:nel
    for j=1:20
        nod=elem(i,j);
        strs(nod,2)=strs(nod,2)+1;
        ig=ig+1;
        strs(nod,1)=strs(nod,1)+sigmat(ig);
    end
end
stress(:,1)=strs(:,1)./strs(:,2);
smx=max(stress);
smn=min(stress);

elem6=zeros(6*nel,8);
for ie=1:nel
    ii=6*ie-5;
    nodi=elem(ie,:);
    elem6(ii:ii+5,:)=[nodi([1 2 3 4  9 10 11 12])
                      nodi([5 6 7 8 13 14 15 16])
                      nodi([1 5 6 2 17 13 18  9])
                      nodi([2 6 7 3 18 14 19 10])
                      nodi([3 7 8 4 19 15 20 11])
                      nodi([4 8 5 1 20 16 17 12])];
end
elem6_sort=sort(elem6,2);
[~,~,ic]=unique(elem6_sort,'rows');
nr=accumarray(ic,1);
elem6=elem6(nr(ic)==1,:);
elem6=elem6(:,[1 5 2 6 3 7 4 8]);

figure(5+istress)
clf
hold on
axis('equal')
colormap(turbo(16));
if iedge==0
    patch('Vertices',[x1 y1 z1],'Faces',elem6,'CData',stress,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[x1 y1 z1],'Faces',elem6,'CData',stress,'Facecolor','interp','edgecolor','w')
end
colorbar
view(3)
max_value=smx
min_value=smn

lighting phong

titlu='\sigma_x\sigma_y\sigma_z\tau_x_y\tau_y_z\tau_z_xVM      u       v       w       ';
sss=titlu(8*(istress-1)+1:8*istress);
title({sss;['min= ',num2str(smn),'  max=',num2str(smx)]})

xlabel('x')
ylabel('y')
zlabel('z')
view(3)
sides

%*** sides ***
nsid=12*nel;
sid=zeros(12*nel,3);
is=0;
for ie=1:nel
    nodi=elem(ie,:);
    sid(is+1:is+12,:)= [nodi([1  9 2])
                        nodi([2 10 3])
                        nodi([3 11 4])
                        nodi([4 12 1])
                        nodi([5 13 6])
                        nodi([6 14 7])
                        nodi([7 15 8])
                        nodi([8 16 5])
                        nodi([1 17 5])
                        nodi([2 18 6])
                        nodi([3 19 7])
                        nodi([4 20 8])];
    is=is+12;
end
sid_sort=sort(sid,2);
[~,~,ic]=unique(sid_sort,'rows');
nr=accumarray(ic,1);
sid=sid(nr(ic)==1,:);
for i=1:length(sid)
    nd=sid(i,:);
    plot3(x1(nd),y1(nd), z1(nd),'k')
end

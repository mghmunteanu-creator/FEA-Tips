% *** stiff ***
E1 =E*(1-nu)/(1+nu)/(1-2*nu);
nu1=nu/(1-nu);
G=E/2/(1+nu);
DHooke=[     E1   nu1*E1       nu1*E1
	     nu1*E1       E1       nu1*E1
         nu1*E1   nu1*E1       E1 ];
DHooke(4,4)=G; DHooke(5,5)=G; DHooke(6,6)=G;
F=zeros(neq,1);
K=zeros(neq);
% Gauss points:
a = sqrt(3/5);
str=a*[-1  -1  -1  -1  -1  -1  -1  -1  -1   0   0   0   0   0   0   0   0   0   1   1   1   1   1   1   1   1   1
       -1  -1  -1   0   0   0   1   1   1  -1  -1  -1   0   0   0   1   1   1  -1  -1  -1   0   0   0   1   1   1
       -1   0   1  -1   0   1  -1   0   1  -1   0   1  -1   0   1  -1   0   1  -1   0   1  -1   0   1  -1   0   1];
 
wg = [1.7147e-01   2.7435e-01   1.7147e-01   2.7435e-01   4.3896e-01   2.7435e-01   1.7147e-01   2.7435e-01   1.7147e-01 ...
      2.7435e-01   4.3896e-01   2.7435e-01   4.3896e-01   7.0233e-01   4.3896e-01   2.7435e-01   4.3896e-01   2.7435e-01 ...
      1.7147e-01   2.7435e-01   1.7147e-01   2.7435e-01   4.3896e-01   2.7435e-01   1.7147e-01   2.7435e-01   1.7147e-01];
ig=0;
for ie=1:nel;
     nodi=elem(ie,:);
    % conectivity matrix:
    ipos(1:3:60)=3*nodi-2;
    ipos(2:3:60)=3*nodi-1;
    ipos(3:3:60)=3*nodi;
    sel=S(ipos);    
    %----------------------------------------------------------------------
    xel=x(nodi); 	% nodal
	yel=y(nodi); 	% coordinates
	zel=z(nodi); 	% 
    fel=zeros(60,1);
	kel=zeros(60);	
    for j=1:27;
        ig=ig+1;
        s=str(1,j);
        t=str(2,j);
        r=str(3,j);
        [~,dNds,dNdt,dNdr] = shape20(s,t,r);

        H=[dNds dNdt dNdr]';
        J= H*[ xel    yel   zel]; 	% Jacobian

        detJ=abs(det(J));
        J1=inv(J);
        b=J1*H;
        % displacement-strain matrices:
        Bux(1:3:60)=b(1,:); Bux(60)=0;
        Buy(1:3:60)=b(2,:); Buy(60)=0;
        Buz(1:3:60)=b(3,:); Buz(60)=0;
        
        Bvx(2:3:60)=b(1,:); Bvx(60)=0;
        Bvy(2:3:60)=b(2,:); Bvy(60)=0;
        Bvz(2:3:60)=b(3,:); Bvz(60)=0;
        
        Bwx(3:3:60)=b(1,:);
        Bwy(3:3:60)=b(2,:);
        Bwz(3:3:60)=b(3,:); 
 
        % displacement derivatives
        ux=Bux*sel; uy=Buy*sel; uz=Buz*sel;
        vx=Bvx*sel; vy=Bvy*sel; vz=Bvz*sel; 
        wx=Bwx*sel; wy=Bwy*sel; wz=Bwz*sel; 
 
        B0=[Bux; Bvy; Bwz; Buy+Bvx;  Bvz+Bwy; Bwx+Buz];
        
        % Green-Lagrange strains:
        ex =ux+ux^2/2+vx^2/2+wx^2/2;
        ey =vy+uy^2/2+vy^2/2+wy^2/2;
        ez =wz+uz^2/2+vz^2/2+wz^2/2;
        exy=uy+vx +ux*uy+vx*vy+wx*wy;
        eyz=vz+wy +uy*uz+vy*vz+wy*wz;
        ezx=wx+uz +uz*ux+vz*vx+wz*wx;
        
        Gx =Bux'*Bux+Bvx'*Bvx+Bwx'*Bwx;
        Gy =Buy'*Buy+Bvy'*Bvy+Bwy'*Bwy;
        Gz =Buz'*Buz+Bvz'*Bvz+Bwz'*Bwz;
        Gxy=Bux'*Buy +Bvx'*Bvy +Bwx'*Bwy+ Buy'*Bux +Bvy'*Bvx +Bwy'*Bwx;
        Gyz=Buy'*Buz +Bvy'*Bvz +Bwy'*Bwz+ Buz'*Buy +Bvz'*Bvy +Bwz'*Bwy;
        Gzx=Buz'*Bux +Bvz'*Bvx +Bwz'*Bwx+ Bux'*Buz +Bvx'*Bvz +Bwx'*Bwz;
        BL=[sel'*Gx; sel'*Gy; sel'*Gz; sel'*Gxy; sel'*Gyz; sel'*Gzx];
         
        B=B0+BL;
        sigmt(ig,1:6,istep+1)=[ex ey ez exy eyz ezx]*DHooke;
        fel=fel+wg(j)*(B'*sigmt(ig,1:6,istep+1)')*detJ;
        kel=kel+wg(j)*(B'*DHooke*B+sigmt(ig,1,istep+1)*Gx+sigmt(ig,2,istep+1)*Gy+sigmt(ig,3,istep+1)*Gz+...
                 sigmt(ig,4,istep+1)*Gxy+sigmt(ig,5,istep+1)*Gyz+sigmt(ig,6,istep+1)*Gzx)*detJ;
        strnt(ig,:,istep+1)=[ex ey ez exy eyz ezx]; 
    end
    % assembling process:
    F(ipos)=F(ipos)+fel;
    K(ipos,ipos)=K(ipos,ipos)+kel;
end
% Constraints
loc=3*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 
% Concentrated force
loc=3*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;               

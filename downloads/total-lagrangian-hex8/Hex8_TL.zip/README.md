# Section 26.1 — Total Lagrangian HEX8

Run `main.m` in MATLAB with all files in the same folder.
The example is a three-dimensional cantilever with large displacements,
small strains and a linear elastic material, using eight Gauss points per element.

- `main.m`: load steps and Newton–Raphson iterations.
- `gen.m`: geometry, material, mesh, constraints and loading.
- `stiff.m`: element forces, tangent stiffness and global assembly.
- `grafic3d0.m`, `sides.m`: mesh/geometry plotting support.
- `plot_disp.m`, `plot_stress.m`: displacement and stress visualization.

The absolute displacement-increment criterion is `sqrt(dS'*dS/neq)`,
where `neq` is the number of equations.
A MATLAB installation supporting the functions used in the programs is required.
`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases,
replace `turbo` with `jet`. This affects visualization only and does not change
the numerical results. This is not a claim of full solver compatibility with
older releases.

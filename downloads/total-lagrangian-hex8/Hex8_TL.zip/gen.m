% *** gen ***
%==========================================================================
% It generates input data for a rectangular cross-section cantilevr beam:
%   L - beam length
%   t - cross-section width
%   h - cross-section height
%   E - Young modulus
%   nu - Poison ratio
%==========================================================================
% x, y, z - tables containing the nodal coordinates
%
% elem  table contains:  
%       [node1  node2  node3  node4  node5  node6  node7  node8  
%       [node1  node2  node3  node4  node5  node6  node7  node8 
%        :      :      :      :      :      :      :      :    ]
%
% cond  table contains nodal constraints 
%       (dir=1 - x direction, dir=2 - y direction, dir=3 - z direction)
%       [node1  dir1
%        node2  dir2
%        :      :   ]
% forze table contains nodal loads
%       [node1  dir1  force1
%        node2  dir2  force2
%        :      :     :     ]
%==========================================================================
% dimension:
L=200;   % Length (along x-axis)
t= 20;   % cros section width (along y-axis)
h=  5;   % cros section height (along z-axis)

E=2e5;
nu=0.3;
F1=4000; 
F2=4*F1; 

nL=50;
nt=6;
nh=4;

dL=L/nL;
dt=t/nt;
dh=h/nh;

nnd=(nt+1)*(nh+1)*(nL+1);
nel=nt*nh*nL;
x=zeros(nnd,1); y=zeros(nnd,1); z=zeros(nnd,1);
elem=ones(nel,8);
%===========================================
% Generation of the tables x, y, z
inod=0;
zz=0;
for i=1:nL+1
    yy=0;
    for j=1:nt+1   
        xx=0;
        for k=1:nh+1      
            inod=inod+1;
            x(inod)=zz;
            y(inod)=yy;
            z(inod)=xx;
            xx=xx+dh;
        end
        yy=yy+dt;
   end
   zz=zz+dL;
end
nnd=inod;
x0=x; y0=y; z0=z;
%===========================================
% Generation of the table "elem"
iel=0;
inod=0;
for i=1:nL
	for j=1:nt
        for k=1:nh
            inod=inod+1;
            iel=iel+1;
            ln1=[inod inod+1 inod+nh+2 inod+nh+1];
            ln2=ln1+(nh+1)*(nt+1);
            elem(iel,:)=[ln1  ln2];
        end
        inod=inod+1;
    end
    inod=inod+nh+1;
end
nel=iel;
%===========================================
% Generation of the table "cond"
ic=0;
for i=1:(nt+1)*(nh+1)
    ic=ic+1;
    cond(ic,1)=i;
    cond(ic,2)=1;
    ic=ic+1;
    cond(ic,1)=i;
    cond(ic,2)=2;
    ic=ic+1;
    cond(ic,1)=i;
    cond(ic,2)=3;
end
%===========================================
% Generation of the table "forze" 
dF=F1/nh/nt;
ij=0;
il=0;
for j=1:nt+1 
    for i=1:nh+1
       	dF0=dF;
        if i==1 | i==nh+1
            dF0=dF0/2;
        end
        if j==1 | j==nt+1
            dF0=dF0/2;
        end
        il=il+1;
        ij=ij+1;
        forze(ij,1)=nnd+1-il;
        forze(ij,2)=3;
        forze(ij,3)=-dF0;
        ij=ij+1;
        forze(ij,1)=nnd+1-il;
        forze(ij,2)=2;
        forze(ij,3)=-dF0*F2/F1;
    end
end

nnd
nel
neq=3*nnd
u=x*0;v=u;w=v;
grafic3d0
title('Mesh')
%===========================================
[nl ~]=size(forze);          
for i=1:nl
    nod=forze(i,1);
    dir=forze(i,2);
    ff =-forze(i,3)/2/10;
    if dir==1
        plot3([x(nod) x(nod)-ff],[y(nod) y(nod)],   [z(nod) z(nod)],'m','linewidth',2)
    elseif dir==2
        plot3([x(nod) x(nod)],   [y(nod) y(nod)-ff],[z(nod) z(nod)],'m','linewidth',2)
    elseif dir==3
        plot3([x(nod) x(nod)],   [y(nod) y(nod)],   [z(nod) z(nod)-ff],'m','linewidth',2)
    end
end

dth=min([dL,dh,dt]);
for i=1:length(cond(:,1))
    nod=cond(i,1);
    dir=cond(i,2);
    if dir==1
        plot3([x(nod) x(nod)-dth],[y(nod) y(nod)],    [z(nod) z(nod)],'r','linewidth',2)
    elseif dir==2
        plot3([x(nod) x(nod)],    [y(nod) y(nod)-dth],[z(nod) z(nod)],'r','linewidth',2)
    elseif dir==3
        plot3([x(nod) x(nod)],    [y(nod) y(nod)],    [z(nod) z(nod)-dth],'r','linewidth',2)
    end
end


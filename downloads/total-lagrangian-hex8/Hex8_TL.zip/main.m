% *** main ***
clear
format short e
nstep=20;   
tol=1e-4;
itermax=50;
% number of load steps
gen
S =zeros(neq,1);              % nodal displacements for the current load step
St=zeros(neq,nstep+1);        % nodal displacements for all load steps  
strnt=zeros(8*nel,6,nstep+1); % strains in finite elements for all load steps
sigmt=zeros(8*nel,7,nstep+1); % stresses in finite elements for all load steps
for istep=1:nstep
    error=1;
    iter=0;
    while (error > tol) & (iter < itermax)
        iter=iter+1;
        stiff
        dS=K\F;
        S=S-dS;
        error=sqrt(dS'*dS/neq);
    end
    u=S(1:3:neq);
    v=S(2:3:neq);
    w=S(3:3:neq);
    grafic3d0  
    drawnow
    [istep iter error]
    St(:,istep+1)=S;
    pause(0.01)
    % Von Mises stresses:
    sgech=sqrt( sigmt(:,1,istep).^2+sigmt(:,2,istep).^2+sigmt(:,3,istep).^2-...
                sigmt(:,1,istep).*sigmt(:,2,istep)-sigmt(:,2,istep).*sigmt(:,3,istep)-sigmt(:,3,istep).*sigmt(:,1,istep)+...
                3*sigmt(:,4,istep).^2+3*sigmt(:,5,istep).^2+3*sigmt(:,6,istep).^2);
    sigmt(:,7,istep+1)=sgech;
end

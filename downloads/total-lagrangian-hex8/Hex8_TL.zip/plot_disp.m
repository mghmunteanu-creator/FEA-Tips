% *** plot_disp ***
iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - does not plot        
idisp=input('Displacement (1-u, 2-v, 3-w, Default=3): ');
if length(idisp)==0, idisp=3; end
scale=input('Displacement scale (Default=1): ');
if length(scale)==0, scale=1; end
istep=input('Load case (Default=nstep): ');
if length(istep)==0, istep=nstep; end
S=St(:,istep+1);
u=S(1:3:neq);
v=S(2:3:neq);
w=S(3:3:neq);
x1=x+scale*u;
y1=y+scale*v;
z1=z+scale*w;

figure(10+idisp)
clf
hold on
axis('equal')

colormap(turbo(16));
displ=S(idisp:3:neq);

dmx=max(displ);
dmn=min(displ);
elem6=zeros(6*nel,4);
for ie=1:nel
    ii=6*ie-5;
    nodi=elem(ie,:);
    elem6(ii:ii+5,:) = [nodi([1 2 3 4])
                        nodi([5 6 7 8])
                        nodi([1 5 6 2])
                        nodi([2 6 7 3])
                        nodi([3 7 8 4])
                        nodi([4 8 5 1])];
end
elem6_sort=sort(elem6,2);
[~,~,ic]=unique(elem6_sort,'rows');
nr=accumarray(ic,1);
elem6=elem6(nr(ic)==1,:);

if iedge==0
    patch('Vertices',[x1 y1 z1],'Faces',elem6,'CData',displ,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[x1 y1 z1],'Faces',elem6,'CData',displ,'Facecolor','interp','edgecolor','w')
end
colorbar
lighting phong
view(3)
disp_max=dmx
disp_min=dmn

if idisp==1
    sss='u';
elseif idisp==2
    sss='v';    
elseif idisp==3
    sss='w';
end
title({[sss,',   Load step ',num2str(istep)],;['min= ',num2str(dmn),'  max=',num2str(dmx)]})
xlabel('x')
ylabel('y')
zlabel('z')
view(3);
sides
drawnow

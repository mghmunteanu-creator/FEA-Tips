% *** plot_stress ***
iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - does not plot
istress=input('Stress (1-sx, 2-sy, 3-sz, 4-txy, 5-tyz, 6-tzx, 7-VM, Default=1): ');
if length(istress)==0, istress=1; end
scale=input('Displacement scale (Default=0): ');
if length(scale)==0, scale=0; end
istep=input('Load case (Default=nstep): ');
if length(istep)==0, istep=nstep; end
S=St(:,istep+1);
S=St(:,istep+1);
u=S(1:3:neq);
v=S(2:3:neq);
w=S(3:3:neq);
x1=x+scale*u;
y1=y+scale*v;
z1=z+scale*w;
%==========================================================================
% extrapolation of the stresses from Gauss points to element nodes
% (the stresses are computed in stiff subprogram, in Gauss points)
sigmati=zeros(8*nel,7);
str=[-1   1  -1   1  -1   1  -1   1
     -1  -1   1   1  -1  -1   1   1
      1   1   1   1  -1  -1  -1  -1]*sqrt(3)/3;
ig=1;
for ie=1:nel
    nodi=elem(ie,:); 
    xel=x(nodi); 	% nodal
	yel=y(nodi); 	% coordinates
	zel=z(nodi); 	% 
    sig0=sigmt(ig:ig+7,istress,istep+1);
    for j=1:8
        s=str(1,j);
        t=str(2,j);
        r=str(3,j);
        N=[(1+s)*(1+t)*(1+r)/8 (1-s)*(1+t)*(1+r)/8 (1-s)*(1-t)*(1+r)/8 (1+s)*(1-t)*(1+r)/8 ...
           (1+s)*(1+t)*(1-r)/8 (1-s)*(1+t)*(1-r)/8 (1-s)*(1-t)*(1-r)/8 (1+s)*(1-t)*(1-r)/8];
        xst(j,1)=N*xel;
        yst(j,1)=N*yel;
        zst(j,1)=N*zel;
    end
    A0=[xst yst zst ones(8,1)];
    A=A0'*A0;
    B=A0'*sig0;
    a=A\B;
    sig=a(1)*xel+a(2)*yel+a(3)*zel+a(4)*ones(8,1);
    sigmti(ig:ig+7,istress)=sig;
    ig=ig+8;
end   
%===================================
if istress<=7
    stress0=zeros(nnd,2);
    is=0;
    for i=1:nel
        for j=1:8
            nod=elem(i,j);
            stress0(nod,2)=stress0(nod,2)+1;
            is=is+1;
            stress0(nod,1)=stress0(nod,1)+sigmti(is,istress);
        end
    end
    stress(:,1)=stress0(:,1)./(stress0(:,2)+1e-55);
end
smx=max(stress);
smn=min(stress);

elem6=zeros(6*nel,4);
for ie=1:nel
    ii=6*ie-5;
    nodi=elem(ie,:);
    elem6(ii:ii+5,:)=[nodi([1 2 3 4])
        nodi([5 6 7 8])
        nodi([1 5 6 2])
        nodi([2 6 7 3])
        nodi([3 7 8 4])
        nodi([4 8 5 1])];
end
elem6_sort=sort(elem6,2);
[~,~,ic]=unique(elem6_sort,'rows');
nr=accumarray(ic,1);
elem6=elem6(nr(ic)==1,:);
%==========================================================================
figure(15+istress)
clf
hold on
axis('equal')
colormap(turbo(16));
if iedge==0
    patch('Vertices',[x1 y1 z1],'Faces',elem6,'CData',stress,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[x1 y1 z1],'Faces',elem6,'CData',stress,'Facecolor','interp','edgecolor','w')
end
colorbar
view(3)
max_value=smx
min_value=smn

lighting phong

titlu='\sigma_x\sigma_y\sigma_z\tau_x_y\tau_y_z\tau_z_xVM      u       v       w       ';
sss=titlu(8*(istress-1)+1:8*istress);
title({sss;['min= ',num2str(smn),'  max=',num2str(smx)]})

xlabel('x')
ylabel('y')
zlabel('z')
view([-234 12]);
view(3)
sides
drawnow

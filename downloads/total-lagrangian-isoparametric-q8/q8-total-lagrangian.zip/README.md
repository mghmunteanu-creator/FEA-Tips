# Section 12.3 — Total Lagrangian Q8 plane-stress finite element

Run `main.m`. The example is a cantilever with L=400 mm, H=20 mm,
thickness=5 mm, E=1000 MPa, nu=0.3 and a downward resultant of 100 N.
The mesh uses nL=60 and nH=8: 480 elements, 1577 nodes and 3154 DOFs.

- `main.m`: five load steps and the Newton–Raphson solution.
- `gen.m`: geometry, Q8 connectivity, constraints, loading and mesh plot.
- `stiff.m`: nine-point Gauss integration, internal forces, consistent
  tangent stiffness, assembly and boundary conditions.
- `plot_disp.m`: nodal displacement map for the selected load step.
- `plot_stress.m`: second Piola–Kirchhoff stresses evaluated at the eight
  element nodes and averaged at common nodes; includes the von Mises measure.

After `main`, run either plotting routine. Press Enter for the defaults:
final load step; vertical displacement (2) or normal stress sigma_x (1);
displacement scale 1. St(:,istep+1) contains the selected displacement state.
The stress routine recalculates stresses at the selected step.

The full example and plotting routines were tested in MATLAB R2026a Update 4.
`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases,
replace `turbo` with `jet`. This affects visualization only and does not
change the numerical results.

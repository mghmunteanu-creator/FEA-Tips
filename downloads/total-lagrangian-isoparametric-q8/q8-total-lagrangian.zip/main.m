%*** main ***
clear
format short e
nstep=5;                    % number of load steps
itermax=100;                % number of maximum iterations
tol=1e-5;                   % tolerance
gen
S =zeros(neq,1);            % nodal displacements for the current load step
St=zeros(neq,nstep+1);      % nodal displacements for all load steps  
strnt=zeros(9*nel,3,nstep); % nine Gauss-point strain values are stored for each element
sigmt=zeros(9*nel,4,nstep); % nine Gauss-point stress values are stored for each element
for istep=1:nstep
    error=1;
    iter=0;
    while (error > tol) & (iter < itermax)
        iter=iter+1;
        stiff
        dS=K\F;
        S=S-dS;
        error=sqrt(dS'*dS/neq);
    end
    u=S(1:2:neq);
    v=S(2:2:neq);
    patch('Vertices',[x+u y+v],'Faces',elem(:,[1 5 2 6 3 7 4 8]),'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b')    
    drawnow
    [istep iter error]
    St(:,istep+1)=S;
    pause(0.01)
end
% Von Mises stresses:
sgech=sqrt(sigmt(:,1,istep).^2+sigmt(:,2,istep).^2-sigmt(:,1,istep).*sigmt(:,2,istep)+3*sigmt(:,3,istep).^2);
sigmt(:,4,istep)=sgech;
  

%*** stiff ***
neq=2*nnd;
E1=E/(1-nu*nu);  
E2=nu*E1;
G=E/2/(1+nu);
DHooke=[E1 E2 0
        E2 E1 0
         0  0 G];
F=zeros(neq,1);
K=zeros(neq);
% Gauss points, 3rd order
xgss=sqrt(0.6);
xgauss=[  -xgss      0     xgss];	
wgauss=[   5/9      8/9    5/9 ];	
xgs=[xgauss; xgauss; xgauss]; xgt=xgs';
xgs=xgs(:); xgt=xgt(:);
wgs=[wgauss; wgauss; wgauss]; wgt=wgs';
wgs=wgs(:); wgt=wgt(:);
ig=0;
for ie=1:nel;
	nodi=elem(ie,:);
    ip=[2*nodi-1; 2*nodi];
    ip=ip(:);
    sel=S(ip);
    %----------------------------------------------------------------------
	xel=x(nodi);         % nodal
	yel=y(nodi);         % coordinates 
    fel=zeros(16,1);
	kel=zeros(16);
	for j=1:9;
        ig=ig+1;
        s=xgs(j);
        t=xgt(j);
        dps0=[(1+t)/4  -(1+t)/4  -(1-t)/4  (1-t)/4     0     0     0     0];    
        dpt0=[(1+s)/4   (1-s)/4  -(1-s)/4 -(1+s)/4     0     0     0     0]; 	

        dps1=[   0    0    0    0    -s*(1+t)   -(1-t^2)/2  -s*(1-t)     (1-t^2)/2 ]; 	
        dpt1=[   0    0    0    0    (1-s^2)/2  -t*(1-s)    -(1-s^2)/2  -t*(1+s)   ]; 	

        dps2=[ (1-t^2)/2  -s*(1+t)    -(1-t^2)/2  -s*(1-t)      0      0     0     0]/2; 	
        dpt2=[-t*(1+s)     (1-s^2)/2  -t*(1-s)    -(1-s^2)/2    0      0     0     0]/2; 

        dps3=[-s*(1+t)    -(1-t^2)/2  -s*(1-t)     (1-t^2)/2    0      0     0     0]/2; 	
        dpt3=[ (1-s^2)/2  -t*(1-s)    -(1-s^2)/2  -t*(1+s)      0      0     0     0]/2; 	

        dps=dps0+dps1-dps2-dps3;
        dpt=dpt0+dpt1-dpt2-dpt3;

        H=[dps
            dpt];
        J=H*[ xel  yel];	% Jacobian
        detJ=abs(det(J));
        J1=inv(J);
        b=J1*H;

        Bux=[b(1,1:8)
             zeros(1,8)]; Bux=Bux(:)';
        Buy=[b(2,1:8)
            zeros(1,8)];  Buy=Buy(:)';

        Bvx=[zeros(1,8)
             b(1,1:8)];  Bvx=Bvx(:)';

        Bvy=[zeros(1,8)
            b(2,1:8)];  Bvy=Bvy(:)';

        ux=Bux*sel;
        uy=Buy*sel;
        vx=Bvx*sel;
        vy=Bvy*sel; 
        B0=[Bux; Bvy; Buy+Bvx];
        
        % Green-Lagrange strains:
        ex =ux+ux^2/2+vx^2/2;
        ey =vy+uy^2/2+vy^2/2;
        exy=uy+vx+ux*uy+vx*vy;
        
        Gx =Bux'*Bux+Bvx'*Bvx;
        Gy =Buy'*Buy+Bvy'*Bvy;
        Gxy=Bux'*Buy+Bvx'*Bvy+Buy'*Bux+Bvy'*Bvx;
        BL=[sel'*Gx; sel'*Gy; sel'*Gxy];
         
        B=B0+BL;
        sigmt(ig,1:3,istep)=[ex ey exy]*DHooke;
    
        fel=fel+wgs(j)*wgt(j)*th*(B'*sigmt(ig,1:3,istep)')*detJ;
        kel=kel+wgs(j)*wgt(j)*th*(B'*DHooke*B+sigmt(ig,1,istep)*Gx+sigmt(ig,2,istep)*Gy+sigmt(ig,3,istep)*Gxy)*detJ;

        strnt(ig,:,istep)=[ex ey exy];
    end
    % assembling process:
    F(ip)=F(ip)+fel;
    K(ip,ip)=K(ip,ip)+kel;
end
% Constraints
loc=2*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 
% Concentrated force
loc=2*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;               

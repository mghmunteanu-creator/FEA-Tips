# Section 12.2 — ANSYS comparison model

## Purpose

This package contains the ANSYS Mechanical APDL macro used for comparison with the Total Lagrangian isoparametric 4-node quadrilateral finite-element example in Section 12.2.

## Model

The macro defines a plane-stress PLANE182 model with a thickness of 5 mm, Young's modulus of 1000 MPa, and Poisson's ratio of 0.3. It contains 1,920 quadrilateral elements and 2,057 nodes. The left end is clamped and a total vertical force of 100 N is distributed over the free-end nodes. Large-displacement analysis is enabled.

## How to run

Run `macro.mac` in ANSYS Mechanical APDL. The macro creates the model, applies the constraints and loads, and solves the nonlinear static problem.

## Validation status

This macro was validated in the original version of the example. It has been transferred to the present edition without technical modification and was therefore not re-executed during the current revision.

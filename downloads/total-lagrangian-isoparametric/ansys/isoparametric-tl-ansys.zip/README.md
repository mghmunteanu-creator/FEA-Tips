# Section 12.2 — ANSYS comparison macro

The package contains the Mechanical APDL macro for the plane-stress cantilever comparison presented in Section 12.2.

This macro was validated in the original version of the example. It has been transferred to the present edition without technical modification and was therefore not re-executed during the current revision.

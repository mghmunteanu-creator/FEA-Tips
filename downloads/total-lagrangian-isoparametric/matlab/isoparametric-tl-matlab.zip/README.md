# Section 12.2 — Total Lagrangian Q4 finite element

This package solves the large-displacement plane-stress cantilever example of Section 12.2 with a Total Lagrangian formulation and 4-node isoparametric quadrilateral elements.

## Files

- `main.m` — load stepping and Newton–Raphson iterations.
- `gen.m` — geometry, material, mesh, constraints, and loading.
- `stiff.m` — Green–Lagrange strains, second Piola–Kirchhoff stresses, internal forces, and tangent stiffness matrix.
- `plot_disp.m` — displacement maps.
- `plot_stress.m` — nodally averaged stress maps.

## Run

Open the package directory in MATLAB and run `main`. The included example uses a 400 mm × 20 mm cantilever, 5 mm thickness, 120 elements along the length, 16 elements through the height, and five load steps. After the analysis, run `plot_disp` or `plot_stress` and press Enter to accept the displayed defaults.

The plotting routines evaluate stresses at the four element-node natural coordinates and average contributions at nodes shared by adjacent elements.

## Compatibility

Tested in MATLAB R2026a. The solver uses standard MATLAB syntax and is expected to be compatible with newer MATLAB versions.

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

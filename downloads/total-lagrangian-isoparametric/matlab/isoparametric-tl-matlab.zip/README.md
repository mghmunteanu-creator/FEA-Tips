# Section 12.2 — Total Lagrangian Q4 finite element

## Purpose

This package implements the Total Lagrangian formulation of a plane-stress isoparametric 4-node quadrilateral finite element for small strains, large displacements, and a linear elastic material.

## Files

- `main.m` — main Newton–Raphson analysis program.
- `gen.m` — geometry, mesh, boundary conditions, material data, and loading.
- `stiff.m` — element internal-force and tangent-stiffness calculation and global assembly.
- `plot_disp.m` — horizontal or vertical displacement map.
- `plot_strain.m` — Green–Lagrange strain map.
- `plot_stress.m` — second Piola–Kirchhoff or Von Mises stress map.

## Model

The example is a 400 mm long cantilever with a 5 mm × 20 mm rectangular cross-section. The material properties are `E=1000 MPa` and `nu=0.3`. A total vertical force of 100 N is distributed at the free end. The mesh contains 120 elements along the beam and 16 elements through its height: 1,920 Q4 finite elements, 2,057 nodes, and 4,114 equations.

## How to run

1. Place all MATLAB files in the same folder.
2. Set that folder as the MATLAB current folder.
3. Run `main`.
4. Run `plot_disp`, `plot_strain`, or `plot_stress` to display a selected result and load step. Press Enter at a prompt to accept the stated default.

The displacement figures published with Section 12.2 use displacement scale 1 and `axis('equal')`.

## Output and verified results

The program stores nodal displacements for all five load steps and Gauss-point strains and stresses. In the supplied example, all five load steps reached convergence. At the final load step:

- maximum horizontal-displacement magnitude: 159.51 mm;
- maximum vertical-displacement magnitude: 288.79 mm;
- Gauss-point axial Green–Lagrange strain range: -0.0726 to 0.0738;
- nodally averaged normal-stress range used for plotting: -82.72 MPa to 84.62 MPa;
- nodally averaged Von Mises stress range used for plotting: 0.189 MPa to 79.54 MPa.

## MATLAB compatibility

Tested in MATLAB R2026a. The code uses standard MATLAB syntax and is expected to be compatible with newer MATLAB versions.

Colormap compatibility: `turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

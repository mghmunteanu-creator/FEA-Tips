%*** plot_strain ***
iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - does not plot
istep=input('Load step [Default: nstep]: ');
if length(istep)==0; istep=nstep; end
istrain=input('Strain (1-ex, 2-ey, 3-gxy) [Default: 1]: ');
if length(istrain)==0; istrain=1; end
scale=1;
u=St(1:2:neq,istep+1);
v=St(2:2:neq,istep+1);
disp(' ');
disp('Load step');
istep
%==========================================================================
% Natural coordinates of the four element nodes
st=[1  -1  -1   1
    1   1  -1  -1];
ig=0;
for i=1:nel;
	n1=elem(i,1); n2=elem(i,2); n3=elem(i,3); n4=elem(i,4);
    ip=[2*n1-1  2*n1  2*n2-1  2*n2  2*n3-1  2*n3  2*n4-1  2*n4]; 
    sel=S(ip);
    %----------------------------------------------------------------------
	xel=[x(n1) x(n2) x(n3) x(n4)]'; 	% nodal
	yel=[y(n1) y(n2) y(n3) y(n4)]'; 	% coordinates 
	for j=1:4;
        ig=ig+1;
        s=st(1,j);
        t=st(2,j);
        H=[(1+t)/4  -(1+t)/4  -(1-t)/4  (1-t)/4
           (1+s)/4   (1-s)/4  -(1-s)/4 -(1+s)/4]; 	
        J=H*[ xel    yel];              % Jacobian
        detJ=abs(det(J));
        J1=inv(J);
        b=J1*H;
        Bux=[b(1,1)  0        b(1,2)   0        b(1,3)   0        b(1,4)   0     ];
        Buy=[b(2,1)  0        b(2,2)   0        b(2,3)   0        b(2,4)   0     ];
        Bvx=[0       b(1,1)   0        b(1,2)   0        b(1,3)   0        b(1,4)]; 
        Bvy=[0       b(2,1)   0        b(2,2)   0        b(2,3)   0        b(2,4)];            
        ux=Bux*sel;
        uy=Buy*sel;
        vx=Bvx*sel;
        vy=Bvy*sel; 
        
        % Green-Lagrange strains:
        ex =ux+ux^2/2+vx^2/2;
        ey =vy+uy^2/2+vy^2/2;
        exy=uy+vx+ux*uy+vx*vy;
        strain(ig,1:3,istep)=[ex ey exy];
    end
end
%==========================================================================
% Average element nodal strains at common mesh nodes
strs=zeros(nnd,2);
isg=0;
for i=1:nel
    for j=1:4
        nod=elem(i,j);
        strs(nod,2)=strs(nod,2)+1;
        isg=isg+1;
        strs(nod,1)=strs(nod,1)+strain(isg,istrain,istep);
    end
end
strain=strs(:,1)./strs(:,2);
%==========================================================================
x1=x+scale*u;
y1=y+scale*v;
figure(20)
clf
hold on
axis('equal')
colormap(turbo(16))
smx=max(strain);
smn=min(strain);
if iedge==0
    patch('Vertices',[x1 y1],'Faces',elem,'CData',strain,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[x1 y1],'Faces',elem,'CData',strain,'Facecolor','interp','edgecolor','w')
end
colorbar
lighting phong
strain_max=smx
strain_min=smn
if istrain==1
    title(['\epsilon_x  -  ','Load step ',num2str(istep)])
elseif istrain==2
    title(['\epsilon_y  -  ','Load step ',num2str(istep)])   
elseif istrain==3
    title(['\gamma_x_y  -  ','Load step ',num2str(istep)])  
end
drawnow

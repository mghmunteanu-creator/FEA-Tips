%*** plot_stress ***
iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - does not plot
istep=input('Load step (default nstep): ');
if length(istep)==0; istep=nstep; end
istress=input('Stress (1-sx, 2-sy, 3-txy, 4-VM; default 1): ');
if length(istress)==0; istress=1; end
scale=input('Displacement scale (default 1): ');
if length(scale)==0; scale=1; end
u=St(1:2:neq,istep+1);
v=St(2:2:neq,istep+1);
disp(' ');
disp('Load step');
istep
%==========================================================================
E1=E/(1-nu*nu);  
E2=nu*E1;
G=E/2/(1+nu);
DHooke=[E1 E2 0
        E2 E1 0
         0  0 G];
% Natural coordinates of the four element nodes
st=[1  -1  -1   1
    1   1  -1  -1];
ig=0;
for i=1:nel;
	n1=elem(i,1); n2=elem(i,2); n3=elem(i,3); n4=elem(i,4);
    ip=[2*n1-1  2*n1  2*n2-1  2*n2  2*n3-1  2*n3  2*n4-1  2*n4]; 
    sel=S(ip);
    %----------------------------------------------------------------------
	xel=[x(n1) x(n2) x(n3) x(n4)]'; 	% nodal
	yel=[y(n1) y(n2) y(n3) y(n4)]'; 	% coordinates 
	for j=1:4;
        ig=ig+1;
        s=st(1,j);
        t=st(2,j);
        H=[(1+t)/4  -(1+t)/4  -(1-t)/4  (1-t)/4
           (1+s)/4   (1-s)/4  -(1-s)/4 -(1+s)/4]; 	
        J=H*[ xel    yel];              % Jacobian
        detJ=abs(det(J));
        J1=inv(J);
        b=J1*H;
        Bux=[b(1,1)  0        b(1,2)   0        b(1,3)   0        b(1,4)   0     ];
        Buy=[b(2,1)  0        b(2,2)   0        b(2,3)   0        b(2,4)   0     ];
        Bvx=[0       b(1,1)   0        b(1,2)   0        b(1,3)   0        b(1,4)]; 
        Bvy=[0       b(2,1)   0        b(2,2)   0        b(2,3)   0        b(2,4)];            
        ux=Bux*sel;
        uy=Buy*sel;
        vx=Bvx*sel;
        vy=Bvy*sel; 
        
        % Green-Lagrange strains:
        ex =ux+ux^2/2+vx^2/2;
        ey =vy+uy^2/2+vy^2/2;
        exy=uy+vx+ux*uy+vx*vy;
        sigma(ig,1:3,istep)=[ex ey exy]*DHooke;
    end
end
sgech=sqrt(sigma(:,1,istep).^2+sigma(:,2,istep).^2-sigma(:,1,istep).*sigma(:,2,istep)+3*sigma(:,3,istep).^2);
sigma(:,4,istep)=sgech;
%==========================================================================
strs=zeros(nnd,2);
isg=0;
% Average element-node stress contributions at shared mesh nodes
for i=1:nel
    for j=1:4
        nod=elem(i,j);
        strs(nod,2)=strs(nod,2)+1;
        isg=isg+1;
        strs(nod,1)=strs(nod,1)+sigma(isg,istress,istep);
    end
end
stress=strs(:,1)./strs(:,2);
%==========================================================================
x1=x+scale*u;
y1=y+scale*v;
figure(15)
clf
hold on
axis('equal')
colormap(turbo(16))
smx=max(stress);
smn=min(stress);
if iedge==0
    patch('Vertices',[x1 y1],'Faces',elem,'CData',stress,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[x1 y1],'Faces',elem,'CData',stress,'Facecolor','interp','edgecolor','w')
end
colorbar
lighting phong
sigma_max=smx
sigma_min=smn
if istress==1
    title(['\sigma_x  -  ','Load step ',num2str(istep)])
elseif istress==2
    title(['\sigma_y  -  ','Load step ',num2str(istep)])   
elseif istress==3
    title(['\tau_x_y  -  ','Load step ',num2str(istep)])  
elseif istress==4
    title(['\sigma_v_o_n_ _M_i_s_e_s  -  ','Load step ',num2str(istep)])
end

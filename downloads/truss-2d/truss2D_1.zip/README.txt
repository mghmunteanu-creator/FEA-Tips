2D truss structures with large displacements
Direct symbolic-derivative implementation

Run main.m in MATLAB R2017b or later.

Tested with MATLAB R2026a and MATLAB R2017b.

The program uses engineering axial strain, linear elastic material behavior,
dead nodal loads, and an exact consistent tangent stiffness matrix.

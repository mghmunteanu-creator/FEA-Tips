%*** bc_grph ***
for i=1:length(forze(:,1))
    nd =forze(i,1); dir=forze(i,2);
    if dir==1
        quiver(x(nd)+S(2*nd-1),y(nd)+S(2*nd),-mean(LL),0,'r','linewidth',1.5)
    else
        quiver(x(nd)+S(2*nd-1),y(nd)+S(2*nd),0,-mean(LL),'r','linewidth',1.5)
    end
end
dd=mean(LL)/2;
for i=1:length(cond(:,1))
    nd=cond(i,1); dir=cond(i,2);
    xt=x(nd); yt=y(nd);
    if dir==1
        fill([xt xt-dd/1.5 xt-dd/1.5],[yt yt+dd/3 yt-dd/3],'g')
    else
        fill([xt xt-dd/3 xt+dd/3],[yt yt-dd/1.5 yt-dd/1.5],'g')
    end
end

%*** gen ***
%==========================================================================
% x, y  vectors that contains the nodal coordinates
%          
% elem  table contains: 
%     element nodes, Young modulus of the material, cross-section area
%       [node1  node2  E1  A1
%       [node1  node2  E2  A2
%        :      :      :   :  ]
%
% cond  table contains nodal constraints
%       (dir=1 - x direction, dir=2 - y direction)
%       [node1  dir1
%        node2  dir2
%        :      :   ]
%
% forze table contains nodal loads
%       [node1  dir1  force1
%        node2  dir2  force2
%        :      :     :     ]
%==========================================================================
a=5;
b=5;
nc=25;
A=25;
E=2e3;
icell=[1 3 
       1 4 
       2 3 
       2 4 
       3 4];
xy=[];   
for i=1:nc+1
    xy=[xy
       (i-1)*b  0  0
       (i-1)*b  a  0];
end
x=xy(:,1); y=xy(:,2);

elem=[1 2 E A];
for i=1:nc
    elem=[elem
          icell+2*(i-1) E*ones(5,1) A*ones(5,1)];
end

nnd=length(x(:,1));     % number of nodes
nel=length(elem(:,1));  % number of truss elements
neq=2*nnd;              % number of equations
    
%      n    dir 
cond=[ 1     1   
       1     2  
       2     1   
       2     2];

%        n    dir   force
forze=[nnd-1   1    -200
       nnd-1   2    -100
       nnd     1    -200
       nnd     2    -100];
    

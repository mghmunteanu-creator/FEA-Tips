%*** main ***
% Tested with MATLAB R2026a and MATLAB R2017b.
clear
gen
nstep=5;        % number of load steps
itermax=100;    % max number of iterations
tol=1e-5;       % tolerance
figure(5), clf, hold on, grid on, axis('equal')
patch('Vertices',[x  y],'Faces',elem(:,1:2),'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b')
drawnow
xlabel('x'), ylabel('y')
S=zeros(neq,1); % Nodal displacements of the truss structure
St=zeros(neq,nstep+1);
straint=zeros(nel,nstep+1);
stresst=zeros(nel,nstep+1);
for istep=1:nstep
    iter=0;
    err=1;
    while err > tol && iter<itermax
        iter=iter+1;
        stiff
        % Newton-Raphson method:
        dS=-K\F;            % dS - displacement increment
        S=S+dS;             %  S - nodal displacements of the truss structure
        err=sqrt(dS'*dS/neq);
    end
    if err > tol
        warning('main:NoConvergence', ...
            'Load step %d did not converge after %d iterations.',istep,itermax)
    end
    [istep iter err]
    St(:,istep+1)=S;
    % Graphical representation of the deformed truss structure:
    patch('Vertices',[x+S(1:2:neq)  y+S(2:2:neq)],'Faces',elem(:,1:2),'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','m')
    drawnow
    pause(0.1)
    % Graphical representation of boundary condition (load & constraints)
    bc_grph
    strain_stress               % calculates the strains and stresses
end
prnt_reslts


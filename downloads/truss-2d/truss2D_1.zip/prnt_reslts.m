%*** prnt_reslts ***
% print the results
ist=input('Number of the load step (default nstep): ');
if length(ist)==0; ist=nstep; end
disp(' ')
disp(['Step number: ',num2str(ist)]);
S=St(:,ist+1);
S=reshape(S,2,nnd)';
str=num2str([[1:nnd]' S]);
disp('Node  u            v')
disp(num2str([[1:nnd]' S],'%-5.0f %-12.5g %-12.5g\n'))
w1=1e6; w2=1e5;
strain=straint(:,ist+1);
stress=stresst(:,ist+1);
strain=round(strain*w1)/w1;
stress=round(stress*w2)/w2;
disp('  ')
disp('Truss Node1 Node2 Strain       Stress')
disp(num2str([[1:nel]' elem(:,1) elem(:,2) strain stress],'%-5.0f %-5.0f %-5.0f %-12.5g %-12.5g\n'));



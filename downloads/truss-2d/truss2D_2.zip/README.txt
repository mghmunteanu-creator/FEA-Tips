2D truss structures with large displacements
Compact exact-derivative implementation

Run main.m in MATLAB R2017b or later.

Tested with MATLAB R2026a and MATLAB R2017b.

deriv.m evaluates the exact strain gradient and Hessian. The resulting
tangent stiffness matrix is consistent with the internal-force vector.

%*** deriv ***
% Exact engineering strain and its first two displacement derivatives.
% Current element-axis components:
qx=dx+du;
qy=dy+dv;

% Engineering strain:
ep=Lf/L-1;

% a = derivative of (Lf^2/2) with respect to element displacements.
a=[-qx
   -qy
    qx
    qy];

% First derivative (strain gradient):
ep1=a/(L*Lf);

% Constant part of the second derivative:
G=[ 1  0 -1  0
    0  1  0 -1
   -1  0  1  0
    0 -1  0  1];

% Exact second derivative (strain Hessian):
ep2=G/(L*Lf)-(a*a')/(L*Lf^3);
    

%*** prnt_reslts ***
% print the results
ist=input('Load step number: ');
S=St(:,ist+1);
S=reshape(S,2,nnd)';
str=num2str([[1:nnd]' S]);
['Node           u             v';str]
w1=1e6; w2=1e5;
strain=straint(:,ist+1);
stress=stresst(:,ist+1);
strain=round(strain*w1)/w1;
stress=round(stress*w2)/w2;
str=num2str([[1:nel]' strain stress]);
['  Truss    Strain        Stress'; str]

%*** strain ***
for ie=1:nel
    n1=elem(ie,1); n2=elem(ie,2);
    x1=x(n1); y1=y(n1); x2=x(n2); y2=y(n2);
    dx=x2-x1; dy=y2-y1;
    u1=S(2*n1-1); v1=S(2*n1); u2=S(2*n2-1); v2=S(2*n2);
    du=u2-u1; dv=v2-v1;
    L =sqrt(dx*dx+dy*dy);
    Lf=sqrt((dx+du)^2+(dy+dv)^2);
    epsilon(ie,1)=(Lf-L)/L;
end
str=num2str([[1:nel]' epsilon]);
['  Truss    strain'; str]
    



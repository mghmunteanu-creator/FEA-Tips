2D truss structures with large displacements
Nonlinear elastic material implementation

Run main.m in MATLAB R2017b or later.

Tested with MATLAB R2026a and MATLAB R2017b.

Hk in gen.m defines nominal stress versus engineering strain. The program
uses shape-preserving cubic interpolation, the corresponding material
tangent, and the exact geometric strain Hessian. It stops with a clear error
if an iteration leaves the tabulated strain interval.

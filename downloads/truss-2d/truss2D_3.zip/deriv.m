%*** deriv ***
% Exact engineering strain and its first two displacement derivatives.
qx=dx+du;
qy=dy+dv;
ep=Lf/L-1;
[sg,Et]=material_response(ep,Hk);

a=[-qx
   -qy
    qx
    qy];
ep1=a/(L*Lf);

G=[ 1  0 -1  0
    0  1  0 -1
   -1  0  1  0
    0 -1  0  1];
ep2=G/(L*Lf)-(a*a')/(L*Lf^3);
    

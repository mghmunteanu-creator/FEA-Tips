%*** gen ***
%==========================================================================
% x     table contains the nodal coordinates
%           [x1  y1
%            x2  y2
%            :   :
%            xn  yn]
%
% elem  table contains: 
%     element nodes, cross-section area
%       [node1  node2  A1
%        node1  node2  A2
%        :      :      : ]
%
% Hk - Hooke's law
%       [eps1 sig1
%        eps2 sig2
%        :    :   ]
% cond  table contains nodal constraints
%       (dir=1 - x direction, dir=2 - y direction)
%       [node1  dir1
%        node2  dir2
%        :      :   ]
%
% forze table contains nodal loads
%       [node1  dir1  force1
%        node2  dir2  force2
%        :      :     :     ]
%==========================================================================
a=5;
b=5;
nc=25;
A=25;
E=2e3;
icell=[1 3 
       1 4 
       2 3 
       2 4 
       3 4];
xy=[];   
for i=1:nc+1
    xy=[xy
       (i-1)*b  0  0
       (i-1)*b  a  0];
end
x=xy(:,1); y=xy(:,2);

elem=[1 2 A];
for i=1:nc
    elem=[elem
          icell+2*(i-1) A*ones(5,1)];
end
%        sigma(strain)
%    strain       stress
Hk=[        0            0
   1.0000e-02   2.0000e+01
   2.0000e-02   3.9183e+01
   3.0000e-02   5.7551e+01
   4.0000e-02   7.5101e+01
   5.0000e-02   9.1836e+01
   6.0000e-02   1.0775e+02
   7.0000e-02   1.2286e+02
   8.0000e-02   1.3714e+02
   9.0000e-02   1.5061e+02
   1.0000e-01   1.6326e+02
   1.1000e-01   1.7510e+02
   1.2000e-01   1.8612e+02
   1.3000e-01   1.9632e+02
   1.4000e-01   2.0571e+02
   1.5000e-01   2.1428e+02
   1.6000e-01   2.2204e+02
   1.7000e-01   2.2898e+02
   1.8000e-01   2.3510e+02
   1.9000e-01   2.4041e+02
   2.0000e-01   2.4490e+02];
nnd=length(x(:,1));     % number of nodes
nel=length(elem(:,1));  % number of truss elements
neq=2*nnd;              % number of equations
    
%      n    dir 
cond=[ 1     1   
       1     2  
       2     1   
       2     2];

%        n    dir   force
forze=[nnd-1   2    -100
       nnd     2    -100];
    

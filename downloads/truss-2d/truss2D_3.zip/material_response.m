function [sigma,Et] = material_response(epsilon,Hk)
%MATERIAL_RESPONSE Interpolate nominal stress and its consistent tangent.
%   Hk(:,1) contains nonnegative engineering strains and Hk(:,2) the
%   corresponding nonnegative nominal stresses. The law is extended as an
%   odd function in stress, with an even tangent modulus.

epsAbs=abs(epsilon);
epsMin=Hk(1,1);
epsMax=Hk(end,1);
if epsAbs < epsMin || epsAbs > epsMax
    error('material_response:OutsideTable', ...
        'Absolute strain %.6g is outside the tabulated interval [%.6g, %.6g].', ...
        epsAbs,epsMin,epsMax);
end

% Shape-preserving cubic interpolation and its analytical derivative.
pp=pchip(Hk(:,1),Hk(:,2));
[breaks,coefs,nPieces,order]=unmkpp(pp);
if epsAbs == breaks(end)
    interval=nPieces;
else
    interval=find(epsAbs >= breaks(1:end-1) & ...
                  epsAbs <  breaks(2:end),1,'last');
end

localCoordinate=epsAbs-breaks(interval);
c=coefs(interval,:);
sigmaAbs=polyval(c,localCoordinate);
dc=c(1:end-1).*(order-1:-1:1);
Et=polyval(dc,localCoordinate);

sigma=sign(epsilon)*sigmaAbs;
if epsilon == 0
    sigma=0;
end
end

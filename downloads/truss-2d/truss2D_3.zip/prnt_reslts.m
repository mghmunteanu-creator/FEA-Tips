%*** prnt_reslts ***
% print the results
ist=input('Number of the load step (default nstep): ');
if length(ist)==0; ist=nstep; end
disp(' ')
disp(['Step number: ',num2str(ist)]);
disp(' ')
S=St(:,ist+1);
S=reshape(S,2,nnd)';
str=num2str([[1:nnd]' S]);
disp(['Node           u             v'])
disp(str)
disp(' ')
w1=1e6; w2=1e5;
strain=straint(:,ist+1);
stress=stresst(:,ist+1);
strain=round(strain*w1)/w1;
stress=round(stress*w2)/w2;
str=num2str([[1:nel]' strain stress]);
disp(['Truss      Strain        Stress'])
disp(str)

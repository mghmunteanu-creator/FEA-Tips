%*** stiff ***
% Assemble the residual and the consistent material/geometric tangent.
K=zeros(neq);             
F=zeros(neq,1);   
for ie=1:nel
    n1=elem(ie,1); n2=elem(ie,2); 
    x1=x(n1); y1=y(n1); x2=x(n2); y2=y(n2);
    dx=x2-x1; dy=y2-y1;
    Ael=elem(ie,3);
    ip=[2*n1-1  2*n1  2*n2-1  2*n2];
    uel=S(ip); 
    u1=uel(1); v1=uel(2); u2=uel(3); v2=uel(4);
    du=u2-u1; dv=v2-v1;
    L =sqrt(dx*dx+dy*dy);LL(ie)=L;
    Lf=sqrt((dx+du)^2+(dy+dv)^2);
    deriv
    % For U = A*L*integral_0^ep sigma(xi) dxi:
    fel=Ael*L*sg*ep1;
    kel=Ael*L*(Et*(ep1*ep1')+sg*ep2);
    K(ip,ip)=K(ip,ip) + kel; 
    F(ip)     =F(ip)      + fel;
end
% Nodal load:
loc=2*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;
% Fixed DOFs:
loc=2*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; 
K(loc,loc)=eye(length(loc)); 
F(loc,:  )=0;  

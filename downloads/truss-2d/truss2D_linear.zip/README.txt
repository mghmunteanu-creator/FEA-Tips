Linear analysis of 2D truss structures

Run main.m in MATLAB R2017b or later.

Tested with MATLAB R2026a and MATLAB R2017b.

The program uses the standard small-displacement, small-strain truss
stiffness matrix and reports nodal displacements and element axial results.

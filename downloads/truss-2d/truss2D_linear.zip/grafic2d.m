%*** grafic2d ***

disp('Node  u_displacement  v_displacement')
u=S(1:2:neq);
v=S(2:2:neq);
disp(num2str([[1:nnd]' u(:) v(:)],'%-5.0f %-12.5g    %-12.5g\n'))

scale=input('Scale (default=1): ');
if length(scale)==0, scale=1; end
x1=x+scale*u;
y1=y+scale*v;

figure(10)
clf
hold on
grid on
axis('equal')
patch('Vertices',[x  y ],'Faces',elem(:,1:2),'Facecolor',[1 1 1],'linewidth',0.01,'edgecolor','b','linewidth',1.25)
patch('Vertices',[x1 y1],'Faces',elem(:,1:2),'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','m','linewidth',1.25)
xlabel('x'),ylabel('y')
bc_grph
drawnow

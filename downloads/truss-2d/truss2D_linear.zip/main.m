%*** main ***
% Tested with MATLAB R2026a and MATLAB R2017b.
clear
gen
truss2d
grafic2d
stress2d

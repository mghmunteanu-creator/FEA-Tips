%*** truss2d ***
nnd=length(x(:,1));     % number of nodes
nel=length(elem(:,1));  % number of truss elements
neq=2*nnd;              % number of equatons
% Overal stiffness matrix initialization:
K=zeros(neq);
% Nodal load initialization:
F=zeros(neq,1);         	
 
for ie=1:nel
    % Truss nodes:
	n1=elem(ie,1); n2=elem(ie,2);
    % Young modulus, cross-section area:
	E =elem(ie,3); A =elem(ie,4); 
    
	dx=x(n2)-x(n1); dy=y(n2)-y(n1);
    % Truss length:
	L =sqrt(dx*dx+dy*dy); LL(ie)=L;
    % cos and sin of theta
	cs=dx/L; sn=dy/L;
    % Line =matrix B*L
    line=[-cs -sn  cs  sn];
    % Element stiffness matrix:
	kel=E*A/L*line'*line;
    % DOFs of the current truss element
	ip=[2*n1-1  2*n1  2*n2-1  2*n2];
    % Assemblimg process of the global stiffness matrix K:
	K(ip,ip)=K(ip,ip)+ kel;       	                                      
end

% Forming of the F vector (load):
loc=2*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)+forze(:,3);

% Applying of constraints (fixed DOFs):
loc=2*(cond(:,1)-1)+cond(:,2);
K(loc,:)=0; K(:,loc)=0;
K(loc,loc)=eye(length(loc)); 
F(loc,:  )=0;                    

% Solve linear system
S=K\F;                  % S - nodal displacements of the truss structure
% graphical representation of boundary condition (load & constraints)

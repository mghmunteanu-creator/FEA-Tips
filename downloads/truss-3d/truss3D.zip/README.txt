FEA Tips - Section 2.1
Large Displacements of 3D Truss Structures

Run main.m to solve the five-step nonlinear example.

Files
-----
main.m           Newton-Raphson load-step solution
gen.m            Geometry, connectivity, supports, and loads
stiff.m          Residual vector and consistent tangent assembly
deriv.m          Exact strain gradient and exact strain Hessian
strain_stress.m  Element strain and stress recovery
bc_grph.m        Boundary-condition and load graphics
prnt_reslts.m    Results listing for a selected load step

Verification
------------
Tested in MATLAB R2026a and MATLAB R2017b.
The revised deriv.m retains the exact engineering-strain Hessian.

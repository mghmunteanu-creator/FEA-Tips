%*** bc_grph ***
% Draw applied loads and support symbols on the deformed configuration.
dd=mean(LL)/2;
for i=1:length(forze(:,1))
    nd =forze(i,1); dir=forze(i,2); f=forze(i,3); f=f/abs(f);
    if dir==1
        quiver3(x(nd)+S(3*nd-2),y(nd)+S(3*nd-1),z(nd)+S(3*nd),dd*f,0,0,'r','linewidth',1.5)
    elseif dir==2
        quiver3(x(nd)+S(3*nd-2),y(nd)+S(3*nd-1),z(nd)+S(3*nd),0,dd*f,0,'r','linewidth',1.5)
    elseif dir==3
        quiver3(x(nd)+S(3*nd-2),y(nd)+S(3*nd-1),z(nd)+S(3*nd),0,0,dd*f,'r','linewidth',1.5)
    end
end
for i=1:length(cond(:,1))
    nd=cond(i,1); dir=cond(i,2);
    xt=x(nd); yt=y(nd); zt=z(nd);
    if dir==1
        fill([xt xt-dd/1.5 xt-dd/1.5],[yt yt+dd/3 yt-dd/3],'g')
    elseif dir==2
        fill([xt xt-dd/3 xt+dd/3],[yt yt-dd/1.5 yt-dd/1.5],'g')
    elseif dir==3
        fill3([xt xt-dd/3 xt+dd/3],[yt yt yt],[zt zt-dd/1.5 zt-dd/1.5],'g')
    end
end

%*** deriv ***
% Exact engineering strain and its first two displacement derivatives.
ep=Lf/L-1;

q=[dx+du; dy+dv; dz+dw];
a=[-q; q];
G=[ eye(3) -eye(3)
   -eye(3)  eye(3)];

% Gradient and exact Hessian of the engineering strain.
ep1=a/(L*Lf);
ep2=G/(L*Lf)-(a*a')/(L*Lf^3);
    

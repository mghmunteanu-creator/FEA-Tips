%*** gen ***
%==========================================================================
% x, y, z  vectors contain the nodal coordinates
%
% elem  table contains: 
%     element nodes, Young modulus of the material, cross-section area
%       [node1  node2  E1  A1
%       [node1  node2  E2  A2
%        :      :      :   :  ]
%
% cond  table contains nodal constraints
%       (dir=1 - x direction, dir=2 - y direction, dir=3 - z direction)
%       [node1  dir1
%        node2  dir2
%        :      :   ]
%
% forze table contains nodal loads
%       [node1  dir1  force1
%        node2  dir2  force2
%        :      :     :     ]
%==========================================================================
Fx= 450000;
Fy= 200000;
Fz=-200000;
d=200;                                   % dimension of a module
xy0=[  0     0     0                     % nodes of one module
       d     0     0
       d     d     0
       0     d     0];
   
%      n1    n2      E       A  
elem0=[1     5  2.0000e+05  100         % truss elements of the module
       2     5  2.0000e+05  100
       2     6  2.0000e+05  100
       2     7  2.0000e+05  100
       3     7  2.0000e+05  100
       4     5  2.0000e+05  100
       4     7  2.0000e+05  100 
       4     8  2.0000e+05  100
       5     6  2.0000e+05  100
       5     7  2.0000e+05  100
       5     8  2.0000e+05  100
       6     7  2.0000e+05  100
       7     8  2.0000e+05  100];
nm=18;                                   % number of modules       
 
nnd=4*(nm+1);
nel=13*nm;
neq=3*nnd;
xy=xy0;
for im=1:nm
    xy=[xy
        xy0+im*[zeros(4,1) zeros(4,1) d*ones(4,1)]];
end 
x=xy(:,1); y=xy(:,2); z=xy(:,3);

elem=[];
for im=1:nm
    elem=[elem
          elem0+(im-1)*[4*ones(13,1) 4*ones(13,1) zeros(13,1) zeros(13,1)]];
end 


cond=[1     1  
      1     2 
      1     3
      2     1  
      2     2 
      2     3
      3     1  
      3     2 
      3     3
      4     1  
      4     2 
      4     3];
nnm=(nnd-4)/2;
forze=[nnd-3   2   Fy/4
       nnd-2   2   Fy/4
       nnd-1   2   Fy/4
       nnd     2   Fy/4
       nnd-3   3   Fz/4
       nnd-2   3   Fz/4
       nnd-1   3   Fz/4
       nnd     3   Fz/4
       nnm-3   1   Fx/4
       nnm-2   1   Fx/4  
       nnm-1   1   Fx/4
       nnm     1   Fx/4  ];
   
figure(5)
clf
hold on
grid on
axis('equal')
patch('Vertices',[x y z],'Faces',elem(:,1:2),'Facecolor',[1 1 1], ...
      'edgecolor','b','linewidth',1.25)
xlabel('x'),ylabel('y'),zlabel('z')
view(3)

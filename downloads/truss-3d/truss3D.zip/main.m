%*** main ***
clear
gen
% Increment the full load in equal steps and restore equilibrium at each step.
nstep=5;        % number of load steps
itermax=100;    % max number of iterations
tol=1e-5;       % tolerance
figure(5), clf, hold on, grid on, axis('equal'), view([-73,6])
patch('Vertices',[x y z],'Faces',elem(:,1:2),'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b')
xlabel('x'); ylabel('y'); zlabel('z');
S=zeros(neq,1); % Nodal displacements of the truss structure
St=zeros(neq,nstep+1);
straint=zeros(nel,nstep+1); % strains in trusses
stresst=zeros(nel,nstep+1); % stresses in trusses
LL=zeros(nel,1);            % initial element lengths
for istep=1:nstep
    iter=0;
    err=1;
    while err > tol && iter<itermax
        iter=iter+1;
        stiff              % assemble tangent stiffness and residual
        % Newton-Raphson method:
        dS=-K\F;            % dS - displacement increment
        S=S+dS;             %  S - nodal displacements of the truss structure
        err=sqrt(dS'*dS/neq);
    end
    if err > tol
        warning('Load step %d did not converge in %d iterations.',istep,itermax)
    end
    [istep iter err]
    St(:,istep+1)=S;
    % Graphical representation of the deformed truss structure:
    patch('Vertices',[x+S(1:3:neq)  y+S(2:3:neq)  z+S(3:3:neq)],'Faces',elem(:,1:2),'Facecolor',[1 1 1],'linewidth',0.5,'edgecolor','k')
    pause(0.1)
    % Graphical representation of boundary condition (load & constraints)
    bc_grph
    strain_stress          % calculate element strains and stresses
end
prnt_reslts                % print results for a selected load step

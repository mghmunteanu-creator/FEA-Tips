%*** stiff ***
% Assemble the global tangent stiffness matrix and residual-force vector.
K=zeros(neq);             
F=zeros(neq,1);   
for ie=1:nel
    n1=elem(ie,1); n2=elem(ie,2); 
    x1=x(n1); y1=y(n1); z1=z(n1); x2=x(n2); y2=y(n2); z2=z(n2);
    dx=x2-x1; dy=y2-y1; dz=z2-z1;
    EA=elem(ie,3)*elem(ie,4);    
    ip=[3*n1-2 3*n1-1  3*n1  3*n2-2  3*n2-1  3*n2];
    uel=S(ip); 
    u1=uel(1); v1=uel(2); w1= uel(3); u2=uel(4); v2=uel(5); w2=uel(6);
    du=u2-u1; dv=v2-v1; dw=w2-w1;
    L =sqrt(dx*dx+dy*dy+dz*dz); LL(ie)=L;
    Lf=sqrt((dx+du)^2+(dy+dv)^2+(dz+dw)^2);
    deriv                         % exact strain, gradient, and Hessian
    % Consistent element internal force and tangent stiffness.
    fel=EA*L*ep*ep1;
    kel=EA*L*(ep*ep2+ep1*ep1');
    K(ip,ip)=K(ip,ip) + kel; 
    F(ip)     =F(ip)      + fel;
end
% Subtract the external nodal load for the current load step.
loc=3*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;
% Enforce zero prescribed displacements.
loc=3*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; 
K(loc,loc)=eye(length(loc)); 
F(loc,:  )=0;  

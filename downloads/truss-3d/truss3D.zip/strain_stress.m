%*** strain_stress ***
% Recover engineering strain and axial stress for every truss element.
for ie=1:nel
    n1=elem(ie,1); n2=elem(ie,2);
    x1=x(n1); y1=y(n1); z1=z(n1); x2=x(n2); y2=y(n2); z2=z(n2);
    dx=x2-x1; dy=y2-y1; dz=z2-z1;
    u1=S(3*n1-2); v1=S(3*n1-1); w1=S(3*n1); 
    u2=S(3*n2-2); v2=S(3*n2-1); w2=S(3*n2);
    du=u2-u1; dv=v2-v1; dw=w2-w1;
    L =sqrt(dx*dx+dy*dy+dz*dz);
    Lf=sqrt((dx+du)^2+(dy+dv)^2+(dz+dw)^2);
    straint(ie,istep+1)=(Lf-L)/L;
    stresst(ie,istep+1)=elem(ie,3)*straint(ie,istep+1);
end  
    

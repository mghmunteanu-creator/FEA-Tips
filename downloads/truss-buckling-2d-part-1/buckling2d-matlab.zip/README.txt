FEA Tips - Chapter 1.2
Buckling analysis of 2D truss structures, Part I

MATLAB compatibility
--------------------
Tested with MATLAB R2026a and MATLAB R2017b.
Designed to remain compatible with MATLAB R2017b and later.

Run
---
Run main.m. The program:
1. generates the example data;
2. solves the small-displacement linear problem;
3. computes the signed axial forces;
4. assembles the geometric stiffness matrix;
5. calculates and plots the first two positive buckling modes.

Sign convention and correction
------------------------------
The program uses N > 0 in tension and N < 0 in compression. Consequently,
the linearized buckling equation is

    K*phi = -lambda*KG*phi

when KG is assembled from the signed forces N.

The revised buckling.m solves the eigenproblem only for the free degrees of
freedom and filters the positive finite eigenvalues. For the supplied example:

    lambda_1 = 940978.7131
    lambda_2 = 6181251.434

These values reproduce the published MATLAB and ANSYS results to the displayed
precision.

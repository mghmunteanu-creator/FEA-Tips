%*** buckling ***
% Linearized buckling analysis of a 2D truss structure.
%
% Sign convention:
%   N > 0 for tension and N < 0 for compression.
% Therefore the critical load factors satisfy
%   K*phi = -lambda*KG*phi,
% where KG is assembled from the signed axial forces N.

% Assemble the geometric stiffness matrix.
KG=zeros(neq);
for ie=1:nel
    n1=elem(ie,1);
    n2=elem(ie,2);
    dx=x(n2)-x(n1);
    dy=y(n2)-y(n1);
    L=hypot(dx,dy);
    cs=dx/L;
    sn=dy/L;

    q=[-sn cs sn -cs]';
    kelG=(N(ie)/L)*(q*q');

    ip=[2*n1-1 2*n1 2*n2-1 2*n2];
    KG(ip,ip)=KG(ip,ip)+kelG;
end

% Solve only for the unconstrained degrees of freedom. This avoids the
% artificial unit diagonal introduced in K when boundary conditions are
% applied and eliminates the corresponding infinite eigenvalues.
fixedDofs=2*(cond(:,1)-1)+cond(:,2);
freeDofs=setdiff((1:neq)',fixedDofs);
Kff=K(freeDofs,freeDofs);
KGff=KG(freeDofs,freeDofs);

[Vfree,lambda]=eig(Kff,-KGff,'vector');
valid=isfinite(lambda) & abs(imag(lambda))<1e-9 & real(lambda)>0;
lambda=real(lambda(valid));
Vfree=real(Vfree(:,valid));
[lambda,order]=sort(lambda);
Vfree=Vfree(:,order);

if isempty(lambda)
    error('No positive finite buckling load factor was found.')
end

% Number of modes to display. Change this value if more modes are required.
neig=min(2,numel(lambda));
scale=max(y)/3;

for ieig=1:neig
    fprintf('Eigenvalue %d: %.10g\n',ieig,lambda(ieig))

    S=zeros(neq,1);
    S(freeDofs)=Vfree(:,ieig);
    S=S/max(abs(S));
    u=S(1:2:neq);
    v=S(2:2:neq);
    x1=x+scale*u;
    y1=y+scale*v;

    figure(9+ieig)
    clf
    hold on
    grid on
    axis equal
    patch('Vertices',[x y],'Faces',elem(:,1:2), ...
        'FaceColor','none','EdgeColor','b','LineWidth',1.25)
    patch('Vertices',[x1 y1],'Faces',elem(:,1:2), ...
        'FaceColor','none','EdgeColor','m','LineWidth',1.25)
    xlabel('x')
    ylabel('y')
    title(sprintf('Buckling mode %d, load factor %.6g',ieig,lambda(ieig)))
    bc_grph
end

%*** gen ***
%==========================================================================
% x, y  are vectors that contain the nodal coordinates
%
% elem  table contains: 
%     element nodes, Young modulus of the material, cross-section area
%       [node1  node2  E1  A1
%       [node1  node2  E2  A2
%        :      :      :   :  ]
%
% cond  table contains nodal constraints
%       (dir=1 - x direction, dir=2 - y direction)
%       [node1  dir1
%        node2  dir2
%        :      :   ]
%
% forze table contains nodal loads
%       [node1  dir1  force1
%        node2  dir2  force2
%        :      :     :     ]
%==========================================================================

xy=[  0     0
    100     0
      0   100
    100   100 
      0   200 
    100   200 
      0   300 
    100   300 
      0   400 
    100   400 
      0   500 
    100   500 ];
  
elem=[1     2  2.0000e+05  100
      1     3  2.0000e+05  100
      1     4  2.0000e+05  100
      2     3  2.0000e+05  100
      2     4  2.0000e+05  100
      3     4  2.0000e+05  100
      3     5  2.0000e+05  100
      3     6  2.0000e+05  100
      4     5  2.0000e+05  100
      4     6  2.0000e+05  100
      5     6  2.0000e+05  100
      5     7  2.0000e+05  100
      5     8  2.0000e+05  100
      6     7  2.0000e+05  100
      6     8  2.0000e+05  100
      7     8  2.0000e+05  100
      7     9  2.0000e+05  100
      7    10  2.0000e+05  100
      8     9  2.0000e+05  100
      8    10  2.0000e+05  100
      9    10  2.0000e+05  100
      9    11  2.0000e+05  100
      9    12  2.0000e+05  100
     10    11  2.0000e+05  100
     10    12  2.0000e+05  100
     11    12  2.0000e+05  100];
x=xy(:,1); y=xy(:,2);

cond=[1     1  
      1     2 
      2     2];

forze=[11   2   -0.5
       12   2   -0.5];
   
figure(5)
clf
hold on
grid on
axis('equal')
patch('Vertices',[x y],'Faces',elem(:,1:2),'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b','linewidth',1.25)
xlabel('x'),ylabel('y')

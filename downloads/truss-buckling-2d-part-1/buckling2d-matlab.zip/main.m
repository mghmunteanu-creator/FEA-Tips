%*** main ***
% Tested with MATLAB R2026a and MATLAB R2017b.
clear
figure(5), clf, hold on, grid on, axis('equal')
gen
patch('Vertices',[x  y],'Faces',elem(:,1:2),'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b')
drawnow
% Solve the small-displacement linear problem:
truss2d
bc_grph
% Compute the axial forces in trusses:
stress2d
% Compute the geometric stiffness matrix Kg and solve the eigenproblem:
buckling

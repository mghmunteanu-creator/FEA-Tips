%*** stress2d ***
disp('Elem nod1  node2   Effort      Stress')
u=S(1:2:neq);
v=S(2:2:neq);
for ie=1:nel
	n1=elem(ie,1); n2=elem(ie,2);  
	E =elem(ie,3); A =elem(ie,4);    
	dx=x(n2)-x(n1); dy=y(n2)-y(n1);
	L =sqrt(dx*dx+dy*dy); 
	cs=dx/L; sn=dy/L;
    delta=(u(n2)-u(n1))*cs+(v(n2)-v(n1))*sn;
    N(ie)=E*A*delta/L;		         
	sigma=N(ie)/A; 
    disp(num2str([ie n1 n2 N(ie) sigma],'%-5.0f %-5.0f %-5.0f %-12.5g %-12.5g\n'))
end

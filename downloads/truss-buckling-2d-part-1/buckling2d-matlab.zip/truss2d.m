%*** truss2d ***
nnd=length(x(:,1));	 
nel=length(elem(:,1));
neq=2*nnd;
% Elastic stiffness matrix:
K=zeros(neq);
% Load vector:
F=zeros(neq,1);         	
for ie=1:nel
	n1=elem(ie,1); n2=elem(ie,2); 
	E =elem(ie,3); A =elem(ie,4);    
	dx=x(n2)-x(n1); dy=y(n2)-y(n1);
	L =sqrt(dx*dx+dy*dy); LL(ie)=L;
	cs=dx/L; sn=dy/L; 
    line=[-cs -sn  cs  sn];
    % Element stiffness matrix
	kel=E*A/L*line'*line;
    % Assemblimg process
	ip=[2*n1-1  2*n1  2*n2-1  2*n2];
	K(ip,ip)=K(ip,ip)+ kel;       	                                      
end

% Load
loc=2*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)+forze(:,3);

% Constraints
loc=2*(cond(:,1)-1)+cond(:,2);
K(loc,:)=0; K(:,loc)=0;
K(loc,loc)=eye(length(loc)); 
F(loc,:  )=0;                    

% Solve linear system
S=K\F;					   

FEA Tips - Section 2.2
Buckling Analysis of 3D Truss Structures

Run main.m to solve the reference linear problem and calculate the first four
linearized buckling load factors and mode shapes.

Files
-----
main.m       Analysis sequence and output
gen.m        Geometry, connectivity, supports, and reference loads
truss3d.m    Elastic stiffness assembly and linear solution
stress3d.m   Signed axial-force and stress recovery
buckling.m   Geometric stiffness assembly and buckling eigenproblem
bc_grph.m    Boundary-condition and load graphics

Sign convention
---------------
Axial force N is positive in tension and negative in compression. The
generalized eigenproblem is therefore

    K*phi = -lambda*KG*phi

and the smallest positive lambda is the first buckling load factor.

Verification
------------
Tested in MATLAB R2026a and MATLAB R2017b.


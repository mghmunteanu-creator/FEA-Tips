%*** bc_grph ***
% Draw reference-load arrows and mark restrained nodes.

dd = mean(LL)/2;

for i = 1:size(forze,1)
    node = forze(i,1);
    direction = forze(i,2);
    arrow = zeros(1,3);
    arrow(direction) = sign(forze(i,3))*dd;
    startPoint = [x(node) y(node) z(node)] - arrow;
    quiver3(startPoint(1),startPoint(2),startPoint(3), ...
        arrow(1),arrow(2),arrow(3),0,'r','LineWidth',1.5, ...
        'MaxHeadSize',0.7)
end

restrainedNodes = unique(cond(:,1));
scatter3(x(restrainedNodes),y(restrainedNodes),z(restrainedNodes), ...
    30,'g','filled')

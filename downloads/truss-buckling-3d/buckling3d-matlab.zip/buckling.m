%*** buckling ***
% Assemble the geometric stiffness matrix and solve the linearized
% buckling eigenproblem. Compression is negative, so the equation is
%
%     K*phi = -lambda*KG*phi.

KG = zeros(neq);

for ie = 1:nel
    n1 = elem(ie,1);
    n2 = elem(ie,2);

    dx = x(n2)-x(n1);
    dy = y(n2)-y(n1);
    dz = z(n2)-z(n1);
    L = sqrt(dx*dx + dy*dy + dz*dz);
    direction = [dx;dy;dz]/L;

    % P projects transverse to the element axis.
    P = eye(3) - direction*direction';
    kelG = (N(ie)/L)*[P -P;-P P];

    ip = [3*n1-2 3*n1-1 3*n1 3*n2-2 3*n2-1 3*n2];
    KG(ip,ip) = KG(ip,ip) + kelG;
end

% Remove restrained degrees of freedom before solving. This avoids the
% artificial infinite eigenvalues produced by zero rows in KG.
Kff = K(freeDofs,freeDofs);
KGff = KG(freeDofs,freeDofs);
[Vfree,D] = eig(Kff,-KGff);
lambdaAll = diag(D);

% Retain finite, real, positive load factors only.
realEnough = abs(imag(lambdaAll)) <= 1e-8*max(1,abs(real(lambdaAll)));
valid = isfinite(lambdaAll) & realEnough & real(lambdaAll) > 0;
lambdaAll = real(lambdaAll(valid));
Vfree = real(Vfree(:,valid));
[lambda,order] = sort(lambdaAll);
Vfree = Vfree(:,order);

neig = min(neig,length(lambda));
lambda = lambda(1:neig);
Vfree = Vfree(:,1:neig);
V = zeros(neq,neig);
V(freeDofs,:) = Vfree;

if plot_results
    for ieig = 1:neig
        mode = V(:,ieig);
        ux = mode(1:3:neq);
        uy = mode(2:3:neq);
        uz = mode(3:3:neq);

        figure(10+ieig)
        clf
        hold on
        grid on
        axis equal
        patch('Vertices',[x y z],'Faces',elem(:,1:2), ...
            'FaceColor','none','EdgeColor','b','LineWidth',1.25)
        patch('Vertices',[x+mode_scale*ux y+mode_scale*uy z+mode_scale*uz], ...
            'Faces',elem(:,1:2),'FaceColor','none', ...
            'EdgeColor','m','LineWidth',1.25)
        xlabel('x')
        ylabel('y')
        zlabel('z')
        title(sprintf('Mode %d, load factor %.6g',ieig,lambda(ieig)))
        bc_grph
        view(3)
    end
end


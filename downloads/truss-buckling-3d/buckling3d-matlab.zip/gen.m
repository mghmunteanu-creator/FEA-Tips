%*** gen ***
% Geometry, connectivity, supports, and reference loads.
%
% x, y, z contain the nodal coordinates.
% elem contains [node1 node2 Young_modulus cross_section_area].
% cond contains [node direction], where direction is 1=x, 2=y, or 3=z.
% forze contains [node direction force].

d = 200;                 % module dimension
nm = 18;                 % number of modules
E = 2.0e5;               % Young's modulus
A = 100;                 % cross-sectional area

xyz0 = [0 0 0;           % four nodes in the first transverse plane
        d 0 0;
        d d 0;
        0 d 0];

elem0 = [1 5 E A;        % 13 truss elements in one module
         2 5 E A;
         2 6 E A;
         2 7 E A;
         3 7 E A;
         4 5 E A;
         4 7 E A;
         4 8 E A;
         5 6 E A;
         5 7 E A;
         5 8 E A;
         6 7 E A;
         7 8 E A];

nnd = 4*(nm+1);
nel = 13*nm;

xyz = zeros(nnd,3);
for im = 0:nm
    rows = 4*im + (1:4);
    xyz(rows,:) = xyz0 + repmat([0 0 im*d],4,1);
end
x = xyz(:,1);
y = xyz(:,2);
z = xyz(:,3);

elem = zeros(nel,4);
for im = 1:nm
    rows = 13*(im-1) + (1:13);
    elem(rows,:) = elem0 + (im-1)*[4 4 0 0];
end

% All three translations are restrained at the four base nodes.
cond = [1 1; 1 2; 1 3;
        2 1; 2 2; 2 3;
        3 1; 3 2; 3 3;
        4 1; 4 2; 4 3];

% A unit downward reference load is shared by the four top nodes.
forze = [nnd-3 3 -0.25;
         nnd-2 3 -0.25;
         nnd-1 3 -0.25;
         nnd   3 -0.25];

neig = 4;                 % number of positive buckling factors to report
mode_scale = 500;         % graphical mode-shape scale
plot_results = true;      % set false for a non-graphical run

if plot_results
    figure(5)
    clf
    hold on
    grid on
    axis equal
    patch('Vertices',[x y z],'Faces',elem(:,1:2), ...
        'FaceColor','none','EdgeColor','b','LineWidth',1.25)
    xlabel('x')
    ylabel('y')
    zlabel('z')
    view(3)
end


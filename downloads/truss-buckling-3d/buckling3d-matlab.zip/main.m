%*** main ***
% Linearized buckling analysis of the 3D truss example in Section 2.2.
clear
close all

gen

% Solve the small-displacement reference problem.
truss3d

% Recover the signed axial forces used to form the geometric stiffness.
stress3d

% Assemble KG and solve K*phi = -lambda*KG*phi.
buckling

fprintf('\nFirst %d positive buckling load factors:\n',neig)
for i = 1:neig
    fprintf('  %d  %.10g\n',i,lambda(i))
end


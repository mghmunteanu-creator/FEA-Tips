%*** stress3d ***
% Recover signed axial forces and stresses in the reference configuration.
% The sign convention is N > 0 in tension and N < 0 in compression.

u = S(1:3:neq);
v = S(2:3:neq);
w = S(3:3:neq);
N = zeros(nel,1);
axialStress = zeros(nel,1);

for ie = 1:nel
    n1 = elem(ie,1);
    n2 = elem(ie,2);
    E = elem(ie,3);
    A = elem(ie,4);

    dx = x(n2)-x(n1);
    dy = y(n2)-y(n1);
    dz = z(n2)-z(n1);
    L = sqrt(dx*dx + dy*dy + dz*dz);
    l = dx/L;
    m = dy/L;
    n = dz/L;

    axialExtension = l*(u(n2)-u(n1)) ...
                   + m*(v(n2)-v(n1)) ...
                   + n*(w(n2)-w(n1));
    N(ie) = (E*A/L)*axialExtension;
    axialStress(ie) = N(ie)/A;
end


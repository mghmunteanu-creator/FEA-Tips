%*** truss3d ***
% Assemble the elastic stiffness matrix and solve the reference-load case.

nnd = length(x);
nel = size(elem,1);
neq = 3*nnd;

K = zeros(neq);
F = zeros(neq,1);
LL = zeros(nel,1);

for ie = 1:nel
    n1 = elem(ie,1);
    n2 = elem(ie,2);
    E = elem(ie,3);
    A = elem(ie,4);

    dx = x(n2)-x(n1);
    dy = y(n2)-y(n1);
    dz = z(n2)-z(n1);
    L = sqrt(dx*dx + dy*dy + dz*dz);
    LL(ie) = L;

    l = dx/L;
    m = dy/L;
    n = dz/L;
    b = [-l -m -n l m n];

    % Elastic stiffness of one spatial truss element.
    kel = (E*A/L)*(b'*b);
    ip = [3*n1-2 3*n1-1 3*n1 3*n2-2 3*n2-1 3*n2];
    K(ip,ip) = K(ip,ip) + kel;
end

% Assemble the reference load vector.
loadDofs = 3*(forze(:,1)-1) + forze(:,2);
for i = 1:size(forze,1)
    F(loadDofs(i)) = F(loadDofs(i)) + forze(i,3);
end

% Solve only for unconstrained degrees of freedom. K remains unmodified and
% can therefore be reused directly in the buckling eigenproblem.
fixedDofs = unique(3*(cond(:,1)-1) + cond(:,2));
freeDofs = setdiff((1:neq)',fixedDofs);
S = zeros(neq,1);
S(freeDofs) = K(freeDofs,freeDofs)\F(freeDofs);


# Chapter 24 — Updated Lagrangian 3D beam

Run `main.m` from the extracted folder in desktop MATLAB. It calls `gen_ex2.m`
for the Example 2 input data and performs the large-displacement analysis of
a straight, two-node isoparametric Timoshenko beam.

- `main.m`: load steps, Newton iterations and displacement output.
- `gen_ex2.m`: Example 2 geometry, material, loads, mesh and constraints.
- `stiff.m`: element forces, tangent stiffness and global assembly.
- `deriv.m`: generalized strains and derivatives with simplified curvatures.
- `deriv_corrected.m`: complete curvature expressions with second-order terms
  and their derivatives, described in Addendum 24a.
- `updt.m`: nodal and local-frame updates; calls `princ.m`.
- `princ.m`: current element lengths and passive transformation matrices.
- `gs0.m`: Gram-Schmidt orthonormalization used by `updt.m`.

The analysis uses `deriv.m`. To study Addendum 24a, select `deriv_corrected`
instead of `deriv` in `stiff.m`; do not call both routines there.

Expected environment: desktop MATLAB with base matrix and plotting functions.
This archive has not been tested as a complete run in a specific MATLAB release.

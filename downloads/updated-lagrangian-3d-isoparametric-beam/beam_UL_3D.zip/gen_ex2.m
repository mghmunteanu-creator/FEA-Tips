%*** gen_ex2 ***
Lb=100;         % length of the beam
h=9;            % rectangular cross-section: dimension along y
b=6;            %                            dimension along z 
E=1000;         % Young's modulus
G=E/2.6;        % shear modulus for Poisson's ratio 0.3
A=b*h;
Ay=A*5/6;
Az=Ay;
Iz=b*h^3/12;
Iy=h*b^3/12;
%--------------------------------------------------------------------------
% Interpolate the coefficient for the rectangular-section torsion constant
dM=max([h,b]);
dm=min([h,b]);
hpeb=[1     1.5   2     3     4     6     8     10    100];
beta=[0.141 0.196 0.229 0.263 0.281 0.299 0.307 0.313 0.333];
cbt=interp1(hpeb,beta,dM/dm,'PCHIP');
%--------------------------------------------------------------------------
It=cbt*dM*dm^3;

EA =E*A;
EIy=E*Iy;
EIz=E*Iz;
GIt=G*It;
GAy=G*Ay;
GAz=G*Az;
nel=50;             % number of finite elements
%==========================================================================
nnd=nel+1;            % number of nodes
neq=6*nnd;
% Nodal coordinates:
dx=Lb/nel;
x(1)=0;
for i=1:nel
    x(i+1,1)=i*dx;
end
y=x*0; z=y;
x0=x; y0=y; z0=z;

% Beam element connectivity
elem=[1:nel; 2:nnd]';

% Auxiliary third nodes defining the element principal planes
c=Lb/4;
nd3=zeros(nel,3);
for ie=1:nel
    nd3(ie,:)=[x(ie) c z(ie)];
end
nd30=nd3;
% Nodal constraints
cond=[1    1
      1    2
      1    3
      1    4
      1    5
      1    6];

% Nodal forces and moments: node, degree of freedom, value
forze=[nnd       2         50
       nnd       3         50
       nnd       4      -3500];
%==========================================================================
Rd=zeros(3,3,nel);
Rd(1,1,:)=1;
Rd(2,2,:)=1;
Rd(3,3,:)=1;
% Rotation matrices of all beam elements
princ


function a=gs0(a)	% Gram-Schmidt orthonormalization of the matrix columns
n=length(a(:,1));
for i=1:n
	for j=1:i-1
		a(:,i)=a(:,i)-(a(:,i)'*a(:,j))*a(:,j);
	end
	a(:,i)=a(:,i)/sqrt(a(:,i)'*a(:,i));
end

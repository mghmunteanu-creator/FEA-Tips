%*** main ***
clear
format short e
gen_ex2
itermax=100;	 % maximum Newton iterations per load step
nstep=50;        % number of load steps
tol=1e-6;        % tolerance for sqrt(dS'*dS/nnd)
St=zeros(neq,nstep+1);
strn  =zeros(nel,6,nstep+1);
stress=zeros(nel,6,nstep+1);
figure(5), clf, hold on, grid on, axis('equal'), view(3)
plot3(x,y,z,'k','linewidth',1.5)
for istep=1:nstep
    S=zeros(neq,1);
    error=1;
    iter=0;
    while (error > tol) & (iter < itermax)
        iter=iter+1;
        stiff
        dS=K\F;
        S=S-dS;
        error=sqrt(dS'*dS/nnd);
    end
    updt % update nodal coordinates and element reference frames
    figure(5)
    plot3(x,y,z,'k','linewidth',1.5)
    xlabel('x'), ylabel('y'), zlabel('z') 
    [istep iter error]
    St(:,istep+1)=St(:,istep)+S;
    pause(0.01)
end
stress(:,1,:)=EA *strn(:,1,:); stress(:,2,:)=EIy*strn(:,2,:); stress(:,3,:)=EIz*strn(:,3,:);
stress(:,4,:)=GIt*strn(:,4,:); stress(:,5,:)=GAy*strn(:,5,:); stress(:,6,:)=GAz*strn(:,6,:);

disp('Displacements')
disp('node       u            v            w')
for i=1:nnd
    disp(num2str([i x(i)-x0(i) y(i)-y0(i) z(i)-z0(i)],' %5.0f %12.5g %12.5g %12.5g \n'))
end

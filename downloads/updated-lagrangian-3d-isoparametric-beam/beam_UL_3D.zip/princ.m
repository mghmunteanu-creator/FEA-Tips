%*** princ ***
% Compute current element lengths and passive transformation matrices
Rt=zeros(12,12,nel);
for ie=1:nel
    n1=elem(ie,1);
    n2=elem(ie,2);
    dx=x(n2)-x(n1); dy=y(n2)-y(n1); dz=z(n2)-z(n1);
    L=sqrt(dx*dx+dy*dy+dz*dz);
    Lt(ie)=L;

    x3=nd3(ie,1); y3=nd3(ie,2); z3=nd3(ie,3);
    lmn1(1)=x(n2)-x(n1); lmn1(2)=y(n2)-y(n1); lmn1(3)=z(n2)-z(n1);
    nm=norm(lmn1); lmn1=lmn1/nm;
    
    lmn2(1)=x3-x(n1);  lmn2(2)=y3-y(n1);  lmn2(3)=z3-z(n1);
    nm=norm(lmn2); lmn2=lmn2/nm;
    lmn3=cross(lmn1,lmn2); nm=norm(lmn3); lmn3=lmn3/nm;
    lmn2=cross(lmn3,lmn1);
    
    R0=[lmn1;lmn2;lmn3];
    Rt( 1: 3, 1: 3,ie)=R0;
    Rt( 4: 6, 4: 6,ie)=R0;
    Rt( 7: 9, 7: 9,ie)=R0;    
    Rt(10:12,10:12,ie)=R0; 
end


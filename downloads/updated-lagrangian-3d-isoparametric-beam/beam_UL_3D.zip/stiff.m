%*** stiff ***
F=zeros(neq,1);
K=zeros(neq);
for ie=1:nel
    L=Lt(ie); L2=L^2;
    n1=elem(ie,1);
    n2=elem(ie,2);
    ipos=[6*n1-5 6*n1-4 6*n1-3 6*n1-2 6*n1-1 6*n1... 
          6*n2-5 6*n2-4 6*n2-3 6*n2-2 6*n2-1 6*n2];
    R=Rt(:,:,ie);
    s=R*S(ipos);
    fel=zeros(12,1);
    kel=zeros(12);
    deriv
    % Alternative: replace deriv above with deriv_corrected for Addendum 24a.
    ep =ep +strn(ie,1,istep);
    bey=bey+strn(ie,2,istep);
    bez=bez+strn(ie,3,istep);
    cax=cax+strn(ie,4,istep);
    cay=cay+strn(ie,5,istep);
    caz=caz+strn(ie,6,istep);
    fel=L*(EA*ep*ep1+GAy*bey*bey1+GAz*bez*bez1+GIt*cax*cax1+EIy*cay*cay1+EIz*caz*caz1);
    kel=L*(EA *(ep*ep2  +ep1*ep1'  )+GAy*(bey*bey2+bey1*bey1')+GAz*(bez*bez2+bez1*bez1')+ ...
           GIt*(cax*cax2+cax1*cax1')+EIy*(cay*cay2+cay1*cay1')+EIz*(caz*caz2+caz1*caz1'));
    strn(ie,1:6,istep+1)=[ep bey bez cax cay caz];
    F(ipos)=F(ipos)+R'*fel;
    K(ipos,ipos)=K(ipos,ipos)+R'*kel*R;
end
% Apply displacement constraints
loc=6*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 
% Subtract the applied nodal forces and moments at the current load step
loc=6*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;               

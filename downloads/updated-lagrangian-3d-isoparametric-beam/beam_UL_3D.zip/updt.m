%*** updt ***
% Update nodal coordinates after each converged load step
x=x+S(1:6:neq);
y=y+S(2:6:neq);
z=z+S(3:6:neq);
% Update accumulated transformations and auxiliary third-node coordinates
for ie=1:nel
    fx=S(6*ie-2); fy=S(6*ie-1); fz=S(6*ie); 
    Rc=gs0([1-(fy^2+fz^2)/2     -fz+fx*fy/2      fy+fz*fx/2
                 fz+fx*fy/2 1-(fz^2+fx^2)/2     -fx+fy*fz/2
                -fy+fz*fx/2      fx+fy*fz/2 1-(fx^2+fy^2)/2]);
    Rd(:,:,ie)=Rc'*Rd(:,:,ie);
    nd3(ie,:)=[x(ie) y(ie) z(ie)]+(nd30(ie,:)-[x0(ie) y0(ie) z0(ie)])*Rd(:,:,ie);
end
princ % recompute current element lengths and passive transformation matrices

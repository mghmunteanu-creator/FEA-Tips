# Chapter 24 — Example 2 ANSYS macro

This package contains the ANSYS Mechanical APDL macro for the flexible 3D cantilever in Example 2. It is not a MATLAB program.

Run `macro_ex_2.mac` in ANSYS Mechanical APDL, from the extracted working directory, using `/INPUT,macro_ex_2,mac`. The macro defines and solves the example model.

Units: millimetres (mm), newtons (N), stresses and elastic modulus in MPa (N/mm²), and moments in Nmm. Compare the deformed configuration and displacements with Example 2.

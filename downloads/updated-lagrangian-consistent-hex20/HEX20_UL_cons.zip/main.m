%*** main ***
clear
format short e
nstep=10;            % number of load steps
tol=1e-5;
itermax=50;

gen
St=zeros(neq,nstep+1);
strnt=zeros(27*nel,6,nstep+1);
sigmt=zeros(27*nel,7,nstep+1);
for istep=1:nstep
    S =zeros(neq,1);
    error=1;
    iter=0;
    while (error > tol) & (iter < itermax)
        iter=iter+1;
        stiff_cons20
        dS=K\F;
        S=S-dS;
        error=sqrt(dS'*dS/neq);
        x=x-dS(1:3:neq);
        y=y-dS(2:3:neq);
        z=z-dS(3:3:neq);
    end
    grafic3d0
    [istep iter error]
    St(:,istep+1)=St(:,istep)+S;
end
% Compute Von Mises stress:
sgech=sqrt(sigmt(:,1,:).^2+sigmt(:,2,:).^2+sigmt(:,3,:).^2-...
sigmt(:,1,:).*sigmt(:,2,:)-sigmt(:,2,:).*sigmt(:,3,:)-sigmt(:,3,:).*sigmt(:,1,:)+...        
3*sigmt(:,4,:).^2+3*sigmt(:,5,:).^2+3*sigmt(:,6,:).^2);
sigmt(:,7,:)=sgech;

%*** stiff_cons20 ***
E1 =E*(1-nu)/(1+nu)/(1-2*nu);
nu1=nu/(1-nu);
G=E/2/(1+nu);
DHooke=[     E1   nu1*E1       nu1*E1
         nu1*E1       E1       nu1*E1
         nu1*E1   nu1*E1       E1 ];
DHooke(4,4)=G; DHooke(5,5)=G;; DHooke(6,6)=G;
F=zeros(neq,1);
K=zeros(neq);
% Gauss points:
a = sqrt(3/5);
str=a*[-1  -1  -1  -1  -1  -1  -1  -1  -1   0   0   0   0   0   0   0   0   0   1   1   1   1   1   1   1   1   1
       -1  -1  -1   0   0   0   1   1   1  -1  -1  -1   0   0   0   1   1   1  -1  -1  -1   0   0   0   1   1   1
       -1   0   1  -1   0   1  -1   0   1  -1   0   1  -1   0   1  -1   0   1  -1   0   1  -1   0   1  -1   0   1];
ind= [  1   9   2  12   0  10   4  11   3  17   0  18   0   0   0  20   0  19   5  13   6  16   0  14   8  15   7];
 
wg = [1.7147e-01   2.7435e-01   1.7147e-01   2.7435e-01   4.3896e-01   2.7435e-01   1.7147e-01   2.7435e-01   1.7147e-01 ...
      2.7435e-01   4.3896e-01   2.7435e-01   4.3896e-01   7.0233e-01   4.3896e-01   2.7435e-01   4.3896e-01   2.7435e-01 ...
      1.7147e-01   2.7435e-01   1.7147e-01   2.7435e-01   4.3896e-01   2.7435e-01   1.7147e-01   2.7435e-01   1.7147e-01];
ig=0;
for ie=1:nel;
    nodi=elem(ie,1:20);
    % Connectivity matrix
    ip(1:3:60)=3*nodi-2;
    ip(2:3:60)=3*nodi-1;
    ip(3:3:60)=3*nodi;

    % Initial nodal coordinates
    xel0=x0(nodi);
    yel0=y0(nodi);
    zel0=z0(nodi);
    % Current trial nodal coordinates
    xelt=x(nodi);
    yelt=y(nodi);
    zelt=z(nodi);

    fel=zeros(60,1);
    kel=zeros(60);
    for jg=1:27
        ig=ig+1;
        s=str(1,jg);
        t=str(2,jg);
        r=str(3,jg);
        [~,dNds,dNdt,dNdr] = shape20(s,t,r);
        H=[dNds dNdt dNdr]';

        % Spatial derivatives in the current trial configuration
        Jt=H*[xelt yelt zelt];
        detJ=det(Jt);
        J1=inv(Jt);
        b=J1*H;
        % B matrix
        Bux(1:3:60)=b(1,:);Bux(60)=0;
        Buy(1:3:60)=b(2,:);Buy(60)=0;
        Buz(1:3:60)=b(3,:);Buz(60)=0;
        Bvx(2:3:60)=b(1,:);Bvx(60)=0;
        Bvy(2:3:60)=b(2,:);Bvy(60)=0;
        Bvz(2:3:60)=b(3,:);Bvz(60)=0;
        Bwx(3:3:60)=b(1,:);
        Bwy(3:3:60)=b(2,:);
        Bwz(3:3:60)=b(3,:);
        B=[Bux; Bvy; Bwz; Buy+Bvx; Bvz+Bwy; Bwx+Buz];

        % Total Euler-Almansi strains
        J0=H*[xel0 yel0 zel0];
        Ftot=(J0\Jt)';
        Q=inv(Ftot*Ftot');
        e=(eye(3)-Q)/2;
        ex=e(1,1);   ey=e(2,2);   ez=e(3,3);
        exy=2*e(1,2); eyz=2*e(2,3); ezx=2*e(3,1);
        strnt(ig,:,istep+1)=[ex ey ez exy eyz ezx];

        % Hooke law (engineering shear strains)
        sigmt(ig,1:6,istep+1)=[ex ey ez exy eyz ezx]*DHooke;
        sig=sigmt(ig,1:6,istep+1)';
        sigma=[sig(1) sig(4) sig(6)
               sig(4) sig(2) sig(5)
               sig(6) sig(5) sig(3)];

        % Internal forces in the current trial configuration
        fel=fel+wg(jg)*B'*sig*detJ;

        % Consistent material tangent: BQ differs from B by the factor Q
        BQ=zeros(6,60);
        for i=1:20;
            ii=3*i-2:3*i;
            BQ(:,ii)=B(:,ii)*Q;
        end
        km=B'*DHooke*BQ;

        % Consistent geometric tangent: changes of volume and of B
        kg=zeros(60);
        for i=1:20;
            ii=3*i-2:3*i;
            bi=b(:,i);
            sbi=sigma*bi;
            for j=1:20;
                jj=3*j-2:3*j;
                bj=b(:,j);
                kg(ii,jj)=sbi*bj'-(sigma*bj)*bi';
            end
        end
        kel=kel+wg(jg)*(km+kg)*detJ;
    end
    % Assembly
    F(ip)=F(ip)+fel;
    K(ip,ip)=K(ip,ip)+kel;
end
% Constraints
loc=3*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;
K(loc,loc)=eye(length(loc));
% Concentrated force
loc=3*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;

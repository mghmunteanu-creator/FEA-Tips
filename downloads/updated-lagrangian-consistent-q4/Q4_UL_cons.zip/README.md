# FEA Tips — Section 15.5

Updated Lagrangian Revisited: A Direct and Consistent Tangent Stiffness Matrix for the Q4 Element

This section was developed with the contribution of Chiara.

## Use
Extract all five MATLAB files into one folder. Run main.m for the cantilever example. The supplied default is nstep=4. gen.m defines the mesh, material, constraints and loads. stiff_cons.m evaluates total Euler–Almansi strains and the material, geometric and thickness tangent terms. plot_disp.m and plot_stress.m provide post-processing.

The constitutive and thickness laws are approximate. The tangent is consistent with the implemented internal-force vector; it need not be symmetric. Do not symmetrize it.

## Verification and compatibility
The supplied stiff_cons.m was executed in MATLAB R2026a Update 4 (26.1.0.3312084) on three single-element states: undeformed, rigidly rotated and nonuniformly deformed. The relative error against central finite differences was below 1.3e-10; rigid rotation gave zero strain to roundoff. These tests do not constitute a rerun of the full cantilever benchmark or the plotting scripts.

MATLAB R2024a is expected to support the inspected syntax, but was not tested for this package. The supplied executable MATLAB statements are unchanged.

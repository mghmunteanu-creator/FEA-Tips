%*** stiff_cons ***
% Developed with assistance from Chiara (ChatGPT).

E1=E/(1-nu*nu);  
E2=nu*E1;
G=E/2/(1+nu);
DHooke=[E1 E2 0
        E2 E1 0
         0  0 G];
F=zeros(neq,1);
K=zeros(neq);
% Gauss points
st=[1  -1  -1   1
    1   1  -1  -1]*sqrt(3)/3;
ig=0;
for ie=1:nel
    nodi=elem(ie,1:4);
    ip=[2*nodi-1; 2*nodi]; ip=ip(:)';
    sel=S(ip);

    % Initial nodal coordinates
    xel0=x0(nodi);        yel0=y0(nodi);
    % Current trial nodal coordinates
    xelt=x(nodi);         yelt=y(nodi);
    fel=zeros(8,1);
    kel=zeros(8);
    for j=1:4
        ig=ig+1;
        s=st(1,j);
        t=st(2,j);
        H=[(1+t)/4  -(1+t)/4  -(1-t)/4  (1-t)/4
           (1+s)/4   (1-s)/4  -(1-s)/4 -(1+s)/4]; 
        % B matrix
        Jt=H*[xelt yelt];
        detJ=abs(det(Jt));
        J1=inv(Jt);
        b=J1*H;
        B=[b(1,1)  0       b(1,2)  0       b(1,3)  0       b(1,4)   0 
           0       b(2,1)  0       b(2,2)  0       b(2,3)  0        b(2,4)
           b(2,1)  b(1,1)  b(2,2)  b(1,2)  b(2,3)  b(1,3)  b(2,4)   b(1,4)];

        % Total Euler-Almansi strains
        J0=H*[xel0 yel0];
        Ftot=(J0\Jt)';
        Q=inv(Ftot*Ftot');
        e=(eye(2)-Q)/2;
        ex=e(1,1);   ey=e(2,2);   exy=2*e(1,2); 
        strnt(ig,:,istep+1)=[ex ey exy];

        % Hooke law (engineering shear strains)
        sigmt(ig,1:3,istep+1)=[ex ey exy]*DHooke;
        sig=sigmt(ig,1:3,istep+1)';
        sigma=[sig(1) sig(3) 
               sig(3) sig(2)];
        th1=(1-nu/(1-nu)*(ex+ey))*th;
        % Internal forces in the current trial configuration
        fel=fel+th1*B'*sig*detJ;

        % Consistent spatial internal forces and tangent (2 x 2 blocks)        % Consistent material tangent: BQ differs from B by the factor Q
        BQ=zeros(3,8);
        for i=1:4;
            ii=2*i-1:2*i;
            BQ(:,ii)=B(:,ii)*Q;
        end
        km=B'*DHooke*BQ;

        % Consistent geometric tangent: changes of volume and of B
        kg=zeros(8);
        for i=1:4;
            ii=2*i-1:2*i;
            bi=b(:,i);
            sbi=sigma*bi;
            for j=1:4;
                jj=2*j-1:2*j;
                bj=b(:,j);
                kg(ii,jj)=sbi*bj'-(sigma*bj)*bi';
            end
        end
        dth=-th*nu/(1-nu)*(BQ(1,:)+BQ(2,:));
        kel=kel+detJ*(th1*(km+kg)      +(B'*sig)*dth);
    end
    % Assembly
    F(ip)=F(ip)+fel;
    K(ip,ip)=K(ip,ip)+kel;
end

% Constraints
loc=2*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 
% Concentrated force
loc=2*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep; 

%*** stiff_cons8 ***
E1=E/(1-nu*nu);  
E2=nu*E1;
G=E/2/(1+nu);
DHooke=[E1 E2 0
        E2 E1 0
         0  0 G];
F=zeros(neq,1);
K=zeros(neq);

% Gauss points, 3rd order
xgs=[-1   -1   -1    0    0    0    1    1    1]*sqrt(0.6);
xgt=[-1    0    1   -1    0    1   -1    0    1]*sqrt(0.6);

wgs=[ 5    5    5    8    8    8    5    5    5]/9;
wgt=[ 5    8    5    5    8    5    5    8    5]/9;

ig=0;
for ie=1:nel
    nodi=elem(ie,:);
    ip=[2*nodi-1; 2*nodi]; ip=ip(:)';
    sel=S(ip);
    %----------------------------------------------------------------------
    % Initial nodal coordinates
    xel0=x0(nodi);        yel0=y0(nodi);
    % Current trial nodal coordinates
    xelt=x(nodi);         yelt=y(nodi);
    fel=zeros(16,1);
    kel=zeros(16);
    for j=1:9
        ig=ig+1;
        s=xgs(j);
        t=xgt(j);
        % H matrix
        dps0=[(1+t)/4  -(1+t)/4  -(1-t)/4  (1-t)/4     0     0     0     0];    
        dpt0=[(1+s)/4   (1-s)/4  -(1-s)/4 -(1+s)/4     0     0     0     0]; 	

        dps1=[   0    0    0    0    -s*(1+t)   -(1-t^2)/2  -s*(1-t)     (1-t^2)/2 ]; 	
        dpt1=[   0    0    0    0    (1-s^2)/2  -t*(1-s)    -(1-s^2)/2  -t*(1+s)   ]; 	

        dps2=[ (1-t^2)/2  -s*(1+t)    -(1-t^2)/2  -s*(1-t)      0      0     0     0]/2; 	
        dpt2=[-t*(1+s)     (1-s^2)/2  -t*(1-s)    -(1-s^2)/2    0      0     0     0]/2; 

        dps3=[-s*(1+t)    -(1-t^2)/2  -s*(1-t)     (1-t^2)/2    0      0     0     0]/2; 	
        dpt3=[ (1-s^2)/2  -t*(1-s)    -(1-s^2)/2  -t*(1+s)      0      0     0     0]/2; 	

        dps=dps0+dps1-dps2-dps3;
        dpt=dpt0+dpt1-dpt2-dpt3;

        H=[dps
           dpt];

        % B matrix
        Jt=H*[xelt yelt];
        detJ=det(Jt);
        J1=inv(Jt);
        b=J1*H;
        Bux=[b(1,1:8)
            zeros(1,8)]; Bux=Bux(:)';
        Buy=[b(2,1:8)
            zeros(1,8)];  Buy=Buy(:)';
        Bvx=[zeros(1,8)
            b(1,1:8)];  Bvx=Bvx(:)';
        Bvy=[zeros(1,8)
            b(2,1:8)];  Bvy=Bvy(:)';
        B=[Bux
           Bvy
           Buy+Bvx];

        % Total Euler-Almansi strains
        J0=H*[xel0 yel0];
        Ftot=(J0\Jt)';
        Q=inv(Ftot*Ftot');
        e=(eye(2)-Q)/2;
        ex=e(1,1);   ey=e(2,2);   exy=2*e(1,2); 
        strnt(ig,:,istep+1)=[ex ey exy];

        % Hooke law (engineering shear strains)
        sigmt(ig,1:3,istep+1)=[ex ey exy]*DHooke;
        sig=sigmt(ig,1:3,istep+1)';
        sigma=[sig(1) sig(3) 
               sig(3) sig(2)];
        th1=(1-nu/(1-nu)*(ex+ey))*th;
        % Internal forces in the current trial configuration
        fel=fel+wgs(j)*wgt(j)*th1*B'*sig*detJ;

        % Consistent spatial internal forces and tangent (2 x 2 blocks)        % Consistent material tangent: BQ differs from B by the factor Q
        BQ=zeros(3,16);
        for i=1:8;
            ii=2*i-1:2*i;
            BQ(:,ii)=B(:,ii)*Q;
        end
        km=B'*DHooke*BQ;

        % Consistent geometric tangent: changes of volume and of B
        kg=zeros(16);
        for i=1:8;
            ii=2*i-1:2*i;
            bi=b(:,i);
            sbi=sigma*bi;
            for j=1:8;
                jj=2*j-1:2*j;
                bj=b(:,j);
                kg(ii,jj)=sbi*bj'-(sigma*bj)*bi';
            end
        end
        dth=-th*nu/(1-nu)*(BQ(1,:)+BQ(2,:));
        kel=kel+wgs(j)*wgt(j)*detJ*(th1*(km+kg)      +(B'*sig)*dth);
    end
    % Assembly
    F(ip)=F(ip)+fel;
    K(ip,ip)=K(ip,ip)+kel;
end

% Constraints
loc=2*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 
% Concentrated force
loc=2*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep; 

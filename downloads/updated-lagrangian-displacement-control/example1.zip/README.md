# Example 1 — prescribed crank rotation

This package analyzes an initially curved compliant mechanism by the Updated Lagrangian finite element method. Displacement control is applied to the rotation of node 1 through a Lagrange multiplier. The additional unknown is the reaction couple required to impose the prescribed crank rotation increment.

## Files

- `main.m` — analysis loop and reaction-couple curve
- `gen.m` — geometry, material data, constraints, and prescribed rotation increment
- `stiff.m` — element assembly and Lagrange-multiplier constraint
- `deriv.m` — generalized strains and their first and second derivatives
- `updt.m` — geometry and element-frame update after each load step

## Running the example

Place all five MATLAB files in the same folder and run `main`. The example uses 100 load steps. Figure 5 shows the evolving geometry; Figure 10 plots reaction couple versus crank angle.

The variable `Ang=180*pi/180` is the imposed rotation increment. The initial crank angle is 20 degrees, so the final crank angle is 200 degrees.

## Verification

Executed in MATLAB R2026a. All 100 load steps completed. At the final step, the crank angle is 200 degrees and the computed reaction couple is approximately 260.8415 N mm. The final Newton–Raphson iteration required five iterations and reached a convergence measure of approximately `5.01e-7`.

%*** gen ***
%==========================================================================
Lr=70;          % crank length
xq=100;         % Coordinates of 
yq=20;          % the point Q
width=2;        % cross-section
th=0.5;         % dimensions
E=1e5;          % Young modulus
nu=0.279;       % Poisson ratio
G=E/2/(1+nu);   % Shear modulus
Ang=pi; % imposed crank rotation increment
%--------------------------------------------------------------------------
% Geometrical properties of the flexible beam cross-section
A2 =width*th;
A2T=5/6*A2;
I2 =width*th^3/12;
% Geometrical properties of the crank cross-section ("rigid" body)
A1 =A2*100;
A1T=A2T*100;
I1 =I2*200;
%==========================================================================
% nodal coordinates
nel1=10;        % number of finite elements for the crank
nel2=100;       % number of finite elements for the flexible beam
nel=nel1+nel2;
nnd=nel+1;
neq0=3*nnd;
neq=neq0+1;
x3=0; y3=0;
x2=xq; y2=yq;
x1=x2-Lr*cos(pi/9); y1=y2-Lr*sin(pi/9);
for i=1:nel1
    x(i,1)=x1+(x2-x1)/nel1*(i-1);
    y(i,1)=y1+(y2-y1)/nel1*(i-1);
end
dx=x2/nel2;
xc=0;
i1=nnd;
for i=1:nel2+1
    x(i1,1)=xc;
    y(i1,1)=2*xc^2/1e3;
    xc=xc+dx;
    i1=i1-1;
end
x0=x; y0=y;
%==========================================================================
% elements
nel=nnd-1;                      % number of nodes
nd=1:nel;
II=[ones(nel1,1);ones(nel2,1)*2];
un=ones(nel,1);
elem=[nd' nd'+1 II];
%==========================================================================
cm=[E*A1 G*A1T E*I1
    E*A2 G*A2T E*I2];
%==========================================================================
% constraints
cond=[   1 1
         1 2
       nnd 1
       nnd 2
       nnd 3];
%==========================================================================
% load
forze=[1 3 0];
%==========================================================================
Rt=zeros(6,6,nel);
for ie=1:nel
    n1=ie;
    n2=ie+1;
    dx=x(n2)-x(n1);
    dy=y(n2)-y(n1);
    L=sqrt(dx*dx+dy*dy);
    cs=dx/L;            
    sn=dy/L;
    Lt(ie)=L;    
    Rt(:,:,ie)=[ cs sn  0   0   0  0           
                -sn cs  0   0   0  0  
                  0  0  1   0   0  0  
                  0  0  0  cs  sn  0  
                  0  0  0 -sn  cs  0  
                  0  0  0   0   0  1];
end

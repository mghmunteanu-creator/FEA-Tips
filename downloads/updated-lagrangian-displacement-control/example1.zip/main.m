%*** main ***
clear
format short e
gen
tol=1e-5;         % tolerance
itermax=100;	  % maximum iteration loops
nstep=100;        % number of load steps
St=zeros(neq,nstep+1);
strn  =zeros(nel,3,nstep+1);
stress=zeros(nel,3,nstep+1);
MM=zeros(nstep+1,2);
for istep=1:nstep
    S=zeros(neq,1);
    error=1;
    iter=0;
    while (error > tol) & (iter < itermax)
        iter=iter+1;
        stiff
        dS=K\F;
        S=S-dS;
        error=sqrt(dS'*dS/nnd);
    end
    updt
    figure(5), clf, hold on, grid on, axis('equal')
    plot(x,y,'r','linewidth',2)
    plot(x0,y0,':b','linewidth',1.5)
    drawnow
    [istep iter error] 
    St(:,istep+1)=St(:,istep)+S;
    pause(0.01)
    MM(istep+1,1)=St(3,istep+1)*180/pi;
    MM(istep+1,2)=S(neq);
end
stress(:,1,:)=EA*strn(:,1,:);
stress(:,2,:)=EI*strn(:,2,:);
stress(:,3,:)=GA*strn(:,3,:);

figure(10), clf, hold on, grid on
plot(MM(:,1)+20,MM(:,2),'linewidth',2)
drawnow
xlabel('Crank angle [^o]')
ylabel('Couple [Nmm]')


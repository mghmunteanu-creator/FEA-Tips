# Example 2 — prescribed horizontal displacement

This package analyzes a fully compliant inverter by the Updated Lagrangian finite element method. Displacement control is applied to the horizontal displacement of node 2 through a Lagrange multiplier. The additional unknown is the horizontal reaction force required to impose the prescribed displacement.

## Files

- `main.m` — analysis loop and force–displacement curve
- `gen.m` — geometry, material data, constraints, and prescribed displacement
- `stiff.m` — element assembly and Lagrange-multiplier constraint
- `deriv.m` — generalized strains and their first and second derivatives
- `updt.m` — geometry and element-frame update after each load step

## Running the example

Place all five MATLAB files in the same folder and run `main`. The example uses 100 load steps. Figure 5 shows the evolving mechanism; Figure 10 plots the horizontal reaction force versus the prescribed horizontal displacement.

The program sets `disp=-0.4` and `dof=4`, which impose the horizontal displacement degree of freedom of node 2.

## Verification

Executed in MATLAB R2026a. All 100 load steps completed. At the final step, the prescribed displacement is -0.4 mm and the computed horizontal reaction is approximately -0.121713 N. The final Newton–Raphson iteration required three iterations and reached a convergence measure of approximately `1.96e-8`.

%*** gen ***
clear
%==========================================================================
width=0.05;         % width of the cross-section
th=0.05;            % thickness of the cross-section
E=2.3e3;            % Young modulus
G=E/2.6;            % Shear modulus
% cross-section properties:
I=width*th^3/12;
A=width*th;
EA=E*A;
GA=G*5/6*A;
EI=E*I;
% displacement imposed on node #2:
disp=-0.4;
%==========================================================================
xy= [0    1
     0    0.5
     0    0
     0.5  1
     0.5  0.75
     0.5  0.25
     0.5  0
     1    0.75
     1    0.5
     1    0.25];
nk0=12;
nk=nk0+2;
elem0=zeros(12,nk);
elem0(:,[1,nk])=[1  4
                 1  5
                 2  5
                 2  6
                 3  6
                 3  7
                 4  5
                 4  8
                 6  7
                 7 10
                 8  9
                 9 10];
n0=10;
for i=1:12
    n1=elem0(i,1); n2=elem0(i,nk);
    for j=2:nk-1
        n0=n0+1;
        xy(n0,1)=xy(n1,1)+(xy(n2,1)-xy(n1,1))*(j-1)/(nk0+1);
        xy(n0,2)=xy(n1,2)+(xy(n2,2)-xy(n1,2))*(j-1)/(nk0+1);            
        elem0(i,j)=n0;
    end
end

elem=[];
for i=1:12
    for j=1:nk-1
        elem=[elem
              elem0(i,j) elem0(i,j+1)];
    end
end
x=xy(:,1); y=xy(:,2);
x0=x;
y0=y;
%==========================================================================
% constraints
cond=[ 1 1
       1 2
       1 3
       3 1
       3 2
       3 3];
%==========================================================================
% load
forze=[2 1 0];
%==========================================================================
nnd=length(x);
nel=length(elem);
neq0=3*nnd;
neq=neq0+1;
Rt=zeros(6,6,nel);
for ie=1:nel
    n1=elem(ie,1);
    n2=elem(ie,2);
    dx=x(n2)-x(n1);
    dy=y(n2)-y(n1);
    L=sqrt(dx*dx+dy*dy);
    cs=dx/L;            
    sn=dy/L;
    Lt(ie)=L;    
    Rt(:,:,ie)=[ cs sn  0   0   0  0           
                -sn cs  0   0   0  0  
                  0  0  1   0   0  0  
                  0  0  0  cs  sn  0  
                  0  0  0 -sn  cs  0  
                  0  0  0   0   0  1];
end

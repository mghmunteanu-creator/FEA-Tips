%*** main ***
clear
format short e
gen
nstep=100;          % number of load steps
tol=1e-5;           % tolerance for the iterative process
itermax=100;        % maximum iteration loops
St=zeros(neq,nstep+1);
strn  =zeros(nel,3,nstep+1);
stress=zeros(nel,3,nstep+1);
for istep=1:nstep
    S=zeros(neq,1);
    error=1;
    iter=0;
    while (error > tol) & (iter < itermax)
        iter=iter+1;
        stiff
        dS=K\F;
        S=S-dS;
        error=sqrt(dS'*dS/nnd);
    end
    updt
    figure(5), clf, hold on, grid on, axis('equal')
    patch('Vertices',[x0 y0],'Faces',elem(:,1:2),'Facecolor',[1 1 1],'linestyle',':','linewidth',0.5,'edgecolor','b')
    patch('Vertices',[x y],'Faces',elem(:,1:2),'Facecolor',[1 1 1],'linewidth',2,'edgecolor','b')
    drawnow
    [istep iter error] 
    St(:,istep+1)=St(:,istep)+S;
    frc(istep+1,1)=S(neq);
    pause(0.01)
end
stress(:,1,:)=EA*strn(:,1,:);
stress(:,2,:)=EI*strn(:,2,:);
stress(:,3,:)=GA*strn(:,3,:);
dst=St(dof,:);
figure(10), clf, hold on, grid on
plot(dst,frc,'linewidth',2)
drawnow
xlabel('Displacement [mm]')
ylabel('Force [N]')

# Section 15.4 — Q8 direct Euler–Almansi analysis

Run `main.m` in MATLAB with all five `.m` files in the same folder.
The program analyses the Chapter 15 cantilever using Q8 elements and five load steps.

- `main.m`: load steps and Newton–Raphson iterations.
- `gen.m`: geometry, mesh, material data, constraints and loads.
- `stiff.m`: direct Euler–Almansi strains, internal forces and tangent stiffness.
- `plot_disp.m`: displacement maps.
- `plot_stress.m`: stress maps.

The MATLAB release used for the supplied comparison results is not specified.
`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

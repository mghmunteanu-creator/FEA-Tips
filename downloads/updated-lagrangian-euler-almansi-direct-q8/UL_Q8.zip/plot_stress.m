%*** plot_stress ***
iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - does not plot
istep=input('Load step (Default: nstep): ');
if length(istep)==0; istep=nstep; end
istress=input('Stress (1-sx, 2-sy, 3-txy, 4-VM, Default: 1): ');
if length(istress)==0; istress=1; end
scale=input('Scale factor (Default: 1): ');
if isempty(scale), scale=1; end
load_step=istep
u=St(1:2:neq,istep+1);
v=St(2:2:neq,istep+1);
xc=x0+u*scale;
yc=y0+v*scale;  
%==========================================================================
% Compute the nodal stresses performing the arithmetic average of the 
% stresses for the elements connected in the same node.
in=[3  6  2  7  0  5  4  8  1];
strs=zeros(nnd,2);
ig=0;
for ie=1:nel
    for j=1:9
        ig=ig+1;
        if in(j)~=0
            jj=in(j);
            nod=elem(ie,jj);
            strs(nod,2)=strs(nod,2)+1;
            strs(nod,1)=strs(nod,1)+sigmt(ig,istress,istep+1);
        end
    end
end
stress=strs(:,1)./strs(:,2);
%==========================================================================
% Graphic representation
figure(14+istress)
clf
hold on
axis('equal')
colormap(turbo(16))
smx=max(stress);
smn=min(stress);
if iedge==0
    patch('Vertices',[xc yc],'Faces',elem(:,[1 5 2 6 3 7 4 8]),'CData',stress,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[xc yc],'Faces',elem(:,[1 5 2 6 3 7 4 8]),'CData',stress,'Facecolor','interp','edgecolor','w')
end
colorbar
sigma_max=smx
sigma_min=smn
lighting phong

titlu=' \sigma_x  \sigma_y  \tau_x_y \sigma_V_M';
sss=titlu(10*(istress-1)+1:10*istress);
title({[sss,',   Load step ',num2str(istep)],;['min= ',num2str(smn),'  max=',num2str(smx)]})
xlabel('x')
ylabel('y')
zlabel('z')
drawnow

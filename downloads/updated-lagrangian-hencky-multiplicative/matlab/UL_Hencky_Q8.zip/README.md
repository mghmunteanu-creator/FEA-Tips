# Section 17.4 — Q8 multiplicative Updated Lagrangian program

Place all six MATLAB files in one folder and run `main.m`.
The example uses 4 × 30 Q8 elements, 429 nodes and ten load steps.

- `main.m`: load stepping and Newton iterations.
- `gen.m`: geometry, Q8 mesh, constraints and loading.
- `stiff_mult.m`: multiplicative deformation-gradient update, internal forces
  and tangent stiffness; `istrain=1` selects Hencky and `istrain=2` Biot strains.
- `B_matrix_mult.m`: Q8 strain–displacement matrix.
- `plot_disp.m`: displacement maps; default final step, vertical displacement,
  and `scale=1`.
- `plot_stress.m`: stresses extrapolated from nine Gauss points to eight Q8
  nodes, followed by nodal averaging; default final step, sigma_x and `scale=0`.

Press Enter at the plotting prompts to accept the defaults. Both plotting
programs use `turbo(16)` and `drawnow`.

The program files were supplied and validated by Mircea. The MATLAB release
used for that validation was not specified; no additional release-specific
execution claim is made here.

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases,
replace `turbo` with `jet`. This affects visualization only and does not change
the numerical results.

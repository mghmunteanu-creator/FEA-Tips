% *** plot_stress ***
iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - does not plot
istep=input('Load step (default=nstep): ');
if length(istep)==0; istep=nstep; end
istress=input('Stress (1-sx, 2-sy, 3-txy, 4-VM) (default=1): ');
if length(istress)==0; istress=1; end
scale=input('Scale (default=0): ');
if length(scale)==0; scale=0; end
load_step=istep
u=St(1:2:neq,istep+1);
v=St(2:2:neq,istep+1);
xc=x0+u*scale;
yc=y0+v*scale;
%==========================================================================
% Compute the nodal stresses performing the arithmetic average of the 
% stresses for the elements connected in the same node.
%==========================================================================
% Extrapolation of stresses from the 9 Gauss points to the 8 Q8 nodes
a=sqrt(0.6);
% Gauss point coordinates - same order as in stiff_mult
sg=[-a -a -a  0 0 0  a a a]';
tg=[-a  0  a -a 0 a -a 0 a]';
% Complete biquadratic interpolation
A=[ones(9,1) sg tg sg.*tg sg.^2 tg.^2 ...
   sg.^2.*tg sg.*tg.^2 sg.^2.*tg.^2];
% Natural coordinates of the Q8 nodes
sn=[ 1 -1 -1  1  0 -1  0  1]';
tn=[ 1  1 -1 -1  1  0 -1  0]';
An=[ones(8,1) sn tn sn.*tn sn.^2 tn.^2 ...
    sn.^2.*tn sn.*tn.^2 sn.^2.*tn.^2];
strs=zeros(nnd,2);
for ie=1:nel
    ig=(ie-1)*9+(1:9);
    % stresses at the 9 Gauss points
    sig0=sigmt(ig,istress,istep+1);
    % extrapolate to the 8 Q8 nodes
    coef=A\sig0;
    sigel=An*coef;
    for j=1:8
        nod=elem(ie,j);
        strs(nod,1)=strs(nod,1)+sigel(j);
        strs(nod,2)=strs(nod,2)+1;
    end
end
stress=strs(:,1)./strs(:,2);
%==========================================================================
% Graphic representation
figure(19+istress)
clf
hold on
axis('equal')
colormap(turbo(16))
smx=max(stress);
smn=min(stress);
if iedge==0
    patch('Vertices',[xc yc],'Faces',elem(:,[1 5 2 6 3 7 4 8]),'CData',stress,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[xc yc],'Faces',elem(:,[1 5 2 6 3 7 4 8]),'CData',stress,'Facecolor','interp','edgecolor','w')
end
colorbar
lighting phong
sigma_max=smx
sigma_min=smn
if istress==1
    sss='\sigma_x  -  Load step ';
elseif istress==2
    sss='\sigma_y  -  Load step ';
elseif istress==3
    sss='\tau_x_y  -  Load step ';
elseif istress==4
    sss='\sigma_v_o_n_ _M_i_s_e_s  -  Load step ';
end
title({[sss,num2str(istep)];['min= ',num2str(smn),'  max=',num2str(smx)]})
drawnow

% *** stiff_mult ***

istrain=1;   % 1 - Hencky strain
             % 2 - Biot strain

E1=E/(1-nu*nu);
E2=nu*E1;
G=E/2/(1+nu);

DHooke=[E1 E2 0
        E2 E1 0
         0  0 G];

F=zeros(neq,1);
K=zeros(neq);

% Gauss points, 3rd order
xgss=sqrt(0.6);
xgauss=[  -xgss      0     xgss];	
wgauss=[   5/9      8/9    5/9 ];	
xgs=[xgauss; xgauss; xgauss]; xgt=xgs';
xgs=xgs(:); xgt=xgt(:);
wgs=[wgauss; wgauss; wgauss]; wgt=wgs';
wgs=wgs(:); wgt=wgt(:);
ig=0;

for ie=1:nel;
	nodi=elem(ie,:);
    ip=[2*nodi-1; 2*nodi];
    ip=ip(:);
    sel=S(ip);
    %----------------------------------------------------------------------
    % Initial nodal coordinates

    xel0=x0(nodi);
    yel0=y0(nodi);

    %----------------------------------------------------------------------
    % Nodal coordinates at the beginning of the current load step

    xel=x(nodi);
    yel=y(nodi);

    % Current trial nodal coordinates

    xelt=xel+sel(1:2:16);
    yelt=yel+sel(2:2:16);

    fel=zeros(16,1);
    kel=zeros(16);

    for j=1:9
        ig=ig+1;
        s=xgs(j);
        t=xgt(j);
        dps0=[(1+t)/4  -(1+t)/4  -(1-t)/4  (1-t)/4     0     0     0     0];    
        dpt0=[(1+s)/4   (1-s)/4  -(1-s)/4 -(1+s)/4     0     0     0     0]; 	

        dps1=[   0    0    0    0    -s*(1+t)   -(1-t^2)/2  -s*(1-t)     (1-t^2)/2 ]; 	
        dpt1=[   0    0    0    0    (1-s^2)/2  -t*(1-s)    -(1-s^2)/2  -t*(1+s)   ]; 	

        dps2=[ (1-t^2)/2  -s*(1+t)    -(1-t^2)/2  -s*(1-t)      0      0     0     0]/2; 	
        dpt2=[-t*(1+s)     (1-s^2)/2  -t*(1-s)    -(1-s^2)/2    0      0     0     0]/2; 

        dps3=[-s*(1+t)    -(1-t^2)/2  -s*(1-t)     (1-t^2)/2    0      0     0     0]/2; 	
        dpt3=[ (1-s^2)/2  -t*(1-s)    -(1-s^2)/2  -t*(1+s)      0      0     0     0]/2; 	

        dps=dps0+dps1-dps2-dps3;
        dpt=dpt0+dpt1-dpt2-dpt3;
        H=[dps
            dpt];
        %------------------------------------------------------------------
        % Jacobians

        J0=H*[xel0 yel0];       % initial configuration
        J =H*[xel  yel ];       % beginning of current load step
        Jt=H*[xelt yelt];       % current trial configuration

        detJ=abs(det(J));

        %------------------------------------------------------------------
        % Derivatives referred to the initial configuration

        J1=inv(J);
        b=J1*H;

        Bux=[b(1,1:8)
             zeros(1,8)]; Bux=Bux(:)';
        Buy=[b(2,1:8)
            zeros(1,8)];  Buy=Buy(:)';

        Bvx=[zeros(1,8)
             b(1,1:8)];  Bvx=Bvx(:)';

        Bvy=[zeros(1,8)
            b(2,1:8)];  Bvy=Bvy(:)';

        ux=Bux*sel;
        uy=Buy*sel;
        vx=Bvx*sel;
        vy=Bvy*sel; 
        B0=[Bux; Bvy; Buy+Bvx];

        % Green-Lagrange strains:
        ex =ux+ux^2/2+vx^2/2;
        ey =vy+uy^2/2+vy^2/2;
        exy=uy+vx+ux*uy+vx*vy;
        %------------------------------------------------------------------
        % Geometric matrices

        Gx =Bux'*Bux+Bvx'*Bvx;
        Gy =Buy'*Buy+Bvy'*Bvy;
        Gxy=Bux'*Buy+Bvx'*Bvy+Buy'*Bux+Bvy'*Bvx;

        %------------------------------------------------------------------
        % Incremental deformation gradient
        % current converged configuration -> current trial configuration

        Finc=(J\Jt)';

        %------------------------------------------------------------------
        % Multiplicative update
        %
        % Fprev(:,:,ig) is the total deformation gradient stored
        % at the end of the preceding converged load step

        Fp=Fprev(:,:,ig,istep);
        FF=Finc*Fp;
        Fprev(:,:,ig,istep+1)=FF;
        %------------------------------------------------------------------
        % Polar decomposition

        C=FF'*FF;
        U=sqrtm(C);
        Ui=inv(U);
        if istrain==1
            ee=logm(U);
            Uic=Ui^2;       % Hencky strain tensor
        elseif istrain==2
            ee=U-eye(2);
            Uic=Ui;         % Biot strain tensor
        else
            error('Unknown strain tensor option')
        end
        %------------------------------------------------------------------
        % Strain-displacement matrix
        %
        % New B_matrix is used.
        B_matrix_mult
        ex =ee(1,1);
        ey =ee(2,2);
        exy=2*ee(1,2);
        %------------------------------------------------------------------
        % Cauchy stresses
        sigmt(ig,1:3,istep+1)=[ex ey exy]*DHooke;
        % Thickness correction
        th1=(1-nu/(1-nu)*(ex+ey))*th;
        %------------------------------------------------------------------
        % Internal force vector
        fel=fel+wgs(j)*wgt(j)*th1*(B'*sigmt(ig,1:3,istep+1)')*detJ;
        %------------------------------------------------------------------
        % Tangent stiffness matrix
        kel=kel+wgs(j)*wgt(j)*th1*(B'*DHooke*B ...
            +sigmt(ig,1,istep+1)*Gx ...
            +sigmt(ig,2,istep+1)*Gy ...
            +sigmt(ig,3,istep+1)*Gxy)*detJ;
        strnt(ig,:,istep+1)=[ex ey exy];

    end
    % assembling process:
    F(ip)=F(ip)+fel;
    K(ip,ip)=K(ip,ip)+kel;

end

% Constraints
loc=2*(cond(:,1)-1)+cond(:,2);
K(loc,:)=0;
K(:,loc)=0;
F(loc)=0;
K(loc,loc)=eye(length(loc));

% Concentrated force
loc=2*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;

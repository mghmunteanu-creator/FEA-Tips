# Section 17.4 MATLAB programs

This package implements the Updated Lagrangian Q4 plane-stress formulation with direct total-strain evaluation and a numerical tangent stiffness matrix obtained by central finite differences.

## Files

- `main.m` — nonlinear solution and load-step loop.
- `gen.m` — mesh, material, constraints, and loading for the bending example.
- `stiff.m` — element loop, assembly, and central numerical differentiation of the tangent matrix.
- `fel_el.m` — element internal nodal force evaluated from the current trial configuration.
- `B_matrix.m` — strain–displacement matrix used by the implemented internal-force formulation.
- `plot_disp.m` — displacement maps.
- `plot_strain.m` — strain recovery and strain maps.
- `plot_stress.m` — stress recovery and stress maps.

The default setting in `stiff.m` is `istrain=1` for Hencky strain. Set `istrain=2` to use Biot strain.

The programs were executed successfully in MATLAB R2026a for both strain options. With the default five-load-step example, the Hencky option converged in 37 total Newton iterations and produced `umax=155.2638 mm` and `vmax=286.1663 mm`. The Biot option converged in 39 total Newton iterations and produced `umax=155.2474 mm` and `vmax=286.0416 mm`.

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

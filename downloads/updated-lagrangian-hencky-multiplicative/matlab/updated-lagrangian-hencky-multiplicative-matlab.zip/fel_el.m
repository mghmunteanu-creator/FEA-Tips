%*** fel_el ***

fel=zeros(8,1);

st=[1  -1  -1   1
    1   1  -1  -1]*sqrt(3)/3;

for j=1:4

    s=st(1,j);
    t=st(2,j);

    H=[(1+t)/4  -(1+t)/4  -(1-t)/4   (1-t)/4
        (1+s)/4   (1-s)/4  -(1-s)/4  -(1+s)/4];

    % Current configuration
    J=H*[xel yel];
    detJ=abs(det(J));

    b=J\H;

    Bux=[b(1,1) 0 b(1,2) 0 b(1,3) 0 b(1,4) 0];
    Buy=[b(2,1) 0 b(2,2) 0 b(2,3) 0 b(2,4) 0];
    Bvx=[0 b(1,1) 0 b(1,2) 0 b(1,3) 0 b(1,4)];
    Bvy=[0 b(2,1) 0 b(2,2) 0 b(2,3) 0 b(2,4)];

    ux=Bux*sel;
    uy=Buy*sel;
    vx=Bvx*sel;
    vy=Bvy*sel;

    % -------------------------------------------------------------
    % B matrix - same approximation as in Section 17.3
    % -------------------------------------------------------------
    FF=[1+ux uy
        vx 1+vy];

    C=FF'*FF;
    U=sqrtm(C);
    Ui=inv(U);

    if istrain==1
        Uic=Ui^2;       % Hencky
    elseif istrain==2
        Uic=Ui;         % Biot
    else
        error('Unknown strain tensor option')
    end

    B_matrix

    % -------------------------------------------------------------
    % Direct total strain at the current trial configuration
    % -------------------------------------------------------------
    xelt=xel+sel(1:2:8);
    yelt=yel+sel(2:2:8);

    J0=H*[xel0 yel0];
    Jt=H*[xelt yelt];

    Ftot=(J0\Jt)';
    Ctot=Ftot'*Ftot;
    Utot=sqrtm(Ctot);
    
    Rtot=Ftot/Utot;
    
    if istrain==1
        ee=logm(Utot);              % material Hencky strain
    elseif istrain==2
        ee=Utot-eye(2);             % material Biot strain
    end

    % strain tensor expressed in the current configuration
    ee=Rtot*ee*Rtot';
    
    ex =ee(1,1);
    ey =ee(2,2);
    exy=2*ee(1,2);

    sig=[ex ey exy]*DHooke;

    th1=(1-nu/(1-nu)*(ex+ey))*th;

    fel=fel+th1*(B'*sig')*detJ;

    % Store only the unperturbed solution
    if isave==1
        ig=4*(ie-1)+j;
        sigmt(ig,1:3,istep+1)=sig;
        strnt(ig,:,istep+1)=[ex ey exy];
    end

end

%*** stiff ***
istrain=1;   % 1 - Hencky strain
             % 2 - Biot strain

dd=1e-5;

E1=E/(1-nu*nu);
E2=nu*E1;
G=E/2/(1+nu);

DHooke=[E1 E2 0
    E2 E1 0
    0  0 G];

F=zeros(neq,1);
K=zeros(neq);

for ie=1:nel

    n1=elem(ie,1);
    n2=elem(ie,2);
    n3=elem(ie,3);
    n4=elem(ie,4);

    ip=[2*n1-1 2*n1 ...
        2*n2-1 2*n2 ...
        2*n3-1 2*n3 ...
        2*n4-1 2*n4];

    sel=S(ip);

    % Nodal coordinates at the beginning of the load step
    xel=[x(n1) x(n2) x(n3) x(n4)]';
    yel=[y(n1) y(n2) y(n3) y(n4)]';

    % Initial nodal coordinates
    xel0=[x0(n1) x0(n2) x0(n3) x0(n4)]';
    yel0=[y0(n1) y0(n2) y0(n3) y0(n4)]';

    % -------------------------------------------------------------
    % Element internal force vector
    % -------------------------------------------------------------
    isave=1;
    fel_el
    fel0=fel;

    % -------------------------------------------------------------
    % Numerical tangent stiffness matrix
    % -------------------------------------------------------------
    kel=zeros(8);

    isave=0;

    for ipert=1:8

        sel(ipert)=sel(ipert)+dd;
        fel_el
        felp=fel;

        sel(ipert)=sel(ipert)-2*dd;
        fel_el
        felm=fel;

        sel(ipert)=sel(ipert)+dd;

        kel(:,ipert)=(felp-felm)/(2*dd);

    end

    % Assembly
    F(ip)=F(ip)+fel0;
    K(ip,ip)=K(ip,ip)+kel;

end

% Constraints
loc=2*(cond(:,1)-1)+cond(:,2);
K(loc,:)=0;
K(:,loc)=0;
F(loc)=0;
K(loc,loc)=eye(length(loc));

% Concentrated force
loc=2*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;

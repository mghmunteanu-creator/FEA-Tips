# Section 17.3 MATLAB programs

The package contains the MATLAB programs used for the example in Section 17.3.

- `main.m` runs the analysis.
- `gen.m` generates the mesh, constraints, and loading.
- `stiff.m` evaluates the internal nodal force vector and the improved tangent stiffness matrix. Set `istrain=1` for Hencky strain or `istrain=2` for Biot strain.
- `B_matrix.m` evaluates the strain-displacement matrix.
- `plot_disp.m`, `plot_strain.m`, and `plot_stress.m` plot displacements, strains, and stresses.

The package contains one `stiff.m` only. It includes the reference-configuration correction described in Section 17.3.

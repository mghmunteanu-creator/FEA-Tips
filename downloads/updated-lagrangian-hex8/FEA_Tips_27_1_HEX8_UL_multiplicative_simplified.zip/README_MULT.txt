FEA Tips - Section 27.1 - HEX8 Updated Lagrangian (UL)
Direct and multiplicative updates of the deformation gradient

How to run
----------
1. Keep the MATLAB .m files in the same directory.
2. Open main.m. Set use_mult=false for the direct evaluation (stiff.m),
   or use_mult=true for the multiplicative update (stiff_mult.m).
3. Run main in MATLAB.
4. Run test_mult_gradient for the standalone eight-Gauss-point identity test.

Multiplicative method
---------------------
- Fhist(:,:,ig) is initialized as eye(3) at every Gauss point: F_0 = I.
- Fhist remains FIXED throughout every Newton iteration of one load step.
- At each Newton trial, stiff_mult.m evaluates:
     Finc=(J\Jt)';
     Ftot=Finc*Fhist(:,:,ig);
     Ftotsal(:,:,ig)=Ftot;
- Once a load step has converged, main.m stores the final evaluated
  Gauss-point gradients in a SINGLE assignment:
     Fhist=Ftotsal;
- There is no commit_Fhist_mult.m or additional geometric recalculation.
- The standard Newton loop still updates S=S-dS after the stiffness
  evaluation. Consequently, Ftotsal corresponds to the last EVALUATED
  trial, before the last displacement correction dS, whose RMS norm is
  below tol. This is a tolerance-level approximation, not exact equality
  with the gradient of the final updated coordinates. Decrease tol if
  needed and compare against the direct version.
- The existing material/geometry stiffness model and external force
  handling are unchanged. This is NOT the fully consistent spatial
  linearization reserved for Section 27.3.

Verification
------------
- The independent 25-increment, eight-Gauss-point kinematic test gave a
  maximum Frobenius difference of 1.27e-15 for full exact multiplicative
  composition vs direct total gradient calculation.
- A MATLAB comparison reported by the user for nstep=20 showed identical
  displayed displacement extrema for direct and multiplicative variants:
  disp_max=1.4165e+00 mm; disp_min=-1.1343e+02 mm.
  This comparison precedes the simplified history update in this ZIP;
  rerun both variants to check the impact of the final discarded dS.
- Full MATLAB execution has not been performed in this environment.

Figures in the 27.1 draft used nstep=50; main.m defaults to nstep=20.

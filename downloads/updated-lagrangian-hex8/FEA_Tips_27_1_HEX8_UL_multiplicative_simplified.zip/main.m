%*** main ***
clear
format short e
nstep=20;            % number of load steps
tol=1e-4;
itermax=50;
use_mult=false;     % false: stiff.m; true: stiff_mult.m

gen
St=zeros(neq,nstep+1);
strnt=zeros(8*nel,6,nstep+1);
sigmt=zeros(8*nel,7,nstep+1);
if use_mult
    Fhist=repmat(eye(3),[1 1 8*nel]);  % F_0 = I at every Gauss point
    Ftotsal=zeros(3,3,8*nel);         % gradients from the latest trial
end
for istep=1:nstep
    S =zeros(neq,1);
    error=1;
    iter=0;
    while (error > tol) & (iter < itermax)
        iter=iter+1;
        if use_mult
            stiff_mult
        else
            stiff
        end
        dS=K\F;
        S=S-dS;
        error=sqrt(dS'*dS/neq);
    end
    if ~(isfinite(error) && error<=tol)
        builtin('error','Newton-Raphson failed at load step %d',istep);
    end
    % Store the total gradient from the last Newton evaluation.
    if use_mult
        Fhist=Ftotsal;
    end
    x=x+S(1:3:neq);
    y=y+S(2:3:neq);
    z=z+S(3:3:neq);
    grafic3d0
    [istep iter error]
    St(:,istep+1)=St(:,istep)+S;
    pause(0.01)
end
% Compute Von Mises stress:
sgech=sqrt(sigmt(:,1,:).^2+sigmt(:,2,:).^2+sigmt(:,3,:).^2-...
sigmt(:,1,:).*sigmt(:,2,:)-sigmt(:,2,:).*sigmt(:,3,:)-sigmt(:,3,:).*sigmt(:,1,:)+...        
3*sigmt(:,4,:).^2+3*sigmt(:,5,:).^2+3*sigmt(:,6,:).^2);
sigmt(:,7,:)=sgech;

%*** stiff ***
E1 =E*(1-nu)/(1+nu)/(1-2*nu);
nu1=nu/(1-nu);
G=E/2/(1+nu);
DHooke=[     E1   nu1*E1       nu1*E1
         nu1*E1       E1       nu1*E1
         nu1*E1   nu1*E1       E1 ];
DHooke(4,4)=G; DHooke(5,5)=G;; DHooke(6,6)=G;
F=zeros(neq,1);
K=zeros(neq);
% Gauss points
str=[-1   1  -1   1  -1   1  -1   1
     -1  -1   1   1  -1  -1   1   1
      1   1   1   1  -1  -1  -1  -1]*sqrt(3)/3;
ig=0;
for ie=1:nel;
    nodi=elem(ie,1:8);
    % conectivity matrix:
    ip(1:3:24)=3*nodi-2;
    ip(2:3:24)=3*nodi-1;
    ip(3:3:24)=3*nodi;

    sel=S(ip);
    
    % Nodal coordinates at the beginning of the current load step
    xel=x(nodi);
    yel=y(nodi);
    zel=z(nodi);

    % Initial nodal coordinates
    xel0=x0(nodi);
    yel0=y0(nodi);
    zel0=z0(nodi);

    % Current trial nodal coordinates
    xelt=xel+sel(1:3:24);
    yelt=yel+sel(2:3:24);
    zelt=zel+sel(3:3:24);

    fel=zeros(24,1);
    kel=zeros(24);
    for j=1:8
        ig=ig+1;
        s=str(1,j);
        t=str(2,j);
        r=str(3,j);
        H=1/8*[(1+t)*(1+r)  -(1+t)*(1+r)  -(1-t)*(1+r)   (1-t)*(1+r)   (1+t)*(1-r)   -(1+t)*(1-r)   -(1-t)*(1-r)   (1-t)*(1-r)     
               (1+s)*(1+r)   (1-s)*(1+r)  -(1-s)*(1+r)  -(1+s)*(1+r)   (1+s)*(1-r)    (1-s)*(1-r)   -(1-s)*(1-r)  -(1+s)*(1-r)     
               (1+s)*(1+t)   (1-s)*(1+t)   (1-s)*(1-t)   (1+s)*(1-t)  -(1+s)*(1+t)   -(1-s)*(1+t)   -(1-s)*(1-t)  -(1+s)*(1-t)];   
        J= H*[ xel    yel   zel];   % Jacobian
        detJ=abs(det(J));
        J1=inv(J);
        b=J1*H;
        Bux(1:3:24)=b(1,:); Bux(24)=0;
        Buy(1:3:24)=b(2,:); Buy(24)=0;
        Buz(1:3:24)=b(3,:); Buz(24)=0;
        
        Bvx(2:3:24)=b(1,:); Bvx(24)=0;
        Bvy(2:3:24)=b(2,:); Bvy(24)=0;
        Bvz(2:3:24)=b(3,:); Bvz(24)=0;
        
        Bwx(3:3:24)=b(1,:);
        Bwy(3:3:24)=b(2,:);
        Bwz(3:3:24)=b(3,:);
        
        %--------------------------------------------------------------
        % Direct total Euler-Almansi strain
        %--------------------------------------------------------------

        % Initial and current trial Jacobians
        J0=H*[xel0 yel0 zel0];
        Jt=H*[xelt yelt zelt];

        % Total deformation gradient: initial -> current trial configuration
        Ftot=(J0\Jt)';

        % Left Cauchy-Green tensor
        btens=Ftot*Ftot';

        % Euler-Almansi strain tensor
        ee=0.5*(eye(3)-inv(btens));

        ex =ee(1,1);
        ey =ee(2,2);
        ez =ee(3,3);
        exy=2*ee(1,2);
        eyz=2*ee(2,3);
        ezx=2*ee(3,1);

        %--------------------------------------------------------------
        Gx =Bux'*Bux+Bvx'*Bvx+Bwx'*Bwx;
        Gy =Buy'*Buy+Bvy'*Bvy+Bwy'*Bwy;
        Gz =Buz'*Buz+Bvz'*Bvz+Bwz'*Bwz;
        Gxy=Bux'*Buy +Bvx'*Bvy +Bwx'*Bwy+ Buy'*Bux +Bvy'*Bvx +Bwy'*Bwx;
        Gyz=Buy'*Buz +Bvy'*Bvz +Bwy'*Bwz+ Buz'*Buy +Bvz'*Bvy +Bwz'*Bwy;
        Gzx=Buz'*Bux +Bvz'*Bvx +Bwz'*Bwx+ Bux'*Buz +Bvx'*Bvz +Bwx'*Bwz;

        B0=[Bux
            Bvy
            Bwz
            Buy+Bvx
            Bvz+Bwy
            Bwx+Buz];

        BL=[sel'*Gx
            sel'*Gy
            sel'*Gz
            sel'*Gxy
            sel'*Gyz
            sel'*Gzx];

        B=B0+BL;

        sigmt(ig,1:6,istep+1)=[ex ey ez exy eyz ezx]*DHooke;

        fel=fel+(B'*sigmt(ig,1:6,istep+1)')*detJ;

        kel=kel+(B'*DHooke*B ...
            +sigmt(ig,1,istep+1)*Gx ...
            +sigmt(ig,2,istep+1)*Gy ...
            +sigmt(ig,3,istep+1)*Gz ...
            +sigmt(ig,4,istep+1)*Gxy ...
            +sigmt(ig,5,istep+1)*Gyz ...
            +sigmt(ig,6,istep+1)*Gzx)*detJ;

        strnt(ig,:,istep+1)=[ex ey ez exy eyz ezx];
    end

    % Assembly
    F(ip)=F(ip)+fel;
    K(ip,ip)=K(ip,ip)+kel;
end

% Constraints
loc=3*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 
% Concentrated force
loc=3*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;    

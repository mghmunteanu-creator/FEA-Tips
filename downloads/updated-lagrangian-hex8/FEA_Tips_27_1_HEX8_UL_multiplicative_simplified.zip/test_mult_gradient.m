% TEST_MULT_GRADIENT -- geometric identity at eight HEX8 Gauss points.
% Standalone test, independent of main.m and the nonlinear solver.
clear
str=[-1 1 -1 1 -1 1 -1 1;
     -1 -1 1 1 -1 -1 1 1;
      1 1 1 1 -1 -1 -1 -1]*sqrt(3)/3;
X=[0 0 0; 0 0 1; 0 1 1; 0 1 0; 2 0 0; 2 0 1; 2 1 1; 2 1 0];
A=[1.03 0.11 0.01; -0.02 0.98 0.04; 0.02 0.01 1.02];
B=[0.97 -0.06 0.05; 0.04 1.01 0.01; 0.00 -0.03 1.02];
X1=X*A'; X2=X1*B';
err=zeros(8,1);
for j=1:8
    s=str(1,j);t=str(2,j);r=str(3,j);
    H=1/8*[(1+t)*(1+r) -(1+t)*(1+r) -(1-t)*(1+r) (1-t)*(1+r) (1+t)*(1-r) -(1+t)*(1-r) -(1-t)*(1-r) (1-t)*(1-r);
           (1+s)*(1+r) (1-s)*(1+r) -(1-s)*(1+r) -(1+s)*(1+r) (1+s)*(1-r) (1-s)*(1-r) -(1-s)*(1-r) -(1+s)*(1-r);
           (1+s)*(1+t) (1-s)*(1+t) (1-s)*(1-t) (1+s)*(1-t) -(1+s)*(1+t) -(1-s)*(1+t) -(1-s)*(1-t) -(1+s)*(1-t)];
    J0=H*X; J1=H*X1; J2=H*X2;
    Fdirect=(J0\J2)';
    Fmult=(J1\J2)'*(J0\J1)';
    err(j)=norm(Fdirect-Fmult,'fro');
end
fprintf('Maximum |Fdirect-Fmult| at Gauss points: %.3e\n',max(err));
assert(max(err)<1e-11)
disp('PASS: multiplicative update matches the direct total gradient.')

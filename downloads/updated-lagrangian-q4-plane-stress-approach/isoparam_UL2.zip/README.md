# Section 15.2 — Updated Lagrangian Q4 plane-stress formulation

## Purpose

This package implements the Section 15.2 Updated Lagrangian formulation for a plane-stress structure discretized with 4-node isoparametric quadrilateral elements. During every load step, the geometry remains fixed at the converged configuration of the preceding step and is updated only after the current step has converged.

Two strain-update routines are included:

- `stiff.m`: simple additive strain update;
- `stiff2.m`: transformed strain update, in which the accumulated strain and the new Green–Lagrange-form increment are transformed to the new current configuration.

Both routines preserve the nonlinear `Gx`, `Gy`, and `Gxy` contributions used by this implementation.

## Files

- `main.m` — main program; configured for the five-load-step example and calling `stiff2` by default;
- `gen.m` — geometry, mesh, material data, boundary conditions, and loading;
- `stiff.m` — element and global computations with the simple strain update;
- `stiff2.m` — element and global computations with the transformed strain update;
- `plot_disp.m` — displacement plots;
- `plot_strain.m` — strain recovery and plots;
- `plot_stress.m` — stress recovery and plots.

## How to run

1. Extract all files into one folder.
2. Start MATLAB in that folder.
3. Run `main`.

The distributed `main.m` calls `stiff2`. To reproduce the simple strain-update result, change that solver call from `stiff2` to `stiff`, leaving the remaining algorithm unchanged.

The plotting routines ask for the load step, result component, and scale factor. Pressing Enter selects the default shown in each prompt. The default scale factor is 1.

## Example

The example is a 400 mm cantilever with a 5 mm × 20 mm rectangular cross-section, Young's modulus 1000 MPa, Poisson ratio 0.3, and a 100 N end force. The mesh contains 120 × 16 = 1920 Q4 elements and 2057 nodes. The analysis uses five load steps.

## Validation

The package was executed in MATLAB R2026a (26.1.0.3312084, Update 4).

With `stiff`, all five load steps converged. The iteration counts were `[8 9 8 7 7]`, the maximum was 9 iterations per step, the total was 39 iterations, and the final convergence error was `3.3047420e-07`. The final displacement extrema were:

- `v_min = -291.2529846 mm`;
- `u_max = 2.2265585 mm`;
- `u_min = -165.3985379 mm`.

With `stiff2`, all five load steps converged. The iteration counts were `[38 23 16 12 11]`, the maximum was 38 iterations per step, the total was 100 iterations, and the final convergence error was `1.1418219e-06`. The final displacement extrema were:

- `v_min = -289.0151185 mm`;
- `u_max = 2.4643912 mm`;
- `u_min = -158.8091207 mm`.

The displacement, strain, and stress plotting routines were also executed using the default scale factor of 1.

## Visualization compatibility

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

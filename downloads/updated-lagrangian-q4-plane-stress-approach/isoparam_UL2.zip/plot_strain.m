%*** plot_strain ***
iedge=0;    % iedge=1 - plot element contours
            % iedge=0 - does not plot
istep=input('Load step (default nstep): ');
if length(istep)==0; istep=nstep; end
istrain=input('Strain (1-ex, 2-ey, 3-gxy; default 1): ');
if length(istrain)==0; istrain=1; end
scale=input('Scale factor (default 1): ');
if isempty(scale), scale=1; end
load_step=istep
u=St(1:2:neq,istep+1);
v=St(2:2:neq,istep+1);
xc=x0+u*scale;
yc=y0+v*scale;
%==========================================================================
% extrapolation of the strains from Gauss points to element nodes
% (the strains are computed in stiff subprogram, at Gauss points)
strni=zeros(4*nel,3);
st=[1  -1  -1   1
    1   1  -1  -1]*sqrt(3)/3;
ig=1;
for ie=1:nel
    n1=elem(ie,1); n2=elem(ie,2); n3=elem(ie,3); n4=elem(ie,4);
    xel=[xc(n1) xc(n2) xc(n3) xc(n4)]'; 	% nodal
	yel=[yc(n1) yc(n2) yc(n3) yc(n4)]'; 	% coordinates 
    eps0=strnt(ig:ig+3,istrain,istep+1);
    for j=1:4
        s=st(1,j);
        t=st(2,j);
        N=[(1+s)*(1+t)/4 (1-s)*(1+t)/4 (1-s)*(1-t)/4 (1+s)*(1-t)/4];
        xst(j,1)=N*xel;
        yst(j,1)=N*yel;
    end
    A0=[xst yst ones(4,1)];
    A=A0'*A0;
    B=A0'*eps0;
    a=A\B;
    eps=a(1)*xel+a(2)*yel+a(3)*ones(4,1);
    strni(ig:ig+3,istrain)=eps;
    ig=ig+4;
end   
%==========================================================================
% Compute the nodal strains by performing the arithmetic average of the 
% strains for the elements connected at the same node.
strs=zeros(nnd,2);
ig=0;
for i=1:nel
    for j=1:4
        nod=elem(i,j);
        strs(nod,2)=strs(nod,2)+1;
        ig=ig+1;
        strs(nod,1)=strs(nod,1)+strni(ig,istrain);
    end
end
strain=strs(:,1)./strs(:,2);
%==========================================================================
% Graphic representation
figure(14+istrain)
clf
hold on
axis('equal')
colormap(turbo(16))
smx=max(strain);
smn=min(strain);
if iedge==0
    patch('Vertices',[xc yc],'Faces',elem,'CData',strain,'Facecolor','interp','edgecolor','none')
else
    patch('Vertices',[xc yc],'Faces',elem,'CData',strain,'Facecolor','interp','edgecolor','w')
end
colorbar
lighting phong
strain_max=smx
strain_min=smn
if istrain==1
    title('\epsilon_x')
elseif istrain==2
    title('\epsilon_y')   
elseif istrain==3
    title('\gamma_x_y')  
end

# Section 15.3 — Direct Euler–Almansi strain evaluation

## Purpose

This package implements the direct evaluation of the total Euler–Almansi strain from the current trial configuration for the Q4 plane-stress example discussed in Section 15.3. The comparison with the `stiff` and `stiff2` approaches is presented on the Section 15.3 web page; this package contains only the direct `stiff3` implementation.

## Files

- `main.m` — main program, configured for the five-load-step example;
- `gen.m` — geometry, mesh, material data, boundary conditions, and loading;
- `stiff3.m` — element and global computations with direct Euler–Almansi strain evaluation;
- `plot_disp.m` — displacement plots;
- `plot_strain.m` — strain recovery and plots;
- `plot_stress.m` — stress recovery and plots.

## How to run

1. Extract all files into one folder.
2. Start MATLAB in that folder.
3. Run `main`.

The geometry remains fixed during the iterations of each load step and is updated after convergence. At every Gauss point, `stiff3` evaluates the total deformation gradient from the initial configuration to the current trial configuration and computes the Euler–Almansi strain directly.

The plotting routines ask for the load step, result component, and scale factor. Pressing Enter selects the default shown in each prompt. The default scale factor is 1.

## Example

The example is a 400 mm cantilever with a 5 mm × 20 mm rectangular cross-section, Young's modulus 1000 MPa, Poisson ratio 0.3, and a 100 N end force. The mesh contains 120 × 16 = 1920 Q4 elements and 2057 nodes. The distributed program uses five load steps.

## MATLAB validation

The program was executed in MATLAB R2026a (26.1.0.3312084, Update 4). All load steps converged for every tested discretization. Using the approved convergence norm based on `neq`, the results were:

| Load steps | Total iterations | Average iterations/load step | Midline free-end `u` (mm) | Midline free-end `v` (mm) |
|---:|---:|---:|---:|---:|
| 5 | 100 | 20.0 | -149.5120572 | -282.6938760 |
| 10 | 104 | 10.4 | -149.9022665 | -282.8802874 |
| 20 | 150 | 7.5 | -149.9946323 | -282.9268882 |
| 50 | 300 | 6.0 | -150.0237491 | -282.9425945 |

Direct comparison with the Section 15.2 `stiff2` routine gave identical iteration counts and displacement values agreeing within normal floating-point roundoff for all four tests.

## Visualization compatibility

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

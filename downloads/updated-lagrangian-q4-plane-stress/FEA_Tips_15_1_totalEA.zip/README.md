# FEA Tips — Section 15.1

Total Euler–Almansi strain evaluation with approximate tangent stiffness.

## Files and use

- main.m: load steps and Newton iterations; default nstep=10.
- gen.m: cantilever mesh, material, constraints and loads.
- stiff_totalEA.m: total strains, internal forces and approximate stiffness.

Open MATLAB in the extracted folder and run main. Set nstep to 5, 10 or 50 for the comparison cases.

## Formulation

Total element displacements are selt=S(ip)+St(ip,istep), equivalently sel+St(ip,istep). Spatial derivatives use the current trial geometry. BL remains based on the current-step increment sel. No strain increments are accumulated. This is the approximate Section 15.1 formulation, not the consistent formulation reserved for Section 15.5.

The convergence measure is sqrt(dS'*dS/nnd), with tol=1e-5. Strains and stresses are stored from the latest assembled trial state. Convergence is checked using the displacement correction, not a separate residual tolerance.

## Verification and compatibility

The package has been inspected statically; no MATLAB release has been executed for this package during integration. MATLAB R2024 and R2026a are expected to support the syntax and base graphics used, but numerical reproduction and runtime compatibility have not been independently verified. No special compatibility substitution is required by the inspected code.
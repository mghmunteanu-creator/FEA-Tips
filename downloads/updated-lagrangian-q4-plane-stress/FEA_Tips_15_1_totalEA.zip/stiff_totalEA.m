%*** stiff_totalEA ***
% Updated Lagrangian Q4, plane stress.
% Total Euler-Almansi strains, with the original approximate B and tangent.
% Current geometry is updated after every Newton iteration in main.m.
% Plane-stress elastic matrix
E1=E/(1-nu*nu);  
E2=nu*E1;
G=E/2/(1+nu);
DHooke=[E1 E2 0
        E2 E1 0
         0  0 G];
F=zeros(neq,1);
K=zeros(neq);
% 2 x 2 Gauss points, with unit integration weights
st=[1  -1  -1   1
    1   1  -1  -1]*sqrt(3)/3;
ig=0;
for ie=1:nel;
	n1=elem(ie,1); n2=elem(ie,2); n3=elem(ie,3); n4=elem(ie,4);
    ip=[2*n1-1  2*n1  2*n2-1  2*n2  2*n3-1  2*n3  2*n4-1  2*n4]; 
    % Element nodal displacement increments accumulated during the current load step:
    sel=S(ip);
    % Total nodal displacements from the initial configuration, at the current trial state
    selt=S(ip)+St(ip,istep);
    %----------------------------------------------------------------------
    % Current trial nodal coordinates (updated after every iteration in main.m)
	xel=[x(n1) x(n2) x(n3) x(n4)]'; 
	yel=[y(n1) y(n2) y(n3) y(n4)]'; 
    fel=zeros(8,1);
	kel=zeros(8);
	for j=1:4;
        ig=ig+1;
        s=st(1,j);
        t=st(2,j);
        H=[(1+t)/4  -(1+t)/4  -(1-t)/4  (1-t)/4
           (1+s)/4   (1-s)/4  -(1-s)/4 -(1+s)/4]; 	
        J=H*[ xel    yel];                  % Jacobian of the current trial geometry
        detJ=abs(det(J));                  % Original absolute-value convention; does not detect inverted elements
        % Spatial derivatives of shape functions in the current configuration
        J1=inv(J);
        b=J1*H;
        Bux=[b(1,1)  0        b(1,2)   0        b(1,3)   0        b(1,4)   0     ];
        Buy=[b(2,1)  0        b(2,2)   0        b(2,3)   0        b(2,4)   0     ];
        Bvx=[0       b(1,1)   0        b(1,2)   0        b(1,3)   0        b(1,4)]; 
        Bvy=[0       b(2,1)   0        b(2,2)   0        b(2,3)   0        b(2,4)];            
        % Spatial gradients of TOTAL displacements (not current-step increments)
        ux=Bux*selt;
        uy=Buy*selt;
        vx=Bvx*selt;
        vy=Bvy*selt; 
        
        B0=[Bux; Bvy; Buy+Bvx];
        % Total Euler-Almansi strains: no accumulation from preceding load steps
        ex =ux-ux^2/2-vx^2/2;
        ey =vy-uy^2/2-vy^2/2;
        exy=uy+vx-ux*uy-vx*vy;
        
        % Matrices for the nonlinear correction in the SIMPLIFIED B
        Gx =Bux'*Bux+Bvx'*Bvx;
        Gy =Buy'*Buy+Bvy'*Bvy;
        Gxy=Bux'*Buy+Bvx'*Bvy+Buy'*Bux+Bvy'*Bvx;
        % IMPORTANT: BL uses sel (current load-step increment), NOT selt.
        % This is retained from the original APPROXIMATE tangent scheme.
        BL=[sel'*Gx; sel'*Gy; sel'*Gxy];
         
        % Approximate strain-displacement matrix; NOT the exact derivative
        % of the TOTAL Euler-Almansi strain with updated spatial gradients.
        B=B0-BL;
        % Stress components from the adopted linear elastic plane-stress law
        sigmt(ig,1:3,istep+1)=[ex ey exy]*DHooke;
        % Small-strain approximation for the current thickness
        th1=(1-nu/(1-nu)*(ex+ey))*th;
        % Original approximate internal-force expression (B rather than spatial B0)
        fel=fel+th1*(B'*sigmt(ig,1:3,istep+1)')*detJ;
        % Simplified APPROXIMATE tangent; no consistent variations of J, B0 or th1
        kel=kel+th1*(B'*DHooke*B)*detJ;
        % Store total strains for post-processing (not for accumulation)
        strnt(ig,:,istep+1)=[ex ey exy];    
    end
    % Assemble element internal forces and tangent matrices
    F(ip)=F(ip)+fel;
    K(ip,ip)=K(ip,ip)+kel;
end
% Enforce the prescribed zero displacement DOFs
loc=2*(cond(:,1)-1)+cond(:,2);
K(loc,:  )=0; K(:  ,loc)=0; F(loc,:  )=0;                    
K(loc,loc)=eye(length(loc)); 
% Apply external nodal loads scaled to the current load step
loc=2*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;               

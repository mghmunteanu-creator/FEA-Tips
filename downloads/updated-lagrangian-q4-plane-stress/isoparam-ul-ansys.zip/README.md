# Section 15.1 ANSYS macro

The package contains the Mechanical APDL macro for the plane-stress cantilever comparison presented in Section 15.1.

The macro defines the geometry, 5 mm thickness, linear elastic material (`E = 1000 MPa`, `nu = 0.3`), plane-stress PLANE182 elements, clamped left edge, distributed free-end loading, and large-displacement static analysis.

This macro was validated in the original version of the example. It has been transferred to the present edition without technical modification and was therefore not re-executed during the current revision.

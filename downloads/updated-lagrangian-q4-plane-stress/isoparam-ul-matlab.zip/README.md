# Section 15.1 MATLAB programs

## Purpose

These programs solve the plane-stress cantilever example from Section 15.1 with an Updated Lagrangian 4-node isoparametric quadrilateral formulation. The geometry is updated after every iteration. The Jacobian, spatial derivatives, strain-displacement matrices, internal-force vector, and approximate tangent stiffness are then recomputed using the latest trial configuration.

## Files

- `main.m` — controls the 50 load steps and iterative solution.
- `gen.m` — defines the geometry, material, mesh, constraints, and loading.
- `stiff.m` — evaluates Euler–Almansi strain increments, Cauchy stresses, internal forces, and the simplified tangent stiffness.
- `plot_disp.m` — plots horizontal or vertical displacement.
- `plot_strain.m` — extrapolates strains from Gauss points, averages shared-node values, and plots a selected strain component.
- `plot_stress.m` — fits a linear stress plane through the four Gauss-point values, evaluates it at element nodes, averages shared-node values, and plots a selected stress component.

## How to run

1. Place all files in one folder and make that folder the MATLAB current folder.
2. Run `main`.
3. After the solution finishes, run `plot_disp`, `plot_strain`, or `plot_stress` and respond to the prompts. Pressing Enter accepts the displayed defaults.

The model uses 1,920 Q4 elements, 2,057 nodes, and 50 load steps.

## Tested version and results

The programs were executed in MATLAB R2026a (version 26.1). All 50 load steps converged; no load step required more than 6 iterations. The final normalized correction error was `4.3018760750e-06`.

Final displacement extrema (mm):

- `u_min = -161.2587367`, `u_max = 2.2807486`
- `v_min = -289.9522833`, `v_max = 0`

Final extrapolated/averaged strain extrema:

- `epsilon_x`: `-0.07925984` to `0.07272984`
- `epsilon_y`: `-0.02332346` to `0.02445334`
- `gamma_xy`: `-0.05455840` to `0.05588089`

Final extrapolated/averaged stress extrema (MPa):

- `sigma_x`: `-87.0338952` to `79.9743861`
- `sigma_y`: `-25.9135142` to `24.1484793`
- `tau_xy`: `-20.9840005` to `21.4926494`
- von Mises stress: `0.1799338` to `78.4933300`

All displacement, strain, and stress plotting routines completed successfully.

## Colormap compatibility

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases, replace `turbo` with `jet`. This affects visualization only and does not change the numerical results.

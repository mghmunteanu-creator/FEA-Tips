%*** main ***
clear
format short e
nstep=50;                       % number of load steps
itermax=100;                    % number of maximum iterations
tol=1e-5;                       % tolerance
figure(5)
clf, hold on, grid on, axis('equal')
gen
St=zeros(neq,nstep+1);          % nodal displacements for all load steps  
strnt=zeros(4*nel,3,nstep+1);   % strains in finite elements for all load steps
sigmt=zeros(4*nel,4,nstep+1);   % stresses in finite elements for all load steps
for istep=1:nstep
    S =zeros(neq,1);            % nodal displacements for the current load step
    error=1;
    iter=0;
    while (error > tol) & (iter < itermax)
        iter=iter+1;
        stiff
        dS=K\F;
        S=S-dS;
        error=sqrt(dS'*dS/neq);
        x=x-dS(1:2:neq);
        y=y-dS(2:2:neq);
    end
    patch('Vertices',[x y],'Faces',elem,'Facecolor',[1 1 1],'linewidth',0.75,'edgecolor','b')    
    drawnow
    [istep iter error]
    St(:,istep+1)=St(:,istep)+S;
    pause(0.01)
end
% Compute Von Mises stress:
sgech=sqrt(sigmt(:,1,:).^2+sigmt(:,2,:).^2-sigmt(:,1,:).*sigmt(:,2,:)+3*sigmt(:,3,:).^2);
sigmt(:,4,:)=sgech;

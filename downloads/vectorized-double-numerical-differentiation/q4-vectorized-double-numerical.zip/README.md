# Section 17.6 — Vectorized double numerical differentiation (Q4)

Extract these nine files into a separate folder, select that folder in MATLAB,
and run `main.m`. Keep this package's routines together.

## Files

- `main.m`: load stepping and Newton loop.
- `gen.m`: geometry, loading, constraints and mesh plot.
- `stiff.m`: evaluates the 17 outer force trials together, assembles a sparse
  global tangent matrix, and applies the constraints and loading.
- `fel_el.m`: function evaluating internal forces for all elements and Gauss
  points together. It retains central differences for B.
- `strain_el.m`: function evaluating the same Hencky or Biot strain using
  batched spectral expressions for symmetric 2-by-2 matrices.
- `plot_disp.m`, `plot_strain.m`, `plot_stress.m`: interactive result plots.
- `README.md`: package instructions.

Set `istrain=1` (Hencky) or `istrain=2` (Biot) at the beginning of `stiff.m`.
The perturbations used in `stiff.m` and the Section 17.6 comparisons are
`ddB=ddK=1e-5`.

## What is accelerated

The 17 outer displacement states are processed simultaneously. The inner
positive/negative strain perturbations are also processed for all elements,
all four Gauss points and all outer states together. There are no repeated
scalar `eig` calls. The 2-by-2 symmetric matrix functions are evaluated using
the same spectral functions in algebraically equivalent closed form, with a
limiting expression when the eigenvalues nearly coincide.

The incremental gradient is affine in the nodal displacements. Consequently,
its perturbations can be formed directly using the shape-function derivatives,
without recomputing nodal trial coordinates and solving the same Jacobian
systems for each perturbation. Sparse assembly reduces the global storage and
linear-solution cost as the mesh grows.

No parallel workers, GPU, or Parallel Computing Toolbox are used. The code
uses `pagemtimes`, `pagemldivide`, and implicit array expansion; it is tested
with MATLAB R2026a Update 4. Compatibility with older releases is not asserted.

## Preserved behavior

The constitutive law, thickness correction, multiplicative Fprev update,
Gauss rule, force sign, constraints, load steps and stopping criterion are
unchanged. Numerical differentiation of both B and the tangent is retained.
No symmetrization of the tangent is introduced.

Only the unperturbed force evaluation is stored in `strnt`, `sigmt` and
`Fprev`. All perturbations read the same preceding load-step history. As in
the supplied main, storage occurs at the trial state at which `stiff` was
called; the vectorization does not add a post-convergence recomputation.

The supplied strain routine uses the components of the strain computed from
the right stretch tensor directly. This version preserves that choice and
does not add a rotation or change the strain/stress pairing. This is a
performance revision, not an independent validation of those assumptions.

Floating-point operation order changes, so bitwise identical results are not
expected. Full numerical and timing comparisons are supplied separately.

`turbo` is available in MATLAB R2020b and later. For earlier MATLAB releases,
replace `turbo` with `jet`. This affects visualization only and does not change
the numerical results. This substitution alone does not establish solver
compatibility with older releases.

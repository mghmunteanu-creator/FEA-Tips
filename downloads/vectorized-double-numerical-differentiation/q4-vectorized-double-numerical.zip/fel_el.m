function [fel,e0,Ftot0]=fel_el(q,b,Fp,detJ,DHooke,nu,th,ddB,istrain)
% Batched internal forces: all elements, Gauss points and outer perturbations.
% q: 8 x nel x ntrial. Gauss point index varies before element index.
nel=size(q,2); ng=4*nel; nt=size(q,3);
qg=repelem(q,1,4,1);
u=qg(1:2:8,:,:); v=qg(2:2:8,:,:);
bx=reshape(b(1,:,:),4,ng);
by=reshape(b(2,:,:),4,ng);
a=1+sum(bx.*u,1); c=sum(bx.*v,1);
d=1+sum(by.*v,1); bb=sum(by.*u,1);
p=reshape(Fp(1,1,:),1,ng); r=reshape(Fp(2,1,:),1,ng);
s=reshape(Fp(1,2,:),1,ng); t=reshape(Fp(2,2,:),1,ng);
% Column-major order [F11; F21; F12; F22].
Ft=cat(1,a.*p+bb.*r,c.*p+d.*r,a.*s+bb.*t,c.*s+d.*t);
ee=strain_el(Ft,istrain);
B=zeros(3,8,ng,nt);
for ib=1:8
    node=ceil(ib/2);
    g1=bx(node,:).*p+by(node,:).*r;
    g2=bx(node,:).*s+by(node,:).*t;
    df=zeros(4,ng);
    if rem(ib,2)==1
        df(1,:)=g1; df(3,:)=g2;
    else
        df(2,:)=g1; df(4,:)=g2;
    end
    ep=strain_el(Ft+ddB*df,istrain);
    em=strain_el(Ft-ddB*df,istrain);
    B(:,ib,:,:) = reshape((ep-em)/(2*ddB),3,1,ng,nt);
end
sig=reshape(DHooke*reshape(ee,3,[]),3,1,ng,nt);
th1=(1-nu/(1-nu)*(ee(1,:,:)+ee(2,:,:)))*th;
fg=pagemtimes(permute(B,[2 1 3 4]),sig);
fg=fg.*reshape(th1.*detJ,1,1,ng,nt);
fel=reshape(sum(reshape(fg,8,4,nel,nt),2),8,nel,nt);
e0=ee(:,:,1); Ftot0=Ft(:,:,1);
end

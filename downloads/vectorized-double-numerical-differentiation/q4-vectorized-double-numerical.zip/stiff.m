% *** stiff — batched double numerical differentiation ***
istrain=1;   % 1 - Hencky strain
             % 2 - Biot strain
ddB=1e-5;
ddK=1e-5;

E1=E/(1-nu*nu);
E2=nu*E1;
G=E/2/(1+nu);
DHooke=[E1 E2 0; E2 E1 0; 0 0 G];

% Interleave the x/y degrees of freedom of each node.
ipos=reshape(permute(cat(3,2*elem'-1,2*elem'),[3 1 2]),8,nel);

st=[1 -1 -1 1;1 1 -1 -1]*sqrt(3)/3;
Hg=zeros(2,4,4);
for j=1:4
    s=st(1,j); t=st(2,j);
    Hg(:,:,j)=[(1+t)/4 -(1+t)/4 -(1-t)/4 (1-t)/4;
              (1+s)/4 (1-s)/4 -(1-s)/4 -(1+s)/4];
end
coords=reshape([x(elem') y(elem')],4,nel,2);
coords=permute(coords,[1 3 4 2]);
J=pagemtimes(reshape(Hg,2,4,4,1),coords);
detJ=reshape(abs(J(1,1,:,:).*J(2,2,:,:)-J(1,2,:,:).*J(2,1,:,:)),1,4*nel);
b=reshape(pagemldivide(J,repmat(Hg,1,1,1,nel)),2,4,4*nel);
Fp=Fprev(:,:,:,istep);

% All seventeen outer force evaluations use the same previous history.
q=repmat(reshape(S(ipos),8,nel,1),1,1,17);
for ipert=1:8
    q(ipert,:,1+ipert)=q(ipert,:,1+ipert)+ddK;
    q(ipert,:,9+ipert)=q(ipert,:,9+ipert)-ddK;
end
[fels,e0,Ftot0]=fel_el(q,b,Fp,detJ,DHooke,nu,th,ddB,istrain);

kel=permute((fels(:,:,2:9)-fels(:,:,10:17))/(2*ddK),[1 3 2]);
rows=repmat(reshape(ipos,8,1,nel),1,8,1);
cols=repmat(reshape(ipos,1,8,nel),8,1,1);
K=sparse(rows(:),cols(:),kel(:),neq,neq);
F=accumarray(ipos(:),reshape(fels(:,:,1),[],1),[neq 1]);

% Store only the unperturbed force evaluation, exactly as in the original.
Fprev(:,:,:,istep+1)=reshape(Ftot0,2,2,4*nel);
strnt(:,:,istep+1)=e0';
sigmt(:,1:3,istep+1)=(DHooke*e0)';

loc=2*(cond(:,1)-1)+cond(:,2);
K(loc,:)=0; K(:,loc)=0; F(loc)=0;
K(loc,loc)=speye(length(loc));
loc=2*(forze(:,1)-1)+forze(:,2);
F(loc)=F(loc)-forze(:,3)*istep/nstep;

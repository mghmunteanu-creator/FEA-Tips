function estr=strain_el(Ft,istrain)
% Spectral function of symmetric 2x2 C, evaluated on whole arrays.
% Algebraically equivalent to Q*diag(log(sqrt(eig(C))))*Q' (Hencky)
% or Q*diag(sqrt(eig(C)))*Q'-I (Biot), without individual eig calls.
% No extra tensor rotation is introduced: the supplied formulation is kept.
a=Ft(1,:,:).^2+Ft(2,:,:).^2;
d=Ft(3,:,:).^2+Ft(4,:,:).^2;
c=Ft(1,:,:).*Ft(3,:,:)+Ft(2,:,:).*Ft(4,:,:);
m=(a+d)/2; z=(a-d)/2; r=hypot(z,c);
detF=Ft(1,:,:).*Ft(4,:,:)-Ft(2,:,:).*Ft(3,:,:);
lp=m+r; lm=detF.^2./lp;
if any(lm(:)<=0) || any(~isfinite(lp(:)))
    error('Singular or non-finite trial deformation gradient')
end
if istrain==1
    alpha=0.5*log(abs(detF));
    beta=zeros(size(m));
    near=r<=1e-6*m;
    w=r(near)./m(near);
    beta(near)=(1+w.^2/3+w.^4/5)./(2*m(near));
    beta(~near)=(log(lp(~near))-log(lm(~near)))./(4*r(~near));
elseif istrain==2
    sumstretch=sqrt(lp)+sqrt(lm);
    alpha=sumstretch/2-1;
    beta=1./sumstretch;
else
    error('Unknown strain tensor option')
end
estr=cat(1,alpha+beta.*z,alpha-beta.*z,2*beta.*c);
end
